'use strict';
/**
 * PingIN GitHub Content Script
 * Shows floating side tab ONLY on GitHub user search results pages
 * Invisible on all other GitHub pages
 */

// ── Only run on user search results ─────────────────────────────
function isGitHubProfilePage() {
  // Match github.com/username — individual profile pages only
  // NOT search pages, trending, explore, orgs etc.
  const skip = ['search','trending','explore','topics','marketplace','features',
                'enterprise','about','pricing','contact','security','sponsors',
                'notifications','settings','login','signup','collections',
                'codespaces','issues','pulls','orgs','site'];
  const m = location.href.match(/^https:\/\/github\.com\/([a-zA-Z0-9_.-]+)\/?(?:\?.*)?$/);
  if (!m) return false;
  const user = m[1].toLowerCase();
  return !skip.includes(user);
}

// ── State ────────────────────────────────────────────────────────
let floatTab      = null;
let floatPanel    = null;
let isOpen        = false;
let savedProfiles = []; // profiles added this session

// ── Init ─────────────────────────────────────────────────────────
function initFloatingTab() {
  if (floatTab) return; // already initialised
  if (!isGitHubProfilePage()) return;

  injectStyles();
  createFloatingTab();
  observeCards();
}

function destroyFloatingTab() {
  if (floatTab)  { floatTab.remove();  floatTab  = null; }
  if (floatPanel){ floatPanel.remove(); floatPanel = null; }
  isOpen = false;
}

// ── Watch URL changes (GitHub is SPA) ───────────────────────────
let lastUrl = location.href;
const urlObserver = new MutationObserver(() => {
  if (location.href === lastUrl) return;
  lastUrl = location.href;

  if (isGitHubProfilePage()) {
    setTimeout(initFloatingTab, 800);
  } else {
    destroyFloatingTab();
  }
});
urlObserver.observe(document.body, { childList: true, subtree: true });

// Run on initial load
if (isGitHubProfilePage()) {
  setTimeout(initFloatingTab, 1000);
}

// ── CSS ──────────────────────────────────────────────────────────
function injectStyles() {
  if (document.getElementById('pingin-gh-style')) return;
  const style = document.createElement('style');
  style.id = 'pingin-gh-style';
  style.textContent = `
    /* Floating tab */
    #pingin-float-tab {
      position: fixed;
      right: 0;
      top: 50%;
      transform: translateY(-50%);
      z-index: 99999;
      background: linear-gradient(180deg, #0060CC, #00A890);
      color: #fff;
      border-radius: 10px 0 0 10px;
      padding: 14px 6px;
      cursor: pointer;
      writing-mode: vertical-rl;
      text-orientation: mixed;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: .05em;
      user-select: none;
      box-shadow: -2px 0 16px rgba(0,96,204,.35);
      transition: transform .2s, box-shadow .2s;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    #pingin-float-tab:hover {
      transform: translateY(-50%) translateX(-3px);
      box-shadow: -4px 0 20px rgba(0,96,204,.5);
    }
    #pingin-float-tab .tab-icon {
      writing-mode: horizontal-tb;
      font-size: 16px;
    }

    /* Slide panel */
    #pingin-float-panel {
      position: fixed;
      right: -320px;
      top: 50%;
      transform: translateY(-50%);
      z-index: 99998;
      width: 300px;
      max-height: 80vh;
      background: #0D0F14;
      border: 1px solid rgba(255,255,255,.12);
      border-radius: 14px 0 0 14px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      transition: right .28s cubic-bezier(.4,0,.2,1);
      box-shadow: -4px 0 32px rgba(0,0,0,.6);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    }
    #pingin-float-panel.open {
      right: 0;
    }

    /* Panel header */
    .pg-hdr {
      padding: 12px 14px 10px;
      background: linear-gradient(135deg, #0A0C10, #111827);
      border-bottom: 1px solid rgba(255,255,255,.08);
      position: relative;
    }
    .pg-hdr::after {
      content: '';
      position: absolute;
      bottom: 0; left: 0; right: 0;
      height: 2px;
      background: linear-gradient(90deg, #0077B5, #00C49A);
    }
    .pg-hdr-top {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 4px;
    }
    .pg-logo {
      font-size: 13px;
      font-weight: 800;
      color: #fff;
    }
    .pg-logo span {
      background: linear-gradient(90deg,#5BB5FF,#00C49A);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .pg-close {
      width: 22px; height: 22px;
      border-radius: 50%;
      background: rgba(255,255,255,.08);
      border: none;
      color: rgba(255,255,255,.5);
      font-size: 14px;
      cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      line-height: 1;
    }
    .pg-close:hover { background: rgba(255,255,255,.15); color: #fff; }
    .pg-sub {
      font-size: 10px;
      color: rgba(255,255,255,.4);
      letter-spacing: .04em;
    }
    .pg-count {
      font-size: 10px;
      font-weight: 700;
      color: #00D4AA;
      margin-top: 2px;
    }

    /* Developer card */
    .pg-card {
      margin: 10px 10px 0;
      padding: 10px 12px;
      background: rgba(255,255,255,.04);
      border: 1px solid rgba(255,255,255,.08);
      border-radius: 10px;
    }
    .pg-card-name {
      font-size: 12px;
      font-weight: 700;
      color: #F0F2F8;
      margin-bottom: 2px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .pg-card-sub {
      font-size: 10px;
      color: rgba(255,255,255,.45);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      margin-bottom: 8px;
    }
    .pg-card-btns {
      display: flex;
      gap: 6px;
    }
    .pg-btn {
      flex: 1;
      padding: 7px 4px;
      border-radius: 7px;
      font-size: 10px;
      font-weight: 700;
      cursor: pointer;
      font-family: inherit;
      border: none;
      transition: opacity .15s;
      text-align: center;
    }
    .pg-btn:hover { opacity: .85; }
    .pg-btn-li {
      background: linear-gradient(135deg,#0055CC,#0077B5);
      color: #fff;
    }
    .pg-btn-add {
      background: linear-gradient(135deg,#009B7D,#00D4AA);
      color: #fff;
    }

    /* Search results hover highlight */
    .pg-result-hover {
      background: rgba(0,119,181,.07) !important;
      transition: background .15s;
    }

    /* Scrollable saved list */
    .pg-saved-wrap {
      flex: 1;
      overflow-y: auto;
      padding: 0 10px 10px;
      max-height: 320px;
    }
    .pg-saved-wrap::-webkit-scrollbar { width: 3px; }
    .pg-saved-wrap::-webkit-scrollbar-thumb { background: rgba(255,255,255,.1); border-radius:2px; }
    .pg-saved-label {
      font-size: 9px;
      font-weight: 700;
      color: rgba(255,255,255,.3);
      text-transform: uppercase;
      letter-spacing: .08em;
      padding: 10px 2px 6px;
    }
    .pg-saved-item {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 7px 9px;
      background: rgba(255,255,255,.03);
      border: 1px solid rgba(255,255,255,.06);
      border-radius: 8px;
      margin-bottom: 5px;
    }
    .pg-saved-av {
      width: 26px; height: 26px;
      border-radius: 50%;
      background: rgba(0,119,181,.25);
      color: #5BB5FF;
      font-size: 9px;
      font-weight: 800;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0;
    }
    .pg-saved-name {
      font-size: 11px;
      color: #E0E4F0;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .pg-saved-tag {
      font-size: 9px;
      font-weight: 700;
      padding: 2px 6px;
      background: rgba(0,212,170,.12);
      color: #00D4AA;
      border-radius: 4px;
      flex-shrink: 0;
    }

    /* Footer buttons */
    .pg-footer {
      padding: 10px;
      border-top: 1px solid rgba(255,255,255,.07);
      display: flex;
      gap: 6px;
    }
    .pg-footer-btn {
      flex: 1;
      padding: 9px;
      border-radius: 8px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      font-family: inherit;
      border: 1px solid rgba(255,255,255,.1);
      background: rgba(255,255,255,.05);
      color: rgba(255,255,255,.7);
      transition: all .15s;
      text-align: center;
    }
    .pg-footer-btn:hover { background: rgba(255,255,255,.1); color: #fff; }
    .pg-footer-btn.primary {
      background: linear-gradient(135deg,#0055CC,#00A890);
      border-color: transparent;
      color: #fff;
    }

    /* Empty state */
    .pg-empty {
      text-align: center;
      padding: 20px 14px;
      color: rgba(255,255,255,.3);
      font-size: 11px;
      line-height: 1.6;
    }
    .pg-empty-icon { font-size: 28px; margin-bottom: 8px; }

    /* Hover card (appears next to result cards) */
    .pg-hover-card {
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      display: flex;
      gap: 5px;
      opacity: 0;
      transition: opacity .2s;
      pointer-events: none;
      z-index: 999;
    }
    .pg-result-item:hover .pg-hover-card,
    .pg-result-item:hover .pg-hover-card {
      opacity: 1;
      pointer-events: all;
    }
    .pg-result-item {
      position: relative;
    }
    .pg-quick-btn {
      padding: 5px 10px;
      border-radius: 6px;
      font-size: 10px;
      font-weight: 700;
      cursor: pointer;
      font-family: inherit;
      border: none;
      color: #fff;
      white-space: nowrap;
      box-shadow: 0 2px 8px rgba(0,0,0,.4);
    }
    .pg-quick-li  { background: linear-gradient(135deg,#0055CC,#0077B5); }
    .pg-quick-add { background: linear-gradient(135deg,#009B7D,#00D4AA); }
  `;
  document.head.appendChild(style);
}

// ── Create floating tab + panel ──────────────────────────────────
function createFloatingTab() {
  // Tab button (vertical strip)
  floatTab = document.createElement('div');
  floatTab.id = 'pingin-float-tab';
  floatTab.innerHTML = '<span class="tab-icon">🐙</span>PingIN';
  document.body.appendChild(floatTab);

  // Slide panel
  floatPanel = document.createElement('div');
  floatPanel.id = 'pingin-float-panel';
  floatPanel.innerHTML = `
    <div class="pg-hdr">
      <div class="pg-hdr-top">
        <div class="pg-logo">Ping<span>IN</span></div>
        <button class="pg-close" id="pg-close-btn">✕</button>
      </div>
      <div class="pg-sub" id="pg-panel-sub">GitHub Developer Profile</div>
      <div class="pg-count" id="pg-added-count"></div>
    </div>

    <div class="pg-card" id="pg-active-card">
      <div class="pg-empty">
        <div class="pg-empty-icon">⏳</div>
        Reading profile...
      </div>
    </div>

    <div class="pg-saved-wrap" id="pg-saved-wrap">
      <div class="pg-saved-label">Added to PingIN</div>
      <div id="pg-saved-list">
        <div class="pg-empty" style="padding:10px 0;">
          <div style="font-size:11px;">No profiles added yet.<br>Click + Add on any developer.</div>
        </div>
      </div>
    </div>

    <div class="pg-footer">
      <button class="pg-footer-btn" id="pg-clear-btn">Clear All</button>
      <button class="pg-footer-btn primary" id="pg-outreach-btn">▶ Smart Outreach (${savedProfiles.length})</button>
    </div>
  `;
  document.body.appendChild(floatPanel);

  // Tab click — toggle panel
  floatTab.addEventListener('click', togglePanel);
  document.getElementById('pg-close-btn')?.addEventListener('click', closePanel);
  document.getElementById('pg-clear-btn')?.addEventListener('click', clearSaved);
  document.getElementById('pg-outreach-btn')?.addEventListener('click', sendToOutreach);

  // On profile pages — auto-load the profile into the active card immediately
  autoLoadProfile();
}

function autoLoadProfile() {
  // Small delay for page to fully render
  setTimeout(() => {
    const dev = extractDevFromPage();
    if (dev) updateActiveCard(dev, null);
  }, 1200);
}

function extractDevFromPage() {
  // Extract profile info directly from the GitHub profile page DOM
  const name     = document.querySelector('[itemprop="name"], .p-name, .vcard-fullname')?.textContent?.trim() || '';
  const username = document.querySelector('[itemprop="additionalName"], .p-nickname')?.textContent?.trim() ||
                   location.pathname.replace('/', '').split('/')[0] || '';
  const bio      = document.querySelector('[data-bio-text], .p-note, .user-profile-bio div')?.textContent?.trim() || '';
  const loc      = document.querySelector('[itemprop="homeLocation"], .p-label, li[itemprop="homeLocation"] span')?.textContent?.trim() || '';

  // Check for LinkedIn link in profile sidebar
  const links  = Array.from(document.querySelectorAll('a[href*="linkedin.com/in/"], li a[href*="linkedin.com"]'));
  const liUrl  = links[0]?.href || null;

  // Get top languages from pinned repos
  const langs  = [...new Set(Array.from(document.querySelectorAll('[data-language]')).map(el => el.dataset.language).filter(Boolean))].slice(0,3);

  if (!username) return null;

  return {
    name:       name || username,
    username,
    bio:        bio || langs.join(', '),
    location:   loc,
    linkedin:   liUrl,
    profileUrl: 'https://github.com/' + username,
    skills:     langs.join(', '),
  };
}

function togglePanel() {
  isOpen ? closePanel() : openPanel();
}
function openPanel() {
  isOpen = true;
  floatPanel?.classList.add('open');
}
function closePanel() {
  isOpen = false;
  floatPanel?.classList.remove('open');
}

// ── Observe GitHub result cards ──────────────────────────────────
function observeCards() {
  // Watch for cards being added to the DOM (GitHub loads dynamically)
  const cardObserver = new MutationObserver(() => wireCards());
  cardObserver.observe(document.body, { childList: true, subtree: true });
  wireCards(); // run immediately
}

let wiredCards = new WeakSet();

function wireCards() {
  // GitHub search result selectors
  const cards = document.querySelectorAll(
    '.search-title, [data-hovercard-type="user"], .UserListItem, .user-list-item'
  );

  // Also try broader — find all user cards on search page
  const resultItems = document.querySelectorAll(
    'article.Box-row, li.Box-row, [class*="UserCard"], [data-testid*="user"]'
  );

  const allCards = [...new Set([...cards, ...resultItems])];

  allCards.forEach(card => {
    if (wiredCards.has(card)) return;
    wiredCards.add(card);

    card.classList.add('pg-result-item');

    // Extract developer info from card
    card.addEventListener('mouseenter', () => {
      const dev = extractDevFromCard(card);
      if (dev) updateActiveCard(dev, card);
    });
  });
}

function extractDevFromCard(card) {
  // Try to get name and username from card
  const linkEl = card.querySelector('a[href^="/"][href*="/"]:not([href*="/search"]):not([href*="/orgs"])') ||
                 card.querySelector('a[data-hovercard-type="user"]') ||
                 card.querySelector('a[href^="/"]');

  if (!linkEl) return null;

  const href     = linkEl.getAttribute('href') || '';
  const username = href.replace(/^\//, '').split('/')[0];
  if (!username || username.includes('.') && !username.includes('-')) return null;

  const name = card.querySelector('.search-match, [class*="name"], strong, h3, h4')?.textContent?.trim() ||
               card.querySelector('a[data-hovercard-type="user"]')?.textContent?.trim() ||
               username;

  const bio  = card.querySelector('p, [class*="bio"], [class*="description"]')?.textContent?.trim() || '';
  const loc  = card.querySelector('[class*="location"], [aria-label*="location"]')?.textContent?.trim() || '';

  const profileUrl = 'https://github.com/' + username;

  return { username, name, bio, location: loc, profileUrl };
}

function updateActiveCard(dev, cardEl) {
  const el = document.getElementById('pg-active-card');
  if (!el) return;

  // Open panel automatically on hover
  if (!isOpen) openPanel();

  const ini = (dev.name || dev.username).split(' ').map(w => w[0] || '').join('').slice(0, 2).toUpperCase();
  const sub = [dev.bio?.split('.')[0]?.slice(0,40), dev.location].filter(Boolean).join(' · ');

  el.innerHTML = `
    <div style="display:flex;align-items:center;gap:9px;margin-bottom:8px;">
      <div style="width:32px;height:32px;border-radius:50%;background:rgba(0,119,181,.25);color:#5BB5FF;font-size:11px;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0;">${ini}</div>
      <div style="flex:1;min-width:0;">
        <div class="pg-card-name">@${dev.username}</div>
        <div class="pg-card-sub">${sub || 'GitHub Developer'}</div>
      </div>
    </div>
    <div class="pg-card-btns">
      <button class="pg-btn pg-btn-li" id="pg-find-li">🔗 Find LinkedIn</button>
      <button class="pg-btn pg-btn-add" id="pg-add-btn">+ Add to List</button>
    </div>
  `;

  document.getElementById('pg-find-li')?.addEventListener('click', () => findLinkedIn(dev));
  document.getElementById('pg-add-btn')?.addEventListener('click', () => addToList(dev));
}

// ── Find LinkedIn ────────────────────────────────────────────────
async function findLinkedIn(dev) {
  // First try to read LinkedIn from their actual GitHub profile
  try {
    const resp = await fetch('https://github.com/' + dev.username, { credentials: 'include' });
    const text = await resp.text();

    // Look for linkedin.com/in/ in the page HTML
    const liMatch = text.match(/https?:\/\/(www\.)?linkedin\.com\/in\/[a-zA-Z0-9_-]+/i);
    if (liMatch) {
      window.open(liMatch[0], '_blank');
      showCardMsg('✅ LinkedIn found and opened!', true);
      return;
    }
  } catch(e) {}

  // Level 2 — Search by name + location
  const name = dev.name && dev.name !== dev.username ? dev.name : null;
  const loc  = dev.location || '';

  if (name) {
    const url = 'https://www.linkedin.com/search/results/people/?keywords=' +
      encodeURIComponent(name + (loc ? ' ' + loc : '')) +
      '&origin=GLOBAL_SEARCH_HEADER';
    window.open(url, '_blank');
    showCardMsg('🔍 No direct link. Opened LinkedIn search for "' + name + '"', false);
    return;
  }

  // Level 3 — Skills fallback
  const skills = dev.bio?.split(/[\s,]+/).slice(0, 3).join(' ') || dev.username;
  const url3 = 'https://www.linkedin.com/search/results/people/?keywords=' +
    encodeURIComponent(skills + (loc ? ' ' + loc : '')) +
    '&origin=GLOBAL_SEARCH_HEADER';
  window.open(url3, '_blank');
  showCardMsg('🔍 Direct profile not found. Opened LinkedIn with matching skills — you might find someone even better.', false);
}

function showCardMsg(msg, ok) {
  const el = document.getElementById('pg-active-card');
  if (!el) return;
  const msgEl = document.createElement('div');
  msgEl.style.cssText = 'margin-top:8px;padding:6px 9px;border-radius:7px;font-size:10px;font-weight:600;' +
    (ok ? 'background:rgba(0,212,170,.12);color:#00D4AA;border:1px solid rgba(0,212,170,.25);'
        : 'background:rgba(255,180,0,.1);color:#FFC107;border:1px solid rgba(255,180,0,.25);');
  msgEl.textContent = msg;
  el.appendChild(msgEl);
  setTimeout(() => msgEl.remove(), 5000);
}

// ── Add to PingIN List ───────────────────────────────────────────
function addToList(dev) {
  // Avoid duplicates
  if (savedProfiles.find(p => p.username === dev.username)) {
    showCardMsg('Already in your list!', false);
    return;
  }

  savedProfiles.push({
    name:       dev.name || dev.username,
    username:   dev.username,
    profileUrl: dev.profileUrl,
    bio:        dev.bio,
    location:   dev.location,
    source:     'github',
    status:     'pending',
    scrapedAt:  new Date().toISOString(),
  });

  renderSavedList();
  showCardMsg('✅ Added to PingIN list!', true);

  // Sync to chrome storage for Smart Outreach
  syncToStorage();
}

function renderSavedList() {
  const list    = document.getElementById('pg-saved-list');
  const countEl = document.getElementById('pg-added-count');
  const outBtn  = document.getElementById('pg-outreach-btn');

  if (countEl) countEl.textContent = savedProfiles.length
    ? savedProfiles.length + ' developer' + (savedProfiles.length > 1 ? 's' : '') + ' added'
    : '';

  if (outBtn) outBtn.textContent = '▶ Smart Outreach (' + savedProfiles.length + ')';

  if (!list) return;

  if (!savedProfiles.length) {
    list.innerHTML = '<div style="font-size:11px;color:rgba(255,255,255,.3);padding:8px 0;">No profiles added yet.</div>';
    return;
  }

  list.innerHTML = savedProfiles.map((p, i) => {
    const ini = (p.name || p.username).split(' ').map(w => w[0] || '').join('').slice(0, 2).toUpperCase();
    return `<div class="pg-saved-item" data-idx="${i}">
      <div class="pg-saved-av">${ini}</div>
      <div class="pg-saved-name">@${p.username}</div>
      <div class="pg-saved-tag">GitHub</div>
    </div>`;
  }).join('');
}

function clearSaved() {
  if (!savedProfiles.length) return;
  if (!confirm('Clear all ' + savedProfiles.length + ' profiles from this list?')) return;
  savedProfiles = [];
  renderSavedList();
  syncToStorage();
}

function syncToStorage() {
  try {
    chrome.runtime.sendMessage({
      action:   'SYNC_GITHUB_PROFILES',
      profiles: savedProfiles,
    }).catch(() => {});
  } catch(e) {}
}

async function sendToOutreach() {
  if (!savedProfiles.length) {
    alert('Add at least one developer first.');
    return;
  }

  // Save to chrome storage as campaign profiles
  // Service worker will pick these up for Smart Outreach
  // NOTE: GitHub profiles don't have LinkedIn URLs yet —
  // user must find them via LinkedIn, then run Smart Outreach on LinkedIn profiles
  // Here we open the PingIN popup-triggered LinkedIn search instead

  const skills = [...new Set(savedProfiles.flatMap(p =>
    (p.bio || '').split(/[\s,]+/).slice(0, 2)
  ))].join(' ');

  const url = 'https://www.linkedin.com/search/results/people/?keywords=' +
    encodeURIComponent(skills) + '&origin=GLOBAL_SEARCH_HEADER';

  window.open(url, '_blank');
  alert('LinkedIn search opened for your saved developers skills.\nPingIN will collect profiles from LinkedIn — then run Smart Outreach from the extension.');
}
