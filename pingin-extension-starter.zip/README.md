# PingIN Chrome Extension v2.1.0
## How to Install for Testing (Load Unpacked)

### Step 1 — Extract
Unzip this file to a folder on your computer.
Example: C:\PingIN-Extension\ or ~/Desktop/PingIN-Extension/

### Step 2 — Open Chrome Extensions
Open Chrome browser → Type in address bar:
chrome://extensions

### Step 3 — Enable Developer Mode
Top right corner → Toggle ON "Developer mode"

### Step 4 — Load Unpacked
Click "Load unpacked" button → Select the extracted folder
(The folder that contains manifest.json)

### Step 5 — Pin the Extension
Click the puzzle icon (🧩) in Chrome toolbar → Pin PingIN

### Step 6 — Activate with License Key
Open PingIN → Go to Settings → Enter your license key
Format: PING-XX-XXXX-XXXX
- Free Trial:  PING-FR-XXXX-XXXX
- Starter:     PING-ST-XXXX-XXXX
- Pro:         PING-PR-XXXX-XXXX
- Annual:      PING-AN-XXXX-XXXX

### Testing on LinkedIn
1. Go to linkedin.com and log in
2. Click PingIN icon in toolbar
3. Try Smart Search, Clone Search, JD Search

### Features in this version (v2.1.0)
✅ Smart Search — AI Boolean search with filters
✅ Clone Search — Find similar profiles
✅ JD Search — Upload JD, find candidates
✅ Platform Search — Naukri, Indeed, Hirist
✅ Predictive Sourcing — Passive candidate finder
⏳ Salary Intelligence — Coming Soon (disabled)

### Support
Website: pingin.in
Email: support@pingin.in
