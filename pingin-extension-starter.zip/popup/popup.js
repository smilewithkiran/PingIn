'use strict';
// PingIN v2.0 — India's Talent Search Engine

const TRIAL_DAYS   = 5;
const TRIAL_MSGS   = 5; // 5 messages/day for free trial

// ─────────────────────────────────────────────
//  State
// ─────────────────────────────────────────────
const S = {
  plan:'free', trialDaysLeft:5, trialMsgsLeft:5,
  planExpiry:null,
  profiles:[], sent:0, failed:0,
  lastSearchParams:{}, currentPage:1, totalPages:1,
  log:[], savedSearches:[], history:[],
  currentFilter: 'all',
  settings:{ randomDelay:true, bizHours:false, skipConnected:true },
};

// Avatar colour palette
const AV = [
  ['rgba(0,119,181,.25)','#5BB5FF'],
  ['rgba(124,58,237,.25)','#C084FC'],
  ['rgba(0,196,154,.2)', '#00C49A'],
  ['rgba(217,119,6,.2)', '#FCD34D'],
  ['rgba(219,39,119,.2)','#F9A8D4'],
  ['rgba(5,150,105,.2)', '#6EE7B7'],
  ['rgba(239,68,68,.2)', '#FCA5A5'],
  ['rgba(59,130,246,.2)','#93C5FD'],
];



const COMPANIES = [

  // ══ IT SERVICES / SOFTWARE ══════════════════════════════════
  "TCS","Infosys","Wipro","HCL Technologies","Tech Mahindra","LTIMindtree",
  "Mphasis","Hexaware","Coforge","Persistent Systems","Cyient","NIIT Technologies",
  "Zensar Technologies","Sonata Software","KPIT Technologies","Sasken Technologies",
  "Birlasoft","L&T Technology Services","Mastech Digital","3i Infotech",
  "Ramp Systems","Tata Elxsi","HARMAN India","Tata Technologies",
  "Mahindra Tech","Quess Corp","TeamLease","Randstad India","Adecco India",

  // ══ PRODUCT / INTERNET / UNICORNS ═══════════════════════════
  "Flipkart","Amazon India","Swiggy","Zomato","Ola","Uber India","Paytm",
  "PhonePe","Razorpay","CRED","Meesho","Nykaa","Groww","Zerodha","Angel One",
  "Freshworks","Zoho","BrowserStack","Postman","Chargebee","Hasura","Druva",
  "Icertis","Mindtickle","Whatfix","Highradius","MoEngage","CleverTap",
  "Locus","Darwinbox","Keka","greytHR","Zimyo","Springworks","HROne",
  "Urban Company","Licious","BigBasket","Dunzo","Rapido","Blinkit","Zepto",
  "OYO","MakeMyTrip","Yatra","Goibibo","ixigo","EaseMyTrip","Airbnb India",
  "PolicyBazaar","Acko","Digit Insurance","RenewBuy","Turtlemint","Coverfox",
  "Dream11","MPL","Games24x7","Gameskraft","WinZO","Nazara Technologies",
  "ShareChat","Moj","Josh","Dailyhunt","InShorts","Newslaundry",
  "Ninjacart","DeHaat","AgroStar","CropIn","FarMart","Waycool","Jai Kisan",
  "Practo","1mg","PharmEasy","Netmeds","Mfine","Portea","Pristyn Care",
  "Healthifyme","Cult.fit","Truemeds","Medikabazaar","Lybrate",
  "upGrad","Unacademy","Byju's","Simplilearn","Great Learning","Vedantu",
  "Leverage Edu","Sunstone","Classplus","Teachmint","ConveGenius",
  "Cars24","CarDekho","Spinny","Droom","OLX India","Quikr","magicbricks",
  "Housing.com","NoBroker","PropTiger","Square Yards","99acres","CommonFloor",
  "Ather Energy","Ola Electric","Hero Electric","Simple Energy","Bounce Infinity",
  "Porter","Shiprocket","Delhivery","Shadowfax","Rivigo","BlackBuck","Wahter",
  "Cashfree","PayU","CCAvenue","BillDesk","Juspay","Setu","Perfios","Finbox",
  "Jupiter","Fi Money","Slice","Uni Cards","OneCard","Smallcase","Kuvera",
  "INDmoney","Fisdom","Wealthdesk","Cube Wealth","Scripbox","Goalwise",
  "Open","RazorpayX","Zaggle","EnKash","Happay","Volopay","Expense Karo",
  "Lendingkart","Indifi","OfBusiness","Moglix","Udaan","Jumbotail","Zetwerk",
  "Stanza Living","Awfis","91springboard","WeWork India","Smartworks","IndiQube",
  "Mensa Brands","GlobalBees","Upscalio","10Club","Goat Brand Labs",
  "boAt","Noise","Boat Lifestyle","Fire-Boltt","Imagine Marketing","Zebronics",
  "Mamaearth","Plum","WOW Skin Science","Minimalist","Dot & Key","Sugar Cosmetics",
  "Lenskart","Fastrack","Titan Company","Manyavar","Fabindia","FabAlley",
  "Pepperfry","Urban Ladder","IKEA India","HomeLane","Livspace","Furlenco",
  "Dunzo Daily","Swiggy Instamart","BB Now","Zepto","Blinkit","Milkbasket",

  // ══ BANKING / NBFC / FINTECH ════════════════════════════════
  "HDFC Bank","ICICI Bank","SBI","Axis Bank","Kotak Mahindra Bank",
  "Yes Bank","IndusInd Bank","Punjab National Bank","Bank of Baroda",
  "Canara Bank","Union Bank","Federal Bank","RBL Bank","South Indian Bank",
  "IDFC First Bank","Bandhan Bank","AU Small Finance Bank","Ujjivan SFB",
  "Suryoday SFB","Jana SFB","Equitas SFB","ESAF SFB","FINCARE SFB",
  "HDFC Life","SBI Life","ICICI Prudential","Max Life","Bajaj Allianz",
  "LIC","Birla Sun Life","Tata AIA","Reliance Nippon Life","PNB MetLife",
  "HDFC AMC","SBI Mutual Fund","ICICI Prudential AMC","Nippon India AMC",
  "Mirae Asset","Axis Mutual Fund","UTI AMC","Aditya Birla Sun Life AMC",
  "Bajaj Finance","Bajaj Finserv","Muthoot Finance","Manappuram Finance",
  "Shriram Finance","Cholamandalam","HDB Financial","Aditya Birla Finance",
  "IIFL Finance","Mahindra Finance","L&T Finance","Tata Capital","Piramal Finance",
  "Home First Finance","Aavas Financiers","Aptus Housing","Can Fin Homes",
  "Paytm Payments Bank","Airtel Payments Bank","Jio Payments Bank",
  "NSDL","CDSL","NSE","BSE","MCX","SEBI",

  // ══ CONSULTING / BIG 4 / MNC ════════════════════════════════
  "Deloitte","PwC","EY","KPMG","McKinsey","BCG","Bain & Company",
  "Accenture","Capgemini","CGI","Cognizant","IBM India","Oracle India",
  "SAP India","Microsoft India","Google India","Amazon Web Services",
  "Salesforce India","Adobe India","Cisco India","Intel India","Qualcomm India",
  "Gartner India","Forrester","IDC India","Dun & Bradstreet","CRISIL",
  "Grant Thornton","RSM India","BDO India","MSKA & Associates",
  "Alvarez & Marsal","Kroll","Ankura","AlixPartners",

  // ══ GCC / GLOBAL CAPABILITY CENTRES ════════════════════════
  "Goldman Sachs","JPMorgan","Citibank","Deutsche Bank","Barclays","HSBC",
  "Morgan Stanley","Bank of America","Wells Fargo","Credit Suisse","UBS",
  "BNY Mellon","State Street","Northern Trust","Fidelity India","Vanguard India",
  "Shell India","BP India","ExxonMobil","Chevron","Honeywell India",
  "GE India","Siemens India","Bosch India","ABB India","Schneider Electric",
  "3M India","Caterpillar India","Cummins India","Rockwell Automation",
  "UnitedHealth","Optum","Aetna","Cigna","Anthem","Humana","Elevance",
  "AstraZeneca India","Novartis India","Pfizer India","Abbott India",
  "Johnson & Johnson","Sanofi India","GSK India","Merck India","Roche India",
  "Philips India","GE Healthcare","Siemens Healthineers","Medtronic",
  "Becton Dickinson","Baxter India","Stryker India","Zimmer Biomet",
  "Target India","Walmart India","Flipkart (Walmart)","Gap India","Macy's India",
  "American Express India","Mastercard India","Visa India","PayPal India",
  "Apple India","Meta India","Netflix India","Spotify India","Twitter India",
  "Uber India","Airbnb India","booking.com India","Agoda India",
  "Fiserv India","FIS India","SS&C India","Broadridge India","Finastra",
  "Refinitiv","Bloomberg India","S&P Global India","Moody's India","MSCI India",
  "Conduent","Concentrix","Teleperformance","WNS","EXL Service","Genpact",
  "iGate","Syntel","Mphasis","NIIT Technologies","Hexaware","Firstsource",
  "Sutherland","Hinduja Global","Aegis BPO","iEnergizer","Startek","SITEL",

  // ══ MANUFACTURING / AUTO / CORE INDUSTRIES ═════════════════
  "Tata Motors","Mahindra & Mahindra","Maruti Suzuki","Hero MotoCorp",
  "Bajaj Auto","TVS Motor","Ashok Leyland","Eicher Motors","Force Motors",
  "Honda India","Toyota India","Hyundai India","Kia India","Skoda India",
  "MG Motor","BMW India","Mercedes India","Audi India","Volkswagen India",
  "Tata Steel","JSW Steel","SAIL","NMDC","Vedanta","Hindalco","Nalco",
  "Larsen & Toubro","BHEL","HAL","DRDO","ISRO","ONGC","Indian Oil",
  "BPCL","HPCL","Reliance Industries","Essar Oil","Castrol India",
  "Gujarat Gas","Mahanagar Gas","IGL","GAIL","Petronet LNG","Torrent Gas",
  "Tata Power","Adani Power","JSW Energy","NTPC","Power Grid","CESC",
  "Thermax","Crompton Greaves","Havells","Finolex Cables","Polycab",
  "Kirloskar","Cummins India","Grindwell Norton","Carborundum Universal",
  "UltraTech Cement","ACC","Ambuja","Shree Cement","Dalmia Bharat",
  "Asian Paints","Berger Paints","Kansai Nerolac","Akzo Nobel India",
  "Pidilite Industries","Astral Pipes","Supreme Industries","Nilkamal",

  // ══ TELECOM / MEDIA / ENTERTAINMENT ════════════════════════
  "Jio","Airtel","Vodafone Idea","BSNL","MTNL","Tata Communications",
  "Tata Play","Dish TV","Hathway","Den Networks",
  "Zee Entertainment","Sony India","Star India","Times of India","HT Media",
  "NDTV","ABP News","TV18","Network18","India Today","News18",
  "Sony Music India","T-Series","Saregama","Tips Music",
  "PVR Inox","Cinepolis","INOX Leisure","Carnival Cinemas",
  "Hotstar","JioCinema","SonyLIV","Zee5","MX Player","Voot","ALTBalaji",
  "Spotify India","Gaana","JioSaavn","Wynk Music","Amazon Music India",

  // ══ RETAIL / E-COMMERCE / FMCG ══════════════════════════════
  "Reliance Retail","DMart","Tata Retail","Future Group","Shoppers Stop",
  "Hindustan Unilever","P&G India","Nestle India","ITC","Dabur","Godrej Consumer",
  "Marico","Emami","Colgate","Britannia","Parle","Haldirams","Amul",
  "Mother Dairy","Patanjali","Tata Consumer Products","MDH","Everest","Catch",
  "Arvind Fashions","Raymond","Madura Fashion","ABFRL","Vedant Fashions",
  "Titan","Tanishq","Kalyan Jewellers","Malabar Gold","PC Jeweller",
  "Walmart India","Reliance Fresh","More Supermarket","Spencer's Retail",
  "Decathlon India","Skechers India","Nike India","Adidas India","Puma India",
  "Myntra","Ajio","Snapdeal","Tata Cliq","JioMart","Paytm Mall",

  // ══ PHARMA / HEALTHCARE / LIFE SCIENCES ═════════════════════
  "Sun Pharma","Dr Reddy's","Cipla","Lupin","Aurobindo Pharma","Cadila Healthcare",
  "Torrent Pharma","Alkem Laboratories","Ipca Laboratories","Natco Pharma",
  "Biocon","Serum Institute","Bharat Biotech","Zydus Lifesciences",
  "Strides Pharma","Gland Pharma","Granules India","Jubilant Pharmova",
  "Metropolis Healthcare","Dr Lal PathLabs","SRL Diagnostics","Thyrocare",
  "Fortis Healthcare","Apollo Hospitals","Max Healthcare","Narayana Health",
  "Manipal Hospitals","Aster DM Healthcare","Columbia Asia","Cloudnine",
  "Medanta","Wockhardt","Shalby Hospitals","NH Health","Rainbow Hospitals",
  "Agilus Diagnostics","Neuberg Diagnostics","Healthspring","Medica Synergie",

  // ══ EDUCATION / EDTECH ══════════════════════════════════════
  "Byju's","Unacademy","upGrad","Simplilearn","Great Learning","Vedantu",
  "Leverage Edu","Sunstone","Classplus","Teachmint","ConveGenius","Doubtnut",
  "Toppr","WhiteHat Jr","Coding Ninjas","Newton School","Scaler","iNeuron",
  "Aptech","NIIT","Jaro Education","Manipal Global","Amity Online",
  "Times Pro","Emeritus","Coursera India","Udemy India","EduBridge",

  // ══ REAL ESTATE / PROPTECH ══════════════════════════════════
  "DLF","Godrej Properties","Lodha Group","Prestige Estates","Sobha Realty",
  "Brigade Group","Embassy Group","Phoenix Mills","Oberoi Realty","Kolte Patil",
  "Mahindra Lifespaces","Puravankara","Shriram Properties","NBCC","L&T Realty",
  "NoBroker","Housing.com","PropTiger","Square Yards","magicbricks","99acres",
  "Anarock","CBRE India","JLL India","Savills India","Knight Frank India",

  // ══ LOGISTICS / SUPPLY CHAIN ════════════════════════════════
  "Delhivery","Blue Dart","DTDC","Ecom Express","XpressBees","Shadowfax",
  "Rivigo","BlackBuck","Porter","Shiprocket","ShipBob India","Pickrr",
  "Maersk India","DHL India","FedEx India","UPS India","TNT India",
  "DB Schenker India","Kuehne + Nagel India","Agility India","Geodis India",
  "GATI","Safexpress","TCI Express","Redington India","Ingram Micro India",
  "Mahindra Logistics","TVS Supply Chain","Allcargo Logistics","Blue Dart",

  // ══ FOOD & BEVERAGE / QSR ═══════════════════════════════════
  "McDonald's India","KFC India","Pizza Hut India","Domino's India",
  "Burger King India","Subway India","Starbucks India","Cafe Coffee Day",
  "Barbeque Nation","Jubilant FoodWorks","Devyani International",
  "Westlife Foodworld","Sapphire Foods","Restaurant Brands Asia",
  "Zomato","Swiggy","Rebel Foods","Freshmenu","EatFit","Box8","Faasos",

  // ══ HOSPITALITY / TRAVEL ════════════════════════════════════
  "Taj Hotels (IHCL)","The Leela","Hyatt India","Marriott India","Hilton India",
  "ITC Hotels","Oberoi Hotels","Radisson India","Lemon Tree Hotels",
  "OYO","FabHotels","Treebo","Zostel","Vista Rooms","WelcomHeritage",
  "MakeMyTrip","Yatra","Goibibo","ixigo","EaseMyTrip","IRCTC","Cleartrip",
  "Thomas Cook India","Cox & Kings","SOTC Travel","Kesari Tours",

  // ══ AGRICULTURE / AGRITECH ══════════════════════════════════
  "Ninjacart","DeHaat","AgroStar","CropIn","FarMart","Waycool","Jai Kisan",
  "Bijak","WayCool","Agrizy","Samunnati","Arya Collateral","Otipy",
  "ITC Agribusiness","Mahindra Agri","Bayer India","Syngenta India",
  "PI Industries","UPL","Coromandel International","Chambal Fertilisers",
  "National Fertilizers","Rashtriya Chemicals","Gujarat Narmada Valley",

  // ══ ELECTRIC VEHICLES / CLEANTECH ══════════════════════════
  "Ather Energy","Ola Electric","Hero Electric","Simple Energy","Revolt Motors",
  "Bounce Infinity","Okinawa","Ampere Vehicles","Greaves Electric",
  "Tata Motors EV","MG Motor India","Hyundai India EV",
  "Exide Industries","Amara Raja Batteries","Luminous Power","Okaya Power",
  "Waaree Energies","Adani Green","Greenko","ReNew Power","Azure Power",
  "Fourth Partner Energy","Cleantech Solar","CleanMax Solar","Engie India",

  // ══ CYBERSECURITY / SAAS / DEEPTECH ════════════════════════
  "Quick Heal","Seqrite","Palo Alto India","Fortinet India","CrowdStrike India",
  "Trellix","Sophos India","Kaspersky India","McAfee India","Trend Micro India",
  "Darktrace India","SentinelOne India","Check Point India","Qualys India",
  "Sprinklr","Freshdesk","Zendesk India","ServiceNow India","Workday India",
  "Informatica India","MuleSoft India","Boomi India","Talend India",
  "UiPath India","Automation Anywhere India","Blue Prism","WorkFusion",
  "ThoughtSpot","DataStax","Cloudera India","Databricks India","Snowflake India",
  "Fractal Analytics","Mu Sigma","LatentView","Tiger Analytics","Innominds",
  "Sigmoid","TheMathCompany","Bridgei2i","Crayon Data","Subex",

  // ══ AEROSPACE / DEFENCE ═════════════════════════════════════
  "HAL","DRDO","ISRO","BEL","BDL","BEML","MIDHANI","Ordnance Factory",
  "Tata Advanced Systems","Mahindra Defence","L&T Defence","Boeing India",
  "Airbus India","Safran India","Thales India","BAE Systems India",
  "Collins Aerospace India","Honeywell Aerospace India","GE Aviation India",

  // ══ MEDIA / PUBLISHING / ADVERTISING ═══════════════════════
  "WPP India","Publicis India","Omnicom India","IPG India","Dentsu India",
  "Ogilvy India","JWT India","Leo Burnett","Grey India","McCann India",
  "Madison World","Interactive Avenues","Isobar","Schbang","Social Beat",
  "iProspect","Performics","Mirum India","Digital Vidya","WATConsult",
  "GroupM India","Mindshare","Wavemaker","MediaCom","Essence","Kinetic",
  "Rediffusion","Lowe Lintas","BBDO India","DDB Mudra","Contract India",

  // ══ HR TECH / RECRUITMENT / STAFFING ═══════════════════════
  "Naukri.com","LinkedIn India","Indeed India","Monster India","Apna",
  "Hirect","iimjobs","Hirist","Internshala","Firstnaukri","Foundit",
  "TeamLease","Quess Corp","Manpower India","Kelly Services India",
  "Randstad India","Adecco India","Capita India","Sapient Staffing",
  "PeopleStrong","Aon India","Mercer India","Willis Towers Watson India",
  "Korn Ferry India","Spencer Stuart India","Egon Zehnder India","Heidrick",
  "Michael Page India","Randstad India","Hudson India","ABC Consultants",

  // ══ LEGAL TECH / COMPLIANCE ═════════════════════════════════
  "LegalKart","Vakil Search","MyAdvo","NoBroker Legal","LawTrade",
  "Legistify","SeedLegals India","Munim","Razorpay Compliance","Signzy",
  "IDfy","Digilocker","Aadhaar Bridge","Bureau","AuthBridge",
];







// ═══════════════════════════════════════════════════════════════
//  SCREEN NAVIGATION
// ═══════════════════════════════════════════════════════════════
function showScreen(screenId, animation='slide-in') {
  document.querySelectorAll('.screen').forEach(s => {
    s.classList.remove('active','slide-in','slide-back','slide-up');
  });
  const target = document.getElementById(screenId);
  if (!target) return;
  target.classList.add('active', animation);
  // When going back to home, hide collect button and scrape info
  if (screenId === 'screen-home') {
    const si = document.getElementById('scrape-info');
    if (si) si.classList.remove('show');
  }
}

function initNavigation() {
  // Home → search screens
  document.querySelectorAll('.search-card[data-screen]').forEach(function(card) {
    card.addEventListener('click', function() {
      if (card._pinginAccess === false) {
        var proOnlyScreens = ['screen-github','screen-stackoverflow','screen-company'];
        var needPlan = proOnlyScreens.indexOf(card.dataset.screen) > -1 ? 'Pro' : 'Starter';
        showStatus('Upgrade to ' + needPlan + ' to unlock this search mode. Visit pingin.in/pricing.html', 'warning');
        return;
      }
      if(card.dataset.screen === 'screen-salary') { showScreen('screen-salary','slide-in'); return; }
      showScreen(card.dataset.screen, 'slide-in');
    });
  });

  // Stack Overflow screen navigation
  document.getElementById('card-stackoverflow')?.addEventListener('click', () => {
    showScreen('screen-stackoverflow', 'slide-in');
  });

  // Back buttons
  document.querySelectorAll('.back-btn[data-back]').forEach(btn => {
    btn.addEventListener('click', () => {
      showScreen(btn.dataset.back, 'slide-back');
    });
  });

  // Settings button in header
  document.getElementById('btn-go-settings')?.addEventListener('click', () => {
    showScreen('screen-settings', 'slide-in');
  });

  // Upgrade button
  document.getElementById('plan-bar-upgrade')?.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://pingin.in/pricing.html', active: true });
  });

  // Status bar profile buttons → go to profiles screen
  ['sb-profiles-btn','sb-view-btn','smart-view-btn','smart-view-btn-inline','clone-view-btn',
   'jd-view-btn','pred-view-btn'].forEach(id => {
    document.getElementById(id)?.addEventListener('click', () => {
      showScreen('screen-profiles', 'slide-up');
    });
  });

  // Status bar profile count clicks
  document.getElementById('sb-profiles-btn')?.addEventListener('click', () => {
    if (S.profiles.length > 0) showScreen('screen-profiles','slide-up');
  });
}

function updateAllCounts() {
  const count = S.profiles.length;
  const hot = S.profiles.filter(p => {
    const sc = scoreProfile(p, S.lastSearchParams);
    return sc >= 75;
  }).length;
  
  ['sb-count','smart-sb-count','clone-sb-count','jd-sb-count','pred-sb-count'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = count;
  });
  var _afs=document.getElementById('smart-after-search');
  var _ic=document.getElementById('smart-inline-count');
  if(_afs) _afs.style.display=count>0?'block':'none';
  if(_ic) _ic.textContent=count;
  document.getElementById('stat-profiles') && (document.getElementById('stat-profiles').textContent = count);
  document.getElementById('stat-hot') && (document.getElementById('stat-hot').textContent = hot);
  updateTopProfiles();
}


// ── Top Profiles Summary — shown when ≥3 profiles ────────────
function updateTopProfiles() {
  const banner = document.getElementById('top-profiles-banner');
  const list   = document.getElementById('top-profiles-list');
  if (!banner || !list) return;

  const total = S.profiles.length;

  // Always update count in header
  const hdr = document.getElementById('profiles-count');
  if (hdr) hdr.textContent = total + ' profile' + (total!==1?'s':'') + (S.lastSearchParams?.keywords ? ' · "'+S.lastSearchParams.keywords+'"' : '');

  // Only show top banner if ≥3 profiles
  if (total < 3 || !S.lastSearchParams) {
    banner.style.display = 'none';
    return;
  }

  // Score and sort all profiles
  const scored = S.profiles
    .map(p => ({ ...p, _score: scoreProfile(p, S.lastSearchParams) }))
    .sort((a,b) => b._score - a._score)
    .slice(0, 3); // top 3

  const SCORE_COLORS = [
    { min:90, color:'#FF7055', label:'🔥 Hot' },
    { min:75, color:'#5BB5FF', label:'⭐ Strong' },
    { min:60, color:'#00C49A', label:'✅ Good' },
    { min:0,  color:'#D97706', label:'👍 Fair' },
  ];

  const getScoreStyle = (sc) => SCORE_COLORS.find(c => sc >= c.min) || SCORE_COLORS[3];

  list.innerHTML = scored.map((p, i) => {
    const isPro2  = ['pro','annual'].includes(S.plan);
    const sc    = isPro2 ? (p._score || 0) : 0;
    const style = isPro2 ? getScoreStyle(sc) : {color:'#4A4E62',label:'🔒 Pro'};
    const name  = cleanScrapedName(p.name || 'Unknown');
    const role  = p.role || p.company || '—';
    const initials = name.split(' ').map(n=>n[0]||'').join('').slice(0,2).toUpperCase();
    return `<div class="top-profile-card" data-url="${p.profileUrl||''}" style="display:flex;align-items:center;gap:9px;padding:6px 8px;background:rgba(255,255,255,.03);border-radius:7px;cursor:pointer;">
      <div style="width:28px;height:28px;border-radius:50%;background:rgba(0,119,181,.25);color:#5BB5FF;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;flex-shrink:0">${initials}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:11px;font-weight:600;color:var(--tp);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${name}${p.isOTW?'<span style="font-size:9px;background:rgba(0,196,154,.15);color:#00C49A;border-radius:3px;padding:1px 4px;margin-left:4px">OTW</span>':''}</div>
        ${p._reason ? `<div style="font-size:10px;color:var(--ts);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${p._reason}</div>` : (role ? `<div style="font-size:10px;color:var(--ts);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${role}</div>` : '')}
        ${p._strengths ? `<div style="font-size:9px;color:#00d4aa;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:1px;">✓ ${p._strengths}</div>` : ''}
        ${p._gaps ? `<div style="font-size:9px;color:#f87171;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:1px;">△ ${p._gaps}</div>` : ''}
      </div>
      <div style="font-size:11px;font-weight:800;color:${style.color};flex-shrink:0">${sc}</div>
    </div>`;
  }).join('');

  banner.style.display = 'block';
}


function delay(ms){return new Promise(r=>setTimeout(r,ms));}


function waitTabLoad(tabId, cb) {
  let fired = false;
  const fn = (id, info) => {
    if (id === tabId && info.status === 'complete') {
      chrome.tabs.onUpdated.removeListener(fn);
      if (!fired) { fired=true; cb(); }
    }
  };
  chrome.tabs.onUpdated.addListener(fn);
  // Timeout fallback after 12 seconds
  setTimeout(() => {
    chrome.tabs.onUpdated.removeListener(fn);
    if (!fired) { fired=true; cb(); }
  }, 12000);
}


function addLog(msg){const t=new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'});S.log.unshift({t,msg});if(S.log.length>50)S.log.pop();chrome.storage.local.set({log:S.log});renderLog();}


async function showStatus(msg,type='success'){
  const icons={success:'✓',warning:'⚠',error:'✗',info:'ℹ'};
  const box=document.getElementById('status-box');
  box.className='info-box '+type;
  box.innerHTML=`<span style="font-weight:700">${icons[type]||''}</span> ${msg}`;
  box.style.display='flex';
}


async function saveToHistory(params){
  S.history=S.history.filter(h=>h.keywords!==params.keywords);
  S.history.unshift(params);
  if(S.history.length>15)S.history.pop();
  await chrome.storage.local.set({searchHistory:S.history});
}


function updateProfileTypeState(){
  const pt = document.getElementById('s-profile-type');
  if (pt) pt.disabled = false;
  const ptHint = document.getElementById('pt-hint');
  if (ptHint) ptHint.style.display = 'none';
}


function resetSearchBtn(){
  const btn=document.getElementById('btn-search');
  btn.disabled=false;
  btn.innerHTML='<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="M20 20l-3-3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg> Search';
}


function extractLinkedInUsername(url) {
  url = url.trim();
  const match = url.match(/(?:linkedin\.com\/in\/|^\/in\/)([a-zA-Z0-9\-_%]+)/i);
  return match ? match[1] : null;
}

// Extract a clean human name from a LinkedIn slug for searching
// Strips trailing numeric/alphanumeric identifiers LinkedIn auto-appends
// Examples:
//   sundeep-are-ba06706       → "sundeep are"
//   deeksha-shetty-a-3a943265 → "deeksha shetty"
//   rahul-sharma-product      → "rahul sharma product"  (no strip - real word)
//   satya-nadella             → "satya nadella"
function cleanNameFromSlug(slug) {
  if (!slug) return '';

  // Remove URL encoding
  slug = decodeURIComponent(slug).toLowerCase();

  // Split on hyphens
  const parts = slug.split('-').filter(Boolean);
  if (!parts.length) return slug;

  // Detect if a part is a LinkedIn auto-ID:
  // Rules: contains any digit AND (is all alphanumeric with digits OR looks like a hex code)
  // Examples of IDs: ba06706, 3a943265, a12b34, 8b921c
  // NOT IDs: product, manager, sr, lead, tech (no digits)
  function isAutoId(part) {
    // Must contain at least one digit
    if (!/[0-9]/.test(part)) return false;
    // Must be purely alphanumeric (no real word would be e.g. "ba06706")
    if (!/^[a-z0-9]+$/.test(part)) return false;
    // Single letters that happen to pair with a number (e.g. the lone "a" in "deeksha-shetty-a-3a943265")
    // are stripped if immediately followed by an ID
    return true;
  }

  // Work backwards — strip trailing ID segments
  let end = parts.length;
  while (end > 1 && isAutoId(parts[end-1])) {
    end--;
  }
  // Also strip a lone single-char part right before the ID (e.g. the "-a-" in deeksha-shetty-a-3a943265)
  while (end > 1 && parts[end-1].length === 1 && /^[a-z]$/.test(parts[end-1])) {
    end--;
  }

  // Take only the first 4 parts max (avoids very long slugs)
  // and only the meaningful ones
  const nameParts = parts.slice(0, end).slice(0, 4);

  return nameParts.join(' ').trim();
}


function buildCloneTags(profile, location, isTopSchool, experience) {
  const tags = [];
  const headline = profile.headline || '';
  const titlePart = headline.split(/\s*[|@·]\s*|\s+at\s+/i)[0].trim();
  if (titlePart) tags.push({ label: '💼 ' + titlePart, type: 'blue' });
  if (location)  tags.push({ label: '📍 ' + location,  type: 'green' });
  const EXP_LABELS = { '1':'0–1 yr', '2':'1–3 yrs', '3':'3–5 yrs', '4':'5–10 yrs', '5':'10+ yrs' };
  if (experience) tags.push({ label: '⏱ ' + (EXP_LABELS[experience]||''), type: 'amber' });
  if (isTopSchool && profile.school) tags.push({ label: '🎓 ' + profile.school, type: 'blue' });
  const skills = (profile.skills||[]).slice(0,3);
  skills.forEach(s => tags.push({ label: s, type: 'green' }));
  return tags;
}


function buildCloneSearchFromProfile(profile) {
  const cloneSearch = {};

  // Keywords — use job title from headline (clean extraction)
  const headline = profile.headline || '';

  // Extract JUST the job title — remove company info
  // Headlines like:
  //   "Senior Data Scientist at Google | IIT Bombay"      → "Senior Data Scientist"
  //   "Manager-Swadesh @ Reliance Retail | Supply Chain"  → "Manager Supply Chain"
  //   "Supply Chain Manager | Retail | Fintech"           → "Supply Chain Manager"
  let titlePart = '';
  if (headline) {
    // Strategy 1: Take everything before @ or |, clean up brand/product names
    let raw = headline
      .split(/\s*[@|·]\s*|\s+at\s+/i)[0]
      .replace(/^(i am|currently|working as|looking for)/i, '')
      .trim();

    // Strategy 2: If raw contains a hyphen followed by a brand name (e.g. "Manager-Swadesh"),
    // check if the part after hyphen looks like a brand (capitalised non-job-word)
    // In that case take the part before the hyphen as the base role
    const JOB_WORDS = /^(manager|engineer|developer|analyst|lead|director|head|officer|specialist|consultant|associate|executive|senior|junior|principal|architect|designer|scientist|recruiter|coordinator|assistant|intern|vp|cto|ceo|cfo|coo|supply|software|data|product|talent|global|strategic|seasoned|technical|business|operations|finance|marketing|sales|growth|hr|human|ai|ml|cloud|devops|fullstack|frontend|backend|platform|infra|security|mobile|ios|android|qa|sre|quant|enterprise|generative|learning|capability|transformation|enablement|workforce|acquisition|resources)/i;
    if (raw.includes('-')) {
      const hparts = raw.split('-').map(p => p.trim()).filter(Boolean);
      if (hparts.length >= 2) {
        const firstPart = hparts[0].trim();
        const secondPart = hparts[1].trim();
        // If first part is a complete job title (has job word AND is reasonable length)
        // AND second part looks like a company/brand name → take only first part
        const firstHasJob = JOB_WORDS.test(firstPart.split(/\s+/)[0]);
        const secondLooksLikeBrand = /^[A-Z]/.test(secondPart) && !JOB_WORDS.test(secondPart.split(/\s+/)[0]);
        if (firstHasJob && (secondLooksLikeBrand || firstPart.split(/\s+/).length >= 2)) {
          raw = firstPart;
        } else if (!JOB_WORDS.test(firstPart.split(/\s+/)[0]) && JOB_WORDS.test(secondPart.split(/\s+/)[0])) {
          // "Swadesh-Manager" pattern → take second part
          raw = secondPart;
        }
        // else keep raw as-is (e.g. single word + single word both non-job)
      }
    }

    // Strategy 3: prefer richer/longer segment over bare single job word
    // "Manager" alone is useless — "Supply Chain Manager" is better
    const rawWords = raw.trim().split(/\s+/);
    const allSegs2 = headline.split(/\s*[@|·]\s*|\s+at\s+/i).map(s => s.trim()).filter(Boolean);
    if (rawWords.length <= 1) {
      // Single-word result is useless — skip first segment, find better one
      // e.g. "Manager-Swadesh" gave "Manager" → find "Supply Chain and CE Control Tower"
      var bestSeg = '';
      var bestLen = 0;
      for (var si = 0; si < allSegs2.length; si++) {
        var s2 = allSegs2[si].replace(/-/g,' ').trim();
        var words2 = s2.split(/\s+/).filter(Boolean);
        // Must have 2+ words, contain a job word, and be longer than current best
        if (words2.length >= 2 && words2.some(function(w){ return JOB_WORDS.test(w); })) {
          // Prefer segments that START with a job word (cleaner titles)
          if (JOB_WORDS.test(words2[0]) && s2.length > bestLen) {
            bestSeg = s2; bestLen = s2.length;
          } else if (!bestSeg && s2.length > bestLen) {
            bestSeg = s2; bestLen = s2.length;
          }
        }
      }
      if (bestSeg) raw = bestSeg;
    } else if (!JOB_WORDS.test(raw.split(/\s+/)[0])) {
      // First word not a job word — look for better segment
      for (var si2 = 0; si2 < allSegs2.length; si2++) {
        var s3 = allSegs2[si2].trim();
        if (JOB_WORDS.test(s3.split(/\s+/)[0]) && s3.length > 3) {
          raw = s3; break;
        }
      }
    }

    titlePart = raw.trim();
  }

  if (titlePart.length > 60) titlePart = titlePart.substring(0, 60);

  // If no title from headline, try extracting from company context
  // e.g. if headline was empty but we have "Deeksha Shetty" → don't search by name
  // Instead try to infer a generic role from any available data
  if (!titlePart && profile.skills && profile.skills.length > 0) {
    // Use top skill as keyword proxy
    titlePart = profile.skills[0];
  }

  let keywords = titlePart ? `"${titlePart}"` : '';

  // Company
  const company = profile.company || '';

  // Location mapping
  const LOC_MAP = {
    'bengaluru': 'Bengaluru', 'bangalore': 'Bengaluru',
    'mumbai': 'Mumbai', 'bombay': 'Mumbai',
    'hyderabad': 'Hyderabad', 'secunderabad': 'Hyderabad',
    'delhi': 'Delhi NCR', 'new delhi': 'Delhi NCR', 'gurgaon': 'Gurgaon',
    'noida': 'Noida', 'pune': 'Pune', 'chennai': 'Chennai',
    'kolkata': 'Kolkata', 'ahmedabad': 'Ahmedabad', 'jaipur': 'Jaipur',
  };
  let location = '';
  const locLower = (profile.location || '').toLowerCase();
  for (const [key, val] of Object.entries(LOC_MAP)) {
    if (locLower.includes(key)) { location = val; break; }
  }

  // School/college tier
  const school = (profile.school || '').toLowerCase();
  const TOP_SCHOOLS = ['iit', 'iim', 'iiit', 'bits', 'nit', 'xlri', 'isb', 'fms', 'sp jain', 'mdi'];
  const isTopSchool = TOP_SCHOOLS.some(s => school.includes(s));

  // Experience level guess
  let experience = '';
  const expCount = profile.experienceCount || 0;
  if (expCount >= 4) experience = '4'; // 5-10 yrs
  else if (expCount >= 3) experience = '3'; // 3-5 yrs
  else if (expCount >= 2) experience = '2'; // 1-3 yrs
  else if (expCount >= 1) experience = '1'; // 0-1 yr

  // Build skills keywords to add
  const skills = (profile.skills || []).slice(0,3);
  if (skills.length > 0 && keywords) {
    keywords += ' AND (' + skills.map(s => `"${s}"`).join(' OR ') + ')';
  }

  return {
    keywords,
    company: '',      // don't lock to same company — find similar people elsewhere
    location,
    experience,
    school: isTopSchool ? profile.school : '',
    isTopSchool,
    profileData: profile,
    tags: buildCloneTags(profile, location, isTopSchool, experience),
  };
}


function scoreProfile(p, searchParams) {
  let score = 0;

  // ── 1. Role Title Match (35 pts) — PRIMARY scoring factor ──
  // This is what we CAN check from LinkedIn search results
  const role    = (p.role    || '').toLowerCase();
  const company = (p.company || '').toLowerCase();
  const name    = (p.name    || '').toLowerCase();
  const kw      = ((searchParams?.keywords || '') + ' ' + (searchParams?.jobTitle || '')).toLowerCase();

  if (kw.trim()) {
    // Extract meaningful words (3+ chars, no boolean operators)
    const kwWords = kw
      .replace(/["()]/g, '')
      .replace(/(and|or|not)/gi, '')
      .split(/\s+/)
      .filter(w => w.length >= 3);

    // Check how many keywords appear in role title
    const roleMatches = kwWords.filter(w => role.includes(w));
    const coMatches   = kwWords.filter(w => company.includes(w));

    if (roleMatches.length >= 3)      score += 35;
    else if (roleMatches.length >= 2) score += 28;
    else if (roleMatches.length >= 1) score += 18;
    else if (coMatches.length >= 1)   score += 8;
    else                              score += 5; // profile shown but no match
  } else {
    score += 20; // no keyword = neutral bonus
  }

  // ── 2. Open to Work (25 pts) ─────────────────────────────
  if (p.isOTW) score += 25;

  // ── 3. Connection Degree (20 pts) ────────────────────────
  // LinkedIn shows: "1st", "2nd", "3rd+" in degree field
  const deg = (p.degree || '').trim();
  if      (deg === '1st' || deg.startsWith('1'))  score += 20;
  else if (deg === '2nd' || deg.startsWith('2'))  score += 13;
  else if (deg === '3rd' || deg.startsWith('3'))  score += 6;
  else if (deg)                                    score += 3;

  // ── 4. Company Tier (15 pts) ──────────────────────────────
  // Use partial matching — company field may contain extra text
  const TIER1 = ['google','microsoft','amazon','meta','apple','netflix','stripe','uber','goldman','jpmorgan','mckinsey','bcg','atlassian'];
  const TIER2 = ['flipkart','razorpay','zerodha','swiggy','zomato','cred','meesho','freshworks','zoho','phonepe','paytm','ola','byjus','unacademy','browserstack'];
  const TIER3 = ['tcs','infosys','wipro','hcl','capgemini','accenture','cognizant','ibm','tech mahindra','l&t','mindtree'];
  if      (TIER1.some(t => company.includes(t))) score += 15;
  else if (TIER2.some(t => company.includes(t))) score += 11;
  else if (TIER3.some(t => company.includes(t))) score += 6;
  else if (company.length > 2)                   score += 3;

  // ── 5. Location Match (5 pts bonus) ──────────────────────
  const loc    = (p.city || p.location || '').toLowerCase();
  const wantLoc = (searchParams?.location || '').toLowerCase();
  if (wantLoc && loc && (loc.includes(wantLoc) || wantLoc.includes(loc.split(',')[0]))) {
    score += 5;
  }

  return Math.min(100, Math.max(5, score));
}


function getScoreClass(score) {
  if (score >= 90) return 'score-hot';
  if (score >= 75) return 'score-strong';
  if (score >= 60) return 'score-good';
  if (score >= 40) return 'score-ok';
  return 'score-weak';
}


function getScoreLabel(score) {
  if (score >= 90) return '🔥 ' + score;
  if (score >= 75) return '⭐ ' + score;
  if (score >= 60) return '✅ ' + score;
  if (score >= 40) return '👍 ' + score;
  return score.toString();
}

// ── Match quality label — based on role/skills/experience scoring ────────────
function getMatchLabel(score) {
  if (score >= 90) return 'Excellent match';
  if (score >= 75) return 'Strong match';
  if (score >= 60) return 'Good match';
  if (score >= 40) return 'Possible match';
  return 'Low match';
}


function buildSearchUrl(keywords,location,degree,experience,profileType,college,company,page=1,salaryRange='',diversityFilters=[]){

  // ── Location keyword map — exact city names (no broad OR chains) ─────────────
  const GEO_KW = {
    'Bengaluru':   'Bengaluru',
    'Hyderabad':   'Hyderabad',
    'Mumbai':      'Mumbai',
    'Navi Mumbai': '"Navi Mumbai"',
    'Thane':       'Thane',
    'Delhi':       'Delhi',
    'New Delhi':   '"New Delhi"',
    'Noida':       'Noida',
    'Gurgaon':     'Gurgaon',
    'Faridabad':   'Faridabad',
    'Ghaziabad':   'Ghaziabad',
    'Chennai':     'Chennai',
    'Pune':        'Pune',
    'Kolkata':     'Kolkata',
    'Ahmedabad':   'Ahmedabad',
    'Jaipur':      'Jaipur',
    'Kochi':       'Kochi',
    'Coimbatore':  'Coimbatore',
    'Chandigarh':  'Chandigarh',
    'Indore':      'Indore',
    'Lucknow':     'Lucknow',
    'Nagpur':      'Nagpur',
  };

  // ── Company IDs (currentCompany) — strict filter ─────────────────────────
  // These use LinkedIn's currentCompany URL param — shows ONLY current employees
  const COMPANY_IDS={
    // IT Services
    'tcs':'1353','tata consultancy services':'1353','tata consultancy':'1353',
    'infosys':'1283','wipro':'11502','hcl':'11985','hcl technologies':'11985',
    'tech mahindra':'46143','cognizant':'1025','accenture':'1033',
    'capgemini':'16086','ibm':'1009','mphasis':'4297','hexaware':'3522',
    'ltimindtree':'204924','l&t technology services':'5177562','mindtree':'14519',
    'persistent systems':'5668','zensar':'46166','niit technologies':'6907',
    'birlasoft':'27086','cyient':'88085','mastech':'17380',
    // Global Tech
    'google':'1441','microsoft':'1035','amazon':'1586','meta':'10667',
    'apple':'162479','netflix':'165158','uber':'19131','airbnb':'391850',
    'oracle':'1028','sap':'1085','salesforce':'3536','adobe':'1060',
    'cisco':'1063','intel':'1053','qualcomm':'1055','nvidia':'4682',
    'atlassian':'115989','workday':'9298','servicenow':'108414',
    // Indian Startups / Unicorns
    'flipkart':'2614906','swiggy':'3454793','zomato':'4553291',
    'razorpay':'3640647','cred':'18385468','phonepe':'6548767',
    'paytm':'1698217','ola':'5025282','nykaa':'3547984','meesho':'11384001',
    'byjus':'3636638','unacademy':'9367169','freshworks':'2130168',
    'zerodha':'5523716','groww':'10440458','browserstack':'1038196',
    'postman':'1658037','chargebee':'1044360','zoho':'672979',
    'browserstack':'1038196','miro':'16047533','hasura':'19177222',
    // Banking / Finance
    'hdfc':'3049','hdfc bank':'3049','icici bank':'3048','sbi':'3126',
    'axis bank':'3035','kotak mahindra bank':'9709',
    'goldman sachs':'1038','morgan stanley':'1040','jp morgan':'1067',
    'deloitte':'1038','kpmg':'1033',
    // Others
    'shell':'1004','honeywell':'4876','bosch':'1115','siemens':'1153',
    'ge':'1308','3m':'3085','p&g':'388','unilever':'16458','nestle':'3044',
    'mahindra':'47561','tata motors':'3025','bajaj auto':'3144',
    'reliance industries':'3026','infosys bpm':'35468',
  };

  // ── School/College IDs — strict filter ───────────────────────────────────
  const SCHOOL_IDS={
    // IITs
    'iit bombay':'15117','iit delhi':'15116','iit madras':'15122',
    'iit kanpur':'15115','iit kharagpur':'15121','iit roorkee':'3989',
    'iit hyderabad':'9000066','iit guwahati':'15119','iit bhu':'14826',
    // NITs
    'nit trichy':'14847','nit warangal':'14846','nit surathkal':'14840',
    'nit calicut':'14843','nit rourkela':'14848',
    // Premier colleges
    'bits pilani':'13359','bits':'13359','delhi university':'5946',
    'du':'5946','iim ahmedabad':'22165','iim bangalore':'22166',
    'iim calcutta':'22167','iim lucknow':'22168',
    'vit':'15259','vit vellore':'15259','srm':'20720','manipal':'15266',
    'anna university':'15123','jadavpur university':'15146',
    'pune university':'15269','mumbai university':'15267',
    'hyderabad university':'148407','osmania university':'15272',
    'nit':'14847', // default NIT = Trichy
    'iit':'15116', // default IIT = Delhi
  };

  // ── Experience filter map ─────────────────────────────────────────────────
  const EXP_MAP={'1':'1','2':'2','3':'3','4':'4','5':'5'};
  const NET={'1':['F'],'2':['S'],'3':['O'],'12':['F','S'],'23':['S','O'],'123':['F','S','O']};
  const EXP_KW={
    '6':'("10 years" OR "12 years" OR "15 years")',
    '7':'("15 years" OR "18 years" OR "20 years")',
    '8':'("20 years" OR "22 years" OR "25 years")',
    'intern':'"internship" OR "intern" OR "trainee"',
    'fresher':'"fresher" OR "entry level" OR "new graduate"',
  };
  const TYPE_KW={
    'open':'"open to work" OR "#opentowork"',
    'immediate':'"immediate joiner" OR "available immediately"',
    'looking':'"looking for change" OR "open to opportunities"',
    'layoff':'"laid off" OR "#opentowork" OR "between jobs"',
    'leadership':'"CEO" OR "CTO" OR "VP of Engineering" OR "Head of" OR "Director"',
    'gcc':'"GCC" OR "Global Capability Centre" OR "Global Capability Center"',
    'startup':'"startup" OR "Series A" OR "Series B" OR "unicorn"',
  };

  // ── Build keyword string (only for skills + profile type + exp) ──────────
  // Auto-quote plain keywords (no existing quotes or boolean operators)
  // "Business Analyst" → exact phrase — prevents Recruiter/TA false matches
  // "Senior DevOps Engineer" → exact phrase
  let raw = (keywords || '').trim();
  let kw  = raw;
  if (raw && !raw.includes('"') && !/\b(AND|OR|NOT)\b/.test(raw) && !raw.includes('(')) {
    kw = '"' + raw + '"';   // wrap as exact phrase
  }

  if(profileType && TYPE_KW[profileType])
    kw = kw ? `(${kw}) AND (${TYPE_KW[profileType]})` : TYPE_KW[profileType];

  if(experience && EXP_KW[experience])
    kw = kw ? `(${kw}) AND (${EXP_KW[experience]})` : EXP_KW[experience];

  // ── Diversity filters via keywords ───────────────────────────────────────
  const DIVERSITY_KW={
    'women':'"Women Who Code" OR "GirlScript" OR "#womenintech"',
    'tier2':'"Nashik" OR "Indore" OR "Coimbatore" OR "Bhubaneswar"',
    'returner':'"career break" OR "returnship" OR "return to work"',
    'veteran':'"Indian Army" OR "ex-serviceman" OR "armed forces"',
  };
  if(diversityFilters && diversityFilters.length>0){
    const divKws=diversityFilters.filter(f=>DIVERSITY_KW[f]).map(f=>`(${DIVERSITY_KW[f]})`);
    if(divKws.length>0){
      const combined=divKws.join(' OR ');
      kw=kw?`(${kw}) AND (${combined})`:combined;
    }
  }

  // ── Build base URL ────────────────────────────────────────────────────────
  const network = JSON.stringify(NET[degree||'123']||['F','S','O']);
  let url = `https://www.linkedin.com/search/results/people/?keywords=${encodeURIComponent(kw||'recruiter')}&network=${encodeURIComponent(network)}&origin=FACETED_SEARCH`;

  // ── Location: keyword-based approach (text input) ──────────────────────────
  // City text is added to keywords → LinkedIn ranks location-relevant profiles first
  // geoUrn added as bonus if city matches a known ID
  const GEO_IDS = {
    'Bengaluru':'105214831', 'Hyderabad':'105556105', 'Mumbai':'106164952',
    'Navi Mumbai':'106164952', 'Thane':'106164952',
    'Delhi':'100458144', 'New Delhi':'100458144', 'Noida':'106199869',
    'Gurgaon':'102140765', 'Faridabad':'100458144', 'Ghaziabad':'100458144',
    'Chennai':'106151043', 'Pune':'104869687', 'Kolkata':'104536289',
    'Ahmedabad':'106785562', 'Jaipur':'102671845', 'Kochi':'104863929',
    'Coimbatore':'114226483', 'Chandigarh':'103012526',
    'Indore':'104340783', 'Lucknow':'106967800', 'Nagpur':'103017793',
  };
  // Location text injected directly into keywords
  // Works with any city name (not limited to dropdown list)
  if (location && location.trim()) {
    const locTrimmed = location.trim();
    // Multi-word cities → auto-quote (e.g. "New Delhi", "Navi Mumbai")
    const locKw = locTrimmed.includes(' ') ? '"' + locTrimmed + '"' : locTrimmed;
    const curKw = decodeURIComponent(url.match(/keywords=([^&]*)/)?.[1] || '');
    const newKw = curKw ? '(' + curKw + ') ' + locKw : locKw;
    url = url.replace(/keywords=[^&]*/, 'keywords=' + encodeURIComponent(newKw));
    // Also try geoUrn as bonus if city matches a known ID
    const GEO_BONUS = {
      'Bengaluru':'105214831','Bangalore':'105214831',
      'Hyderabad':'105556105','Mumbai':'106164952',
      'Delhi':'100458144','New Delhi':'100458144','Noida':'106199869',
      'Gurgaon':'102140765','Gurugram':'102140765',
      'Chennai':'106151043','Pune':'104869687','Kolkata':'104536289',
    };
    const geoId = GEO_BONUS[locTrimmed];
    if (geoId) url += '&geoUrn=' + encodeURIComponent('["urn:li:geo:' + geoId + '"]');
  }

    // ── Company — use LinkedIn ID for strict filter, keyword as fallback ──────
  if(company){
    const companies = company.split(/\s+OR\s+/i).map(c=>c.trim().replace(/^"|"$/g,''));
    const knownIds  = companies.map(c=>COMPANY_IDS[c.toLowerCase()]).filter(Boolean);
    const unknownCo = companies.filter(c=>!COMPANY_IDS[c.toLowerCase()]);

    if(knownIds.length > 0){
      // Strict ID-based filter for known companies
      url += '&currentCompany=' + encodeURIComponent(JSON.stringify(knownIds));
    }
    if(unknownCo.length > 0){
      // Keyword fallback for unknown companies (exact quoted match)
      const coKw = unknownCo.length===1
        ? '"'+unknownCo[0]+'"'
        : '('+unknownCo.map(c=>'"'+c+'"').join(' OR ')+')';
      const existing = decodeURIComponent(url.match(/keywords=([^&]*)/)[1]);
      const newKw    = existing && existing !== 'recruiter' ? `(${existing}) AND ${coKw}` : coKw;
      url = url.replace(/keywords=[^&]*/, 'keywords='+encodeURIComponent(newKw));
    }
  }

  // ── College/School — strict ID-based filter ───────────────────────────────
  if(college){
    const schoolId = SCHOOL_IDS[college.toLowerCase()];
    if(schoolId){
      url += '&school=' + encodeURIComponent('["'+schoolId+'"]');
    } else {
      // Keyword fallback
      const existing = decodeURIComponent(url.match(/keywords=([^&]*)/)[1]);
      const colKw    = '"'+college+'"';
      const newKw    = existing && existing !== 'recruiter' ? `(${existing}) AND ${colKw}` : colKw;
      url = url.replace(/keywords=[^&]*/, 'keywords='+encodeURIComponent(newKw));
    }
  }

  // ── Experience ────────────────────────────────────────────────────────────
  if(experience && EXP_MAP[experience] && parseInt(experience)<=5)
    url += `&yearsOfExperience=${encodeURIComponent('[\"'+EXP_MAP[experience]+'\"]')}`;

  if(page>1) url += `&page=${page}`;
  return url;
}


async function extractFromJD(text) {
  // Route through Cloudflare Worker (has API key stored securely)
  try {
    const resp = await fetch(PINGIN_AI_WORKER, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'parseJD', jdText: text.substring(0, 3000) })
    });
    if (!resp.ok) throw new Error('Worker error: ' + resp.status);
    const data = await resp.json();
    if (!data.ok || !data.parsed) throw new Error('No parsed data');
    const parsed = data.parsed;

    const cityMap = {
      'bangalore':'Bengaluru','bengaluru':'Bengaluru','hyderabad':'Hyderabad',
      'mumbai':'Mumbai','delhi':'Delhi NCR','pune':'Pune','chennai':'Chennai',
      'kolkata':'Kolkata','noida':'Noida','gurgaon':'Gurgaon','gurugram':'Gurgaon',
      'ahmedabad':'Ahmedabad','jaipur':'Jaipur','kochi':'Kochi','remote':'Remote',
    };
    const locations = (parsed.locations || []).map(l => cityMap[l.toLowerCase()] || l).filter(Boolean);
    const skills = (parsed.topSkills || parsed.skills || []).slice(0, 6);
    return {
      title:     parsed.jobTitle || '',
      keywords:  parsed.searchKeywords || parsed.jobTitle || '',
      skills, topSkills: skills,
      experience: parsed.experienceYears || '',
      expFilter:  parsed.expFilter || '3',
      location:   locations[0] || '',
      locations,
      education:  parsed.education || '',
      roleCategory: parsed.roleCategory || 'engineer',
    };
  } catch(e) {
    console.warn('[PingIN] JD Worker parse failed, using local fallback:', e.message);
    return extractFromJDFallback(text);
  }
}


async function extractFromJDFallback(text) {
  const result = {
    title:'', keywords:'', skills:[], experience:'', expFilter:'3',
    location:'', locations:[], education:'', roleCategory:'engineer'
  };

  // ── Step 1: Extract the JOB TITLE from the first meaningful line ───────────
  // Never scan full body for role — too many false positives
  // (e.g. "work with recruiting team" → wrongly triggers "Talent Acquisition")
  const titleLine = text.split('\n')
    .map(l => l.trim())
    .filter(l => l.length > 3 && l.length < 120 &&
      !l.startsWith('http') &&
      !l.toLowerCase().startsWith('about') &&
      !l.toLowerCase().startsWith('company') &&
      !l.toLowerCase().startsWith('we are') &&
      !l.toLowerCase().includes('years of experience') &&
      !/^[•\-\*]/.test(l))
    .slice(0, 4);  // Only check first 4 lines for title

  const titleText = titleLine.join(' ').toLowerCase();

  // Detect role from TITLE only
  if (/talent acquisition|ta partner|ta specialist|ta manager|recruitment manager|recruiter|recruiting manager/i.test(titleText))
    result.keywords = 'Talent Acquisition Recruiter';
  else if (/machine learning engineer|ml engineer/i.test(titleText))
    result.keywords = 'Machine Learning Engineer';
  else if (/data scientist/i.test(titleText))
    result.keywords = 'Data Scientist';
  else if (/data engineer/i.test(titleText))
    result.keywords = 'Data Engineer';
  else if (/data analyst/i.test(titleText))
    result.keywords = 'Data Analyst';
  else if (/java.*(spring|microservice|backend)/i.test(titleText) || /(spring|microservice).*java/i.test(titleText))
    result.keywords = 'Java Backend Developer';
  else if (/java.*developer|java.*engineer|senior java|java architect/i.test(titleText))
    result.keywords = 'Java Developer';
  else if (/python.*(django|flask|fastapi|backend)/i.test(titleText))
    result.keywords = 'Python Backend Developer';
  else if (/python.*developer|python.*engineer|senior python/i.test(titleText))
    result.keywords = 'Python Developer';
  else if (/react.*developer|react.*engineer|frontend.*react/i.test(titleText))
    result.keywords = 'React Developer';
  else if (/angular.*developer|angular.*engineer/i.test(titleText))
    result.keywords = 'Angular Developer';
  else if (/full.?stack.*developer|full.?stack.*engineer/i.test(titleText))
    result.keywords = 'Full Stack Developer';
  else if (/node\.?js.*developer|nodejs.*engineer/i.test(titleText))
    result.keywords = 'Node.js Developer';
  else if (/\.net.*developer|c#.*developer|dotnet.*developer/i.test(titleText))
    result.keywords = '.NET Developer';
  else if (/android.*developer|android.*engineer/i.test(titleText))
    result.keywords = 'Android Developer';
  else if (/ios.*developer|ios.*engineer|swift.*developer/i.test(titleText))
    result.keywords = 'iOS Developer';
  else if (/devops.*engineer|site reliability|sre|platform engineer/i.test(titleText))
    result.keywords = 'DevOps Engineer';
  else if (/qa.*engineer|test.*engineer|automation.*engineer|sdet/i.test(titleText))
    result.keywords = 'QA Automation Engineer';
  else if (/product manager|product owner/i.test(titleText))
    result.keywords = 'Product Manager';
  else if (/ui.*ux|ux.*designer|product designer/i.test(titleText))
    result.keywords = 'UI UX Designer';
  else if (/software engineer|software developer|sde[^v]|sde$/i.test(titleText))
    result.keywords = 'Software Engineer';
  else if (/backend.*engineer|backend.*developer/i.test(titleText))
    result.keywords = 'Backend Developer';
  else if (/frontend.*engineer|frontend.*developer/i.test(titleText))
    result.keywords = 'Frontend Developer';
  else {
    // Use the first title line directly if no pattern matches
    result.keywords = titleLine[0]?.replace(/[^a-zA-Z0-9\s]/g, '').trim().substring(0, 60) || 'Software Engineer';
  }
  result.title = result.keywords;

  // ── Step 2: Extract SKILLS from the full body (safe — not for role detection) ──
  const lower = text.toLowerCase();
  const skillPatterns = [
    'java','spring boot','microservices','rest api','restful','kafka','redis','postgresql','mysql',
    'python','django','flask','fastapi','pandas','numpy','tensorflow','pytorch',
    'javascript','typescript','react','angular','vue','node.js',
    '.net','c#','asp.net','entity framework',
    'aws','azure','gcp','kubernetes','docker','terraform','jenkins','ci/cd',
    'mongodb','cassandra','elasticsearch','redis','rabbitmq',
    'machine learning','deep learning','nlp','computer vision',
    'spark','airflow','hadoop','etl','dbt','snowflake',
    'selenium','testng','junit','cypress','appium',
  ];
  result.skills = skillPatterns.filter(s => lower.includes(s)).slice(0, 6);
  result.topSkills = result.skills;

  // ── Step 3: Extract EXPERIENCE ─────────────────────────────────────────────
  const expMatch = text.match(/(\d+)\+?\s*(?:to|-)?\s*(\d+)?\s*years?/i);
  if (expMatch) {
    const min = parseInt(expMatch[1]);
    result.experience = expMatch[0];
    result.expFilter = min >= 10 ? '5' : min >= 5 ? '4' : min >= 3 ? '3' : min >= 1 ? '2' : '1';
  }

  // ── Step 4: Extract LOCATION ───────────────────────────────────────────────
  const cityMap = {
    'bangalore':'Bengaluru','bengaluru':'Bengaluru','hyderabad':'Hyderabad',
    'mumbai':'Mumbai','delhi':'Delhi NCR','pune':'Pune','chennai':'Chennai',
    'kolkata':'Kolkata','noida':'Noida','gurgaon':'Gurgaon','gurugram':'Gurgaon',
    'ahmedabad':'Ahmedabad','jaipur':'Jaipur','kochi':'Kochi','remote':'Remote',
  };
  for (const [raw, mapped] of Object.entries(cityMap)) {
    if (lower.includes(raw)) {
      result.location = mapped;
      result.locations = [mapped];
      break;
    }
  }

  return result;
}


async function buildCloneSearchWithAI(profile) {
  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 300,
        messages: [{
          role: "user",
          content: `You are a LinkedIn recruiter. Given this profile data, generate the best search query to find SIMILAR professionals on LinkedIn.

Profile:
Name: ${profile.name || 'Unknown'}
Headline/Role: ${profile.headline || '(not available)'}
Current Company: ${profile.company || '(not available)'}
Location: ${profile.location || '(not available)'}
Education: ${profile.school || '(not available)'}
Skills: ${(profile.skills||[]).slice(0,5).join(', ') || '(not available)'}

IMPORTANT RULES:
- If headline is available: extract the job title (e.g. "Supply Chain Manager", "Software Engineer", "Data Scientist")
- If headline has "@Company": take only the role part before "@"
- If headline has "|": take only the first part (the actual role)
- If nothing is available: use the name to infer a reasonable professional role
- searchQuery must be 2-5 words describing the ROLE, not the person's name
- Never put the person's own name in the searchQuery
- location must be a major Indian city or blank

Return ONLY valid JSON (no markdown, no explanation):
{
  "searchQuery": "role-based search string (e.g. Supply Chain Manager or Software Engineer)",
  "location": "Indian city name or empty string",
  "experience": "number 1-5 (1=0-1yr, 2=1-3yr, 3=3-5yr, 4=5-10yr, 5=10+yr)",
  "reason": "one short line explaining search strategy"
}`
        }]
      })
    });
    if (!response.ok) throw new Error('API');
    const data = await response.json();
    const raw = data.content?.[0]?.text || '';
    const parsed = JSON.parse(raw.replace(/```json|```/g,'').trim());

    const cityMap = {'bangalore':'Bengaluru','bengaluru':'Bengaluru','hyderabad':'Hyderabad','mumbai':'Mumbai','delhi':'Delhi NCR','pune':'Pune','chennai':'Chennai','noida':'Noida','gurgaon':'Gurgaon'};
    const loc = cityMap[(parsed.location||'').toLowerCase()] || parsed.location || '';

    // Build tags for display
    const tags = [];
    if (parsed.searchQuery) tags.push({ label: '🔍 ' + parsed.searchQuery, type: 'blue' });
    if (loc)                tags.push({ label: '📍 ' + loc, type: 'green' });
    if (parsed.reason)      tags.push({ label: '💡 ' + parsed.reason, type: 'amber' });

    return {
      keywords:    parsed.searchQuery || '',
      location:    loc,
      experience:  parsed.experience || '3',
      tags,
      profileData: profile,
    };
  } catch(e) {
    return null; // fallback to regex
  }
}


async function applyCloneSearch(params) {
  // Clear existing profiles for fresh search
  S.profiles = []; S.sent = 0; S.failed = 0;
  await chrome.storage.local.set({ profiles:[], sent:0, failed:0 });

  // GUARD: Never launch with empty keywords — it shows random network people
  let searchKw = params.keywords || '';

  // Check if manual role was entered by user
  const manualRoleInput = document.getElementById('clone-manual-role');
  const manualRole = (manualRoleInput?.value || '').trim();
  if (manualRole) {
    searchKw = manualRole;
  }

  if (!searchKw.trim()) {
    // Show the manual role box and ask user to fill it in
    const manualBox = document.getElementById('clone-manual-role-box');
    if (manualBox) {
      manualBox.style.display = 'block';
      document.getElementById('clone-manual-role')?.focus();
    }
    showStatus('Please enter the role/job title to search for similar profiles.', 'warning');
    return;
  }

  // Build search URL directly and navigate — no need to fill form
  const url = buildSearchUrl(
    searchKw,
    params.location,
    '123',
    params.experience || '',
    '', '', '', 1, '', []
  );

  // Save params for scraping
  S.lastSearchParams = {
    keywords: params.keywords,
    location: params.location,
    degree: '123',
    experience: params.experience || '',
    profileType: '', college: '', degreeType: '', company: '',
    salaryRange: '', diversityFilters: []
  };
  await chrome.storage.local.set({ lastSearchParams: S.lastSearchParams });

  addLog('🧬 Clone Search: ' + (params.profileData?.name || 'profile'));

  // Open in new tab so popup stays alive and profiles appear automatically
  await chrome.tabs.create({ url, active: true });
  setTimeout(() => showScreen('screen-profiles', 'slide-up'), 1000);
}


async function applyJDToSearch(ext) {
  // Clear existing profiles for fresh search
  S.profiles = []; S.sent = 0; S.failed = 0;
  await chrome.storage.local.set({ profiles:[], sent:0, failed:0 });

  // Build search: Job title + top 2 skills for precision
  let kw = ext.keywords || ext.title || '';
  if (kw && kw.includes(' ') && !/\b(AND|OR|NOT)\b/.test(kw)) {
    kw = '"' + kw + '"';
  }
  // Add top 2 skills to narrow results to actual matching candidates
  const topSkills = (ext.topSkills || ext.skills || []).slice(0, 2);
  if (topSkills.length > 0 && kw) {
    const skillStr = topSkills.map(s => '"'+s+'"').join(' OR ');
    kw = '(' + kw + ') AND (' + skillStr + ')';
  }

  // Handle MULTIPLE locations — open one tab per location
  const locations = ext.locations || (ext.location ? [ext.location] : []);
  
  if (locations.length === 0) {
    // No location — single search in new tab (keeps popup alive)
    const url = buildSearchUrl(kw, '', '123', ext.expFilter || '', '', '', '', 1, '', []);
    await chrome.tabs.create({ url, active: true });
  } else if (locations.length === 1) {
    // Single location — new tab
    const url = buildSearchUrl(kw, locations[0], '123', ext.expFilter || '', '', '', '', 1, '', []);
    await chrome.tabs.create({ url, active: true });
  } else {
    // Multiple locations — open a tab for each
    for (let i = 0; i < locations.length; i++) {
      const url = buildSearchUrl(kw, locations[i], '123', ext.expFilter || '', '', '', '', 1, '', []);
      await chrome.tabs.create({ url, active: i === 0 });
      await new Promise(r => setTimeout(r, 300));
    }
    addLog('JD Search: opened ' + locations.length + ' tabs for ' + locations.join(', '));
  }

  S.lastSearchParams = { keywords:kw, location:locations[0]||'', degree:'123', experience:ext.expFilter||'', profileType:'', college:'', degreeType:'', company:'', salaryRange:'', diversityFilters:[] };
  await chrome.storage.local.set({ lastSearchParams: S.lastSearchParams });
  
  setTimeout(() => showScreen('screen-profiles', 'slide-up'), 1500);
}


function filterDropdown(query, selectId, dropdownId) {
  const dropdown = document.getElementById(dropdownId);
  const select   = document.getElementById(selectId);
  if (!dropdown || !select) return;
  const q = (query||'').toLowerCase().trim();
  if (!q) { dropdown.style.display='none'; return; }
  const allOptions = Array.from(select.querySelectorAll('option'))
    .filter(o => o.value && o.value !== 'other_college' && o.value !== '')
    .filter(o => o.text.toLowerCase().includes(q) || o.value.toLowerCase().includes(q))
    .slice(0, 12);
  // Show first 8 options even on empty query
  const displayOptions = q ? allOptions : Array.from(select.querySelectorAll('option')).filter(o=>o.value&&o.value!=='other_college'&&o.value!=='').slice(0,8);
  const finalOptions = q ? allOptions : displayOptions;
  if (!finalOptions.length) { dropdown.style.display='none'; return; }
  dropdown.innerHTML = allOptions.map(o =>
    `<div class="cd-item" data-value="${o.value.replace(/"/g,'&quot;')}" data-select="${selectId}" data-inp="${dropdownId.replace('-dropdown','-search')}">${o.text.replace(new RegExp('('+q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','gi'),'<mark>$1</mark>')}</div>`
  ).join('');
  dropdown.style.display = 'block';
  dropdown.querySelectorAll('.cd-item').forEach(item => {
    item.addEventListener('mousedown', e => {
      e.preventDefault();
      const val = item.dataset.value;
      const sel = document.getElementById(item.dataset.select);
      const inp = document.getElementById(item.dataset.inp);
      if (inp) inp.value = item.textContent;
      if (sel) sel.value = val;
      dropdown.style.display = 'none';
      const kw = document.getElementById('s-keywords');
      if (kw && val && !kw.value.includes(val)) {
        kw.value = kw.value ? kw.value + ' "' + val + '"' : '"' + val + '"';
      }
      updateProfileTypeState();
    });
  });
}


// MULTI-COMPANY CHIP SYSTEM
function getCompanyList() {
  try { var e=document.getElementById('s-company-list'); return e?JSON.parse(e.value||'[]'):[];} catch(e){return [];}
}
function setCompanyList(arr) {
  var e=document.getElementById('s-company-list');
  if(e) e.value=JSON.stringify(Array.isArray(arr)?arr:[]);
  renderCompanyChips(arr||[]);
}
function renderCompanyChips(arr) {
  var wrap=document.getElementById('company-chips');
  if(!wrap) return;
  wrap.innerHTML=(arr||[]).map(function(c,i){
    var lbl=c.length>16?c.slice(0,15)+'…':c;
    return '<span style="display:inline-flex;align-items:center;gap:3px;background:rgba(0,119,181,.15);border:1px solid rgba(0,119,181,.3);border-radius:100px;padding:2px 9px;font-size:11px;font-weight:600;color:#5BB5FF;white-space:nowrap;" title="'+c.replace(/"/g,'&quot;')+'">'
      +lbl+'<button data-ci="'+i+'" style="background:none;border:none;color:rgba(91,181,255,.7);cursor:pointer;font-size:15px;line-height:1;padding:0 0 0 3px;">×</button></span>';
  }).join('');
  wrap.querySelectorAll('button[data-ci]').forEach(function(btn){
    btn.addEventListener('mousedown',function(e){
      e.preventDefault(); e.stopPropagation();
      var list=getCompanyList(); list.splice(parseInt(btn.getAttribute('data-ci')),1); setCompanyList(list);
    });
  });
  var inp=document.getElementById('s-company');
  if(inp) inp.placeholder=(arr&&arr.length)?'Add another...':'Google, Swiggy, HDFC...';
  var cw=document.getElementById('company-chips-wrap');
  if(cw) cw.style.borderColor=(arr&&arr.length)?'rgba(0,119,181,.45)':'var(--border2)';
}
function addCompanyChip(name) {
  var n=(name||'').trim().replace(/,+$/,'').trim();
  if(!n) return;
  var arr=getCompanyList();
  if(arr.map(function(x){return x.toLowerCase();}).indexOf(n.toLowerCase())>-1) return;
  if(arr.length>=10){showStatus('Maximum 10 companies at once.','warning');return;}
  arr.push(n); setCompanyList(arr);
  var inp=document.getElementById('s-company');
  if(inp) inp.value='';
}
function removeCompanyChip(idx) {
  var arr=getCompanyList(); arr.splice(idx,1); setCompanyList(arr);
}
function getCompanySearchString() {
  var arr=getCompanyList();
  if(!arr.length) return '';
  if(arr.length===1) return arr[0];
  return arr.map(function(c){return '"'+c+'"';}).join(' OR ');
}
async function filterCompanyDropdown(query) {
  var dd=document.getElementById('company-dropdown');
  var inp=document.getElementById('s-company');
  if(!dd||!inp) return;
  var raw=inp.value||'';
  if(raw.indexOf(',')>-1){
    var parts=raw.split(',').map(function(s){return s.trim();}).filter(Boolean);
    if(parts.length>1){parts.forEach(function(p){addCompanyChip(p);}); inp.value=''; dd.style.display='none'; return;}
  }
  var q=(query||'').toLowerCase().trim();
  var selected=getCompanyList().map(function(x){return x.toLowerCase();});
  var popular=['TCS','Infosys','Wipro','HCL Technologies','Accenture','Google India','Microsoft India','Amazon India','Swiggy','Zomato','Flipkart','Deloitte','HDFC Bank','ICICI Bank','Cognizant'];
  var src=q?COMPANIES:popular;
  var filtered=src.filter(function(c){return !q||c.toLowerCase().indexOf(q)>-1;}).filter(function(c){return selected.indexOf(c.toLowerCase())===-1;}).slice(0,12);
  if(!filtered.length){dd.style.display='none';return;}
  dd.innerHTML=filtered.map(function(c){
    var d=c;
    if(q){try{var re=new RegExp('('+q.replace(/[$()*+.?[\]^{|}\\]/g,'\\$&')+')','gi');d=c.replace(re,'<mark>$1</mark>');}catch(e){}}
    return '<div class="cd-item" data-val="'+c.replace(/"/g,'&quot;')+'">'+d+'</div>';
  }).join('');
  dd.style.display='block';
  dd.querySelectorAll('.cd-item').forEach(function(item){
    item.addEventListener('mousedown',function(e){
      e.preventDefault(); addCompanyChip(item.getAttribute('data-val')); dd.style.display='none';
    });
  });
}


// PLAN-BASED TAB VISIBILITY
function updateTabVisibility() {
  var plan = S.plan || 'free';
  var ACCESS = {
    free:    ['screen-smart','screen-salary'],
    starter: ['screen-smart','screen-clone','screen-jd','screen-predictive','screen-salary'],
    pro:     ['screen-smart','screen-clone','screen-jd','screen-github','screen-stackoverflow','screen-company','screen-predictive','screen-salary'],
    annual:  ['screen-smart','screen-clone','screen-jd','screen-github','screen-stackoverflow','screen-company','screen-predictive','screen-salary'],
    expired: ['screen-smart'],
  };
  var allowed = ACCESS[plan] || ACCESS['free'];
  document.querySelectorAll('.search-card[data-screen]').forEach(function(card) {
    var scr = card.getAttribute('data-screen');
    var ok  = allowed.indexOf(scr) > -1;
    card._pinginAccess = ok;
    card.style.opacity = ok ? '1' : '0.45';
    var existing = card.querySelector('.plan-lock-badge');
    if (!ok && !existing) {
      // GitHub/SO/Company = Pro only · Clone/JD/Predictive = Starter+
      var proScreens = ['screen-github','screen-stackoverflow','screen-company'];
      var needPlan = proScreens.indexOf(scr) > -1 ? 'Pro' : 'Starter';
      var badge = document.createElement('span');
      badge.className = 'plan-lock-badge';
      badge.textContent = needPlan;
      badge.style.cssText = 'font-size:9px;font-weight:700;background:rgba(186,117,23,.15);color:#EF9F27;border:1px solid rgba(186,117,23,.25);border-radius:100px;padding:2px 6px;margin-left:5px;vertical-align:middle;';
      var title = card.querySelector('.card-title');
      if (title) title.appendChild(badge);
    }
    if (ok && existing) existing.remove();
  });
}

async function checkPlanStatus() {
  try {
    const data = await chrome.storage.local.get([
      'planStatus','planExpiry','licenseKey','trialStart','dailyLimit'
    ]);

    const plan        = data.planStatus  || 'free';
    const planExpiry  = data.planExpiry  || null;
    const licenseKey  = data.licenseKey  || null;
    const trialStart  = data.trialStart  || null;
    const now         = Date.now();

    // ── If no plan set at all — detect from manifest name ──────────
    if (!licenseKey && !planExpiry) {
      // Read manifest name to determine which plan ZIP this is
      var manifestName = chrome.runtime.getManifest().name || '';
      var autoplan = 'free';
      if (manifestName.indexOf('Annual') > -1)       autoplan = 'annual';
      else if (manifestName.indexOf('Pro') > -1)     autoplan = 'pro';
      else if (manifestName.indexOf('Starter') > -1) autoplan = 'starter';

      S.plan = autoplan;
      const autoDaysMap = { free: TRIAL_DAYS, starter: 15, pro: 30, annual: 365 };
      S.trialDaysLeft = autoDaysMap[autoplan] || TRIAL_DAYS;
      S.trialMsgsLeft = 0; // outreach removed
      updatePlanBar();
      updatePremiumGating();
      return;
    }

    // ── Check expiry ──
    if (planExpiry && now > new Date(planExpiry)) {
      S.plan = 'expired';
      updatePlanBar();
      updatePremiumGating();
      return;
    }

    // ── Active plan ──
    S.plan = plan;
    if (planExpiry) {
      S.trialDaysLeft = Math.max(0, Math.ceil((new Date(planExpiry) - now) / 86400000));
    } else {
      S.trialDaysLeft = TRIAL_DAYS;
    }
    S.trialMsgsLeft = data.dailyLimit || PLANS[plan]?.dailyLimit || (S.plan==='free' ? 5 : 50);
    updatePlanBar();
    updatePremiumGating();

  } catch(e) {
    // On any error — allow free trial access so user is not locked out
    S.plan = 'free';
    S.trialDaysLeft = TRIAL_DAYS;
    S.trialMsgsLeft = 0; // outreach removed
    updatePlanBar();
    updatePremiumGating();
  }
}


function updatePlanBar() {
  const bar  = document.getElementById('plan-bar');
  const icon = document.getElementById('plan-bar-icon');
  const text = document.getElementById('plan-bar-text');
  const upBtn= document.getElementById('plan-bar-upgrade');
  if (!bar) return;
  bar.style.display = 'flex';

  if (S.plan === 'expired') {
    bar.className = 'plan-bar';
    bar.style.background = 'rgba(226,75,74,.12)';
    if (icon) icon.textContent = '⚠';
    if (text) text.textContent = 'Plan expired — renew at pingin.in';
    if (upBtn) { upBtn.style.display='inline-block'; upBtn.textContent='Renew'; }
    return;
  }

  const planNames = { free:'Free Trial', starter:'Starter', pro:'Pro', annual:'Annual' };
  const planName  = planNames[S.plan] || 'Free Trial';
  const daysLeft  = S.trialDaysLeft || 5;

  if (S.plan === 'free' || !S.plan) {
    bar.className = 'plan-bar';
    bar.style.background = 'rgba(0,119,181,.1)';
    if (icon) icon.textContent = '🆓';
    if (text) text.textContent = 'Free Trial · ' + daysLeft + ' days left';
    if (upBtn) { upBtn.style.display='inline-block'; upBtn.textContent='Upgrade'; }
  } else {
    bar.className = 'plan-bar premium';
    bar.style.background = '';
    if (icon) icon.textContent = '✓';
    if (text) text.textContent = planName + ' · ' + daysLeft + ' days left';
    if (upBtn) upBtn.style.display = 'none';
  }
}


async function updatePremiumGating() {
  const plan = S.plan || 'free';
  const isPro     = ['pro','annual'].includes(plan);
  const isStarter = ['starter','pro','annual'].includes(plan);
  const isPaid    = isStarter;
  const isFree    = !isStarter;
  const isExpired = plan === 'expired';

  // Lock CSV/Excel Export — Pro+ only
  const csvBtn  = document.getElementById('btn-export-csv');
  const xlsxBtn = document.getElementById('btn-export-xlsx');
  if (csvBtn)  { csvBtn.disabled  = !isPro; csvBtn.title  = isPro ? '' : 'Pro plan required'; csvBtn.style.opacity = isPro ? '1' : '0.35'; }
  if (xlsxBtn) { xlsxBtn.disabled = !isPro; xlsxBtn.title = isPro ? '' : 'Pro plan required'; xlsxBtn.style.opacity = isPro ? '1' : '0.35'; }

  // Lock profile scoring display — Pro+ only
  // Scores hidden via CSS class on profiles wrapper
  const profContent = document.querySelector('.profiles-content');
  if (profContent) {
    if (isPro) profContent.classList.remove('scores-hidden');
    else       profContent.classList.add('scores-hidden');
  }

  // Save search button — paid only
  const saveSrch = document.getElementById('btn-save-search');
  const saveProf = document.getElementById('btn-save-profiles');
  if (saveSrch) {
    saveSrch.disabled = !isPaid;
    saveSrch.title = isPaid ? 'Save this search' : 'Upgrade to save searches';
    saveSrch.classList.toggle('locked', !isPaid);
  }
  if (saveProf) {
    saveProf.disabled = !isPro;
    saveProf.title = isPro ? 'Save profiles' : 'Pro plan required';
    saveProf.classList.toggle('locked', !isPro);
  }

  // College filter (IIT/IIM) — Pro+ only — lock BOTH search input + dropdown
  const collegeField  = document.getElementById('s-college');
  const collegeSearch = document.getElementById('college-search');
  const degSearch     = document.getElementById('deg-search');
  const degType       = document.getElementById('s-degree-type');
  [collegeField, collegeSearch, degSearch, degType].forEach(el => {
    if (!el) return;
    el.disabled = !isPro;
    el.style.opacity = isPro ? '1' : '0.4';
    el.style.pointerEvents = isPro ? '' : 'none';
    el.style.cursor = isPro ? '' : 'not-allowed';
    if (!isPro && el.tagName === 'INPUT') {
      el.placeholder = '🔒 Pro plan only';
    }
  });
  // Grey out the whole college section visually
  const collegeWrap = collegeField?.closest('.form-group');
  if (collegeWrap) {
    collegeWrap.style.opacity = isPro ? '1' : '0.45';
    collegeWrap.title = isPro ? '' : 'College Filter is available in Pro plan';
  }
  const degWrap = degType?.closest('.form-group');
  if (degWrap) {
    degWrap.style.opacity = isPro ? '1' : '0.45';
    degWrap.title = isPro ? '' : 'Degree Filter is available in Pro plan';
  }

  // Profile type filter — Pro+ only
  const profileType = document.getElementById('s-profile-type');
  if (profileType) {
    profileType.disabled = !isPro;
    if (!isPro) profileType.style.opacity = '0.5';
    else profileType.style.opacity = '1';
  }

  // View Profiles button — Pro+ only  
  const viewBtn = document.getElementById('smart-view-btn');
  if (viewBtn) {
    if (!isPro) {
      viewBtn.style.display = 'none';
    } else {
      viewBtn.style.display = '';
    }
  }

  updateTabVisibility();

  // ── Pro-only features: collect, scoring, export ──────────────────────────────
  const collectBtn = document.getElementById('btn-collect');
  if (collectBtn) {
    if (!isPro) {
      collectBtn.disabled = true;
      collectBtn.style.cursor = 'not-allowed';
      collectBtn.style.opacity = '0.4';
      collectBtn.style.background = 'rgba(99,130,200,.15)';
      collectBtn.style.border = '1.5px solid rgba(99,130,200,.2)';
      collectBtn.style.color = 'rgba(255,255,255,.3)';
      collectBtn.textContent = '🔒 Get Profiles (Pro Plan)';
      collectBtn.title = 'Upgrade to Pro to collect profiles';
    }
  }

  // CSV / Excel export — Pro only
  ['btn-export-csv','btn-export-xlsx','smart-export-btn'].forEach(function(id) {
    const el = document.getElementById(id);
    if (el) {
      el.disabled = !isPro;
      el.style.opacity = isPro ? '1' : '0.35';
      el.style.cursor = isPro ? 'pointer' : 'not-allowed';
      el.title = isPro ? '' : 'Upgrade to Pro to export profiles';
    }
  });

  // Score badges — hide for non-Pro (show "PRO" label instead)
  document.querySelectorAll('.score-badge, [class*="score-badge"]').forEach(function(el) {
    if (!isPro && el.textContent && el.textContent !== '–') {
      el.style.opacity = '0.3';
      el.title = 'Score visible in Pro plan';
    }
  });

  // Profiles screen — show upgrade banner for non-Pro
  const profilesEmpty = document.getElementById('profiles-empty');
  if (profilesEmpty && !isPro && S.profiles && S.profiles.length === 0) {
    profilesEmpty.innerHTML = '<div style="font-size:28px;margin-bottom:8px;">🔒</div>' +
      '<div style="font-size:14px;font-weight:600;color:var(--tp);margin-bottom:6px;">Pro Plan Feature</div>' +
      '<div style="font-size:12px;color:var(--ts);max-width:220px;margin:0 auto 14px;line-height:1.6;">Collect &amp; view profiles, AI scoring and CSV export are available in Pro plan.</div>' +
      '<a href="https://pingin.in/pricing.html" target="_blank" style="display:inline-block;padding:9px 20px;background:linear-gradient(135deg,#0055cc,#38bdf8);border-radius:8px;color:#fff;font-size:12px;font-weight:700;text-decoration:none;">Upgrade to Pro →</a>';
    profilesEmpty.style.display = 'block';
  }
}





// ── Firebase server-side plan validation on startup ──────────────────────────
// Runs once per session — verifies plan via Firebase REST API
// Fails open (never blocks user if Firebase unreachable)
async function validatePlanWithFirebase() {
  try {
    const data = await chrome.storage.local.get(['licenseKey','planStatus','planEmail']);
    const email      = data.planEmail || '';
    const licenseKey = data.licenseKey || '';
    if (!email || !licenseKey) return; // No plan to validate

    // Firebase config — injected from extension storage if available
    const fbConfig = await chrome.storage.local.get(['fb_project_id','fb_api_key']);
    const projectId = fbConfig.fb_project_id || '';
    const apiKey    = fbConfig.fb_api_key || '';
    if (!projectId || !apiKey) return; // Firebase not configured

    const result = await chrome.runtime.sendMessage({
      action:     'VALIDATE_PLAN_FIREBASE',
      email,
      licenseKey,
      projectId,
      apiKey,
    });

    if (result && result.valid === false) {
      // Server says plan is invalid — update local state
      console.warn('[PingIN] Server validation failed:', result.reason);
      if (result.reason === 'expired_server' || result.reason === 'invalid_key_server') {
        await chrome.storage.local.set({ planStatus: 'expired' });
        // Reload to apply expired state
        location.reload();
      }
    }
  } catch(e) {
    // Fail open — never block user due to validation errors
  }
}

// Run validation silently after 3s delay (non-blocking)
setTimeout(validatePlanWithFirebase, 3000);


// ── DOM helpers ──────────────────────────────────────────────────────────────
function setVal(id, val) {
  const el = document.getElementById(id);
  if (el) el.value = val;
}
function setChk(id, checked) {
  const el = document.getElementById(id);
  if (el) el.checked = !!checked;
}

async function syncFromStorage() {
  try {
    const data = await chrome.storage.local.get([
      'profiles','log','settings','sent','failed',
      'messageTemplate','searchHistory','planStatus','lastSearchParams',
      'totalMsgsSent','dailySent','pendingScrape','lastScrapeResult',
    ]);

    S.profiles         = data.profiles         || [];
    S.log              = data.log              || [];
    S.sent             = data.sent             || 0;
    S.failed           = data.failed           || 0;
    S.history    = data.searchHistory    || [];
    S.plan             = data.planStatus       || 'free';
    // Sync to Firebase so admin panel can see this user
    try {
      const u = await PingINDB.findUserByEmail(S.email||'');
      if (u) PingINDB.syncUserToFirebase({ ...u, plan: S.plan, lastSeen: new Date().toISOString() }).catch(()=>{});
    } catch(e) {} // default to free trial
    S.lastSearchParams = data.lastSearchParams || null;

    // Settings
    const cfg = data.settings || {};
    setVal('c-daily',            cfg.dailyLimit    || 50);
    setVal('c-delay',            cfg.delaySeconds  || 45);
    setVal('set-weekly',         cfg.weeklyLimit   || 80);
    setChk('set-random-delay',   cfg.randomDelay   !== false);
    setChk('set-biz-hours',      cfg.bizHours      !== false);
    setChk('set-skip-connected', cfg.skipConnected !== false);
    setChk('set-skip-messaged',  cfg.skipMessaged  !== false);
    setChk('set-auto-pause',     cfg.autoPause     !== false);

    // Restore message template
    if (data.messageTemplate) {
      const ta = document.getElementById('s-message');
      if (ta) { ta.value = data.messageTemplate; updateCharCount(); }
    }

    // ── Check if service worker just finished a scrape ──
    const lastScrape = data.lastScrapeResult;
    if (lastScrape && (Date.now() - lastScrape.at) < 30000) {
      // Fresh scrape result — notify user
      setTimeout(() => {
        showStatus('✓ ' + lastScrape.count + ' profiles collected! Total: ' + lastScrape.total, 'success');
        renderProfiles(); updateStats();
      }, 500);
      await chrome.storage.local.remove('lastScrapeResult');
    }

    // ── Check for pending scrape (popup was closed during search) ──
    const pendingScrape = data.pendingScrape;
    if (pendingScrape && (Date.now() - pendingScrape.requestedAt) < 120000) {
      // Within 2 minutes — check if we're on the right page and scrape
      const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      const tab  = tabs?.[0];
      if (tab?.url?.includes('linkedin.com/search/results/people')) {
        showStatus('Search results detected! Collecting profiles...','info');
        setTimeout(async () => {
          await doScrape(tab.id, pendingScrape.params, pendingScrape.page || 1);
          await chrome.storage.local.remove('pendingScrape');
        }, 1500);
      }
    }

    // ── Restore last search fields ──
    if (S.lastSearchParams) {
      const p = S.lastSearchParams;
      const setField = (id, val) => { const el=document.getElementById(id); if(el&&val) el.value=val; };
      setField('s-keywords',    p.keywords);
      setField('s-location',    p.location);
      setField('s-degree',      p.degree);
      setField('s-experience',  p.experience);
      setField('s-college',     p.college);
      // Pre-fill single company from cloned profile
      if (p.company) setCompanyList([p.company]);
      else setCompanyList([]);
      setField('s-degree-type', p.degreeType);
      setField('s-salary-range', p.salaryRange);
      // Restore diversity filters
      if (p.diversityFilters && p.diversityFilters.length > 0) {
        const toggle = document.getElementById('diversity-toggle');
        const sub    = document.getElementById('diversity-sub');
        if (toggle) { toggle.checked = true; }
        if (sub)    { sub.style.display = 'block'; }
        p.diversityFilters.forEach(val => {
          const chk = document.querySelector(`.div-chk[value="${val}"]`);
          if (chk) chk.checked = true;
        });
      }
      if (p.keywords && p.profileType) {
        const pt = document.getElementById('s-profile-type');
        if (pt) { pt.disabled=false; pt.value=p.profileType; }
      }
    }

  } catch(e) {
    console.error('[PingIN] syncFromStorage error:', e);
  }
}


async function checkLoginState() {
  try {
    const data = await chrome.storage.local.get(['userSession','planStatus']);
    const session = data.userSession;
    const loginScreen = document.getElementById('login-screen');
    const mainApp     = document.getElementById('main-app');

    if (session?.loginAt) {
      const hours = (Date.now() - new Date(session.loginAt)) / 3600000;
      if (hours < 168) {
        loginScreen && (loginScreen.style.display='none');
        mainApp     && (mainApp.style.display='block');
        const footerUser = document.getElementById('footer-user');
        if (footerUser && session.name) footerUser.textContent = session.name;
        return true;
      }
    }
    // ── Fallback: try reading from pingin_session via injected script ──
    // Website stores session in localStorage — try to read it
    try {
      const liTabs = await chrome.tabs.query({ url: 'https://pingin.in/*' });
      if (liTabs.length > 0) {
        const res = await chrome.scripting.executeScript({
          target: { tabId: liTabs[0].id },
          func: () => {
            try { return JSON.parse(localStorage.getItem('pingin_session') || 'null'); } catch(e) { return null; }
          }
        });
        const webSession = res?.[0]?.result;
        if (webSession?.loginAt && webSession?.email) {
          // Sync to chrome.storage for future use
          await chrome.storage.local.set({ userSession: webSession });
          loginScreen && (loginScreen.style.display='none');
          mainApp     && (mainApp.style.display='block');
          const footerUser = document.getElementById('footer-user');
          if (footerUser && webSession.name) footerUser.textContent = webSession.name;
          return true;
        }
      }
    } catch(e) {}
    // ── Extension works without login — show app anyway ──
    loginScreen && (loginScreen.style.display='none');
    mainApp     && (mainApp.style.display='block');
    const footerUser = document.getElementById('footer-user');
    if (footerUser) footerUser.textContent = 'Free Trial';
    return true;
  } catch(e) {
    console.error('[PingIN] checkLoginState:', e);
    return false;
  }
}


function renderProfiles(filter){
  if (filter !== undefined) S.currentFilter = filter;
  if (!S.currentFilter) S.currentFilter = 'all';

  // ── Apply location display filter — final safety net ─────────────────────
  // Some profiles may slip through (e.g. "IIT Delhi" in education but based in Hyderabad)
  // Filter at display level using the searched location
  const searchedLoc = (S.lastSearchParams?.location || '').toLowerCase().trim();
  const LOC_DISPLAY = {
    'bengaluru':['bengaluru','bangalore'],'hyderabad':['hyderabad','secunderabad'],
    'mumbai':['mumbai','bombay'],'delhi':['delhi','new delhi'],
    'new delhi':['new delhi','delhi'],'noida':['noida'],
    'gurgaon':['gurgaon','gurugram'],'faridabad':['faridabad'],
    'ghaziabad':['ghaziabad'],'chennai':['chennai','madras'],
    'pune':['pune'],'kolkata':['kolkata','calcutta'],
    'ahmedabad':['ahmedabad'],'jaipur':['jaipur'],
    'navi mumbai':['navi mumbai'],'thane':['thane'],
    'kochi':['kochi','cochin'],'coimbatore':['coimbatore'],
    'chandigarh':['chandigarh'],'indore':['indore'],
    'lucknow':['lucknow'],'nagpur':['nagpur'],
  };
  function cityMatch(profileCity, wantLoc) {
    if (!wantLoc) return true;
    if (!profileCity) return true; // no city info — don't hide, give benefit of doubt
    const c = profileCity.toLowerCase();
    const aliases = LOC_DISPLAY[wantLoc] || [wantLoc];
    return aliases.some(a => c.includes(a));
  }
  // Filter S.profiles for display only (don't modify the actual array)
  const displayProfiles = searchedLoc
    ? S.profiles.filter(p => cityMatch(p.city, searchedLoc))
    : S.profiles;

  updateTopProfiles();
  const list=document.getElementById('profiles-list');
  const empty=document.getElementById('profiles-empty');

  // Score all profiles (Pro/Annual only — Free/Starter see no scores)
  const canScore = ['pro','annual'].includes(S.plan);
  const scored = displayProfiles.map(p => ({
    ...p,
    _score: canScore ? scoreProfile(p, S.lastSearchParams) : 0
  }));

  let filtered = scored;

  // Filter by tab
  if (S.currentFilter === 'toppicks') {
    if (!canScore) {
      filtered = [];
    } else {
      filtered = scored
        .filter(p => p._score >= 40)
        .sort((a,b) => b._score - a._score);
    }
  } else if (S.currentFilter !== 'all') {
    filtered = scored.filter(p =>
      S.currentFilter === 'pending'
        ? (p.status==='pending'||p.status==='queued')
        : p.status === S.currentFilter
    );
  } else {
    // All — sort by score descending
    filtered = scored.sort((a,b) => b._score - a._score);
  }

  const countEl = document.getElementById('profiles-count');
  if (countEl) {
    if (S.currentFilter === 'toppicks') {
      countEl.textContent = filtered.length + ' top picks (score ≥40)';
    } else {
      countEl.textContent = filtered.length + (S.currentFilter!=='all' ? ' '+S.currentFilter : '') + ' profiles';
    }
  }

  if (!filtered.length) {
    empty.style.display = 'block';
    list.innerHTML = S.currentFilter === 'toppicks'
      ? '<div class="toppicks-empty">🔍 No top picks yet.<br>Collect more profiles to see top matches!</div>'
      : '';
    return;
  }
  empty.style.display = 'none';

  // Score legend (show in Top Picks and All tabs)
  const legend = (S.currentFilter === 'toppicks' || S.currentFilter === 'all')
    ? `<div class="score-legend">
        <span style="font-weight:600;color:var(--ts)">Score:</span>
        <span class="sl-item"><span class="score-badge score-hot">🔥 90+</span> Hot</span>
        <span class="sl-item"><span class="score-badge score-strong">⭐ 75+</span> Strong</span>
        <span class="sl-item"><span class="score-badge score-good">✅ 60+</span> Good</span>
      </div>`
    : '';

  list.innerHTML = legend + filtered.slice(0,60).map((p,i) => {
    const ini=(p.name||'?').split(' ').map(n=>n[0]).join('').slice(0,2).toUpperCase();
    const[bg,tc]=AV[i%AV.length];
    const sub=[p.role,p.company,p.city].filter(Boolean).join(' · ');
    const av=p.photo
      ? `<img src="${p.photo}" style="width:30px;height:30px;border-radius:50%;object-fit:cover" onerror="this.style.display='none'">`
      : ini;
    const degBadge=p.degree?`<span class="p-degree">${p.degree}</span>`:'';
    const otwBadge=p.isOTW?`<span class="p-degree" style="background:rgba(0,212,170,.15);color:var(--accent)">OTW</span>`:'';
    const scoreClass = getScoreClass(p._score);
    const scoreLabel = getScoreLabel(p._score);
    const matchLabel = getMatchLabel(p._score);
    const borderClass = p._score>=90?'hot':p._score>=75?'strong':p._score>=60?'good':'';
    const sourceLabel = p.keyword ? `<span style="font-size:9px;color:var(--tm);display:block;margin-top:2px;">🔍 ${(p.keyword||'').substring(0,30)}</span>` : '';
    return `<div class="profile-item ${borderClass}" data-url="${p.profileUrl||''}" style="cursor:pointer;" title="Click to open LinkedIn profile">
      <div class="p-av-wrap">
        <div class="p-av" style="background:${bg};color:${tc}">${av}</div>
        ${p.isOTW ? '<div class="p-otw-dot" title="Open to Work"></div>' : ''}
      </div>
      <div class="p-info">
        <div class="p-name">${p.name}${degBadge}</div>
        <div class="p-sub">${sub||'—'}</div>
        ${sourceLabel}
        ${p.notes ? `<div style="font-size:9px;color:rgba(255,212,0,.8);margin-top:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:160px;">📝 ${p.notes.split('\n')[0].slice(0,45)}</div>` : ''}
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:3px;flex-shrink:0;">
        <span class="score-badge ${scoreClass}">${scoreLabel}</span>
        <span class="p-badge ${scoreClass}" style="font-size:9px;">${matchLabel}</span>
        <button class="p-note-btn" data-url="${p.profileUrl||''}" title="${p.notes ? 'Edit note: ' + p.notes.slice(0,40) : 'Add a note'}" style="font-size:11px;font-weight:700;padding:2px 6px;border-radius:5px;border:1px solid ${p.notes ? 'rgba(255,212,0,.3)' : 'rgba(255,255,255,.1)'};background:${p.notes ? 'rgba(255,212,0,.1)' : 'rgba(255,255,255,.04)'};color:${p.notes ? 'rgba(255,212,0,.9)' : 'rgba(255,255,255,.3)'};cursor:pointer;font-family:inherit;white-space:nowrap;">${p.notes ? '📝 Note' : '+ Note'}</button>
      </div>
    </div>`;
  }).join('') + (filtered.length>60
    ? `<div style="text-align:center;padding:8px;font-size:11px;color:var(--ts)">+${filtered.length-60} more</div>`
    : '');
}


function updateStats(){
  (function(){const _el=document.getElementById('c-found');if(_el)_el.textContent=S.profiles.length;})();
  (function(){const _el=document.getElementById('c-sent');if(_el)_el.textContent=S.profiles.filter(p=>p.status==='sent').length;})();
  (function(){const _el=document.getElementById('c-pending');if(_el)_el.textContent=S.profiles.filter(p=>p.status==='pending'||p.status==='queued').length;})();
  (function(){const _el=document.getElementById('c-failed');if(_el)_el.textContent=S.profiles.filter(p=>p.status==='failed').length;})();
}


function exportCSV(){
  // Plan check — free trial cannot export
  if (S.plan === 'free' || S.plan === 'none' || !S.plan) {
    showStatus('Profile export requires Starter plan or above. Upgrade at pingin.in/pricing.html', 'warning');
    return;
  }
  if (!S.profiles.length) { alert('No profiles to export.'); return; }

  // Get notes from storage for each profile
  var notes = {};
  try {
    var stored = JSON.parse(localStorage.getItem('pingin_notes') || '{}');
    notes = stored;
  } catch(e) {}

  const hdr = [
    'Name','Headline / Role','Company','City','Education',
    'Open To Work','Match Score','LinkedIn URL',
    'Status','Notes','Search Keyword','Collected At'
  ];
  const rows = S.profiles.map(p => {
    var score = typeof scoreProfile === 'function'
      ? scoreProfile(p, S.lastSearchParams) : '';
    var note  = notes[p.profileUrl] || '';
    return [
      p.name || '',
      p.role || p.headline || '',
      p.company || '',
      p.city || p.location || '',
      p.degree || '',
      p.isOTW ? 'Yes' : 'No',
      score,
      p.profileUrl || '',
      p.status || 'collected',
      note,
      p.keyword || S.lastSearchParams?.keywords || '',
      p.scrapedAt || '',
    ];
  });

  // BOM for Excel compatibility with Indian names / Unicode
  const csv = '\uFEFF' + [hdr, ...rows]
    .map(r => r.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(','))
    .join('\n');

  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
  a.download = 'pingin_profiles_' + new Date().toISOString().slice(0,10) + '.csv';
  a.click();
  URL.revokeObjectURL(a.href);
  addLog('CSV exported · ' + S.profiles.length + ' profiles');
  showStatus('✓ Exported ' + S.profiles.length + ' profiles to CSV', 'success');
}


async function exportXLSX() {
  if (!S.profiles.length) { alert('No profiles to export.'); return; }
  // Build CSV and trigger download as xlsx-compatible
  const headers = ['Name','Role','Company','City','Degree','OTW','Score','Profile URL','Status','Scraped At'];
  const rows = S.profiles.map(p => {
    const score = scoreProfile(p, S.lastSearchParams);
    return [
      p.name||'', p.role||'', p.company||'', p.city||'',
      p.degree||'', p.isOTW?'Yes':'No', score,
      p.profileUrl||'', p.status||'', p.scrapedAt||''
    ].map(v => '"'+String(v).replace(/"/g,'""')+'"').join(',');
  });
  const csv = [headers.join(','), ...rows].join('\n');
  const blob = new Blob(['\uFEFF'+csv], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'pingin_profiles_'+new Date().toISOString().slice(0,10)+'.csv';
  a.click(); URL.revokeObjectURL(url);
  addLog('Exported '+S.profiles.length+' profiles as CSV/Excel');
}


async function clearProfiles(){
  if(!confirm('Clear all '+S.profiles.length+' profiles?'))return;
  S.profiles=[];S.sent=0;S.failed=0;
  await chrome.storage.local.set({profiles:[],sent:0,failed:0});
  renderProfiles();updateStats();addLog('Profiles cleared');
}


async function saveCurrentSearch(){
  const params={
    keywords:   document.getElementById('s-keywords').value.trim(),
    location:   document.getElementById('s-location').value,
    degree:     document.getElementById('s-degree').value,
    experience: document.getElementById('s-experience').value,
    profileType:document.getElementById('s-profile-type').value,
    college:    document.getElementById('s-college').value,
    company:    getCompanySearchString(),
    companyList: getCompanyList(),
    savedAt:    new Date().toISOString(),
  };
  if(!params.keywords){showStatus('Nothing to save — enter keywords first.','warning');return;}
  const data=await chrome.storage.local.get('savedSearches');
  const saved=data.savedSearches||[];
  saved.unshift(params);
  if(saved.length>20)saved.pop();
  await chrome.storage.local.set({savedSearches:saved});
  showStatus('✓ Search saved!','success');
  addLog('Search saved: "'+params.keywords+'"');
}


async function startSearch(){
  // Check plan
  if (S.plan === 'expired') {
    showStatus('Your plan has expired. Please renew at pingin.in/pricing.html', 'warning');
    window.open('https://pingin.in/pricing.html');
    return;
  }
  let keywords=document.getElementById('s-keywords').value.trim();
  if(!keywords){showStatus('Enter a keyword or job title first.','warning');document.getElementById('s-keywords').focus();return;}

  // ── Smart exact-phrase wrapping ──────────────────────────────────
  // If user typed a multi-word title WITHOUT quotes and WITHOUT AND/OR/NOT
  // → auto-wrap in quotes for exact match
  // e.g. "Staff Engineer" → ensures exact title match, not Staff AND Engineer
  const hasBoolOp = /(AND|OR|NOT)|["()]/.test(keywords);
  if (!hasBoolOp && keywords.includes(' ')) {
    keywords = `"${keywords}"`;
    // Update the input to show user what's being searched
    document.getElementById('s-keywords').value = keywords;
  }

  const location   =document.getElementById('s-location').value;
  const degree     =document.getElementById('s-degree').value;
  const experience =document.getElementById('s-experience').value;
  const profileType=document.getElementById('s-profile-type').value;
  const college    =document.getElementById('s-college').value;
  const degreeType =document.getElementById('s-degree-type')?.value||'';
  // Multi-company: get OR-joined string from chip list
  const company = getCompanySearchString();
  const salaryRange  = document.getElementById('s-salary-range')?.value||'';
  const diversityOn = document.getElementById('diversity-toggle')?.checked||false;
  const diversityFilters = diversityOn ? ['women'] : [];

  // Save params for multi-page
  S.lastSearchParams={keywords,location,degree,experience,profileType,college,degreeType,company,salaryRange,diversityFilters};
  await chrome.storage.local.set({lastSearchParams:S.lastSearchParams});
  S.currentPage=1;

  const searchUrl=buildSearchUrl(keywords,location,degree,experience,profileType,college,company,1,salaryRange,diversityFilters);
  const btn=document.getElementById('btn-search');
  btn.disabled=true;
  btn.innerHTML='<span style="display:inline-block;animation:spin 1s linear infinite">⟳</span> Searching...';

  await saveToHistory({keywords,location,degree,experience,profileType,college,degreeType,company,salaryRange,diversityFilters,searchedAt:new Date().toISOString()});
  const salaryLabel    = salaryRange ? ' · '+salaryRange.replace(/_/g,' ') : '';
  const diversityLabel = diversityFilters.length ? ' · 🌈 '+diversityFilters.join('+') : '';
  const coList = getCompanyList();
  const coLabel = coList.length ? ' · @['+coList.join(', ')+']' : (company ? ' · @'+company : '');
  addLog('Search: "'+keywords+'"'+(location?' · '+location:'')+coLabel+salaryLabel+diversityLabel);
  showStatus('Navigating to LinkedIn...','info');

  try{
    // Save pending scrape — service worker picks this up when LinkedIn loads
    await chrome.storage.local.set({
      pendingScrape: {
        url:         searchUrl,
        params:      S.lastSearchParams,
        page:        1,
        isNewSearch: true,
        requestedAt: Date.now(),
      }
    });

    // Reuse existing LinkedIn tab — no new tabs piling up
    try {
      const allTabs = await chrome.tabs.query({});
      const liTab   = allTabs.find(t =>
        t.url && (
          t.url.includes('linkedin.com/search') ||
          t.url.includes('linkedin.com/in/')    ||
          t.url.includes('linkedin.com/feed')   ||
          t.url.includes('linkedin.com/mynetwork')
        )
      );
      if (liTab) {
        await chrome.tabs.update(liTab.id, { url: searchUrl, active: true });
        showStatus('LinkedIn tab updated. Wait for it to load, then click Collect Profiles.','info');
      const collectBtn = document.getElementById('btn-collect');
      if (collectBtn) collectBtn.style.display = 'block';
      } else {
        await chrome.tabs.create({ url: searchUrl, active: true });
        showStatus('LinkedIn opening... Come back here and click Collect Profiles.','success');
        const collectBtn2 = document.getElementById('btn-collect');
        if (collectBtn2) {
          collectBtn2.disabled = false;
          collectBtn2.style.cursor = 'pointer';
          collectBtn2.style.background = 'linear-gradient(135deg,#0055CC,#0099DD)';
          collectBtn2.style.border = 'none';
          collectBtn2.style.color = '#fff';
          collectBtn2.textContent = '📥 Step 2 — Get Profiles from Page';
        }
      }
    } catch(e) {
      await chrome.tabs.create({ url: searchUrl, active: true });
      showStatus('LinkedIn opening... Reopen PingIN to see profiles.','success');
    }
    resetSearchBtn();

  }catch(e){
    showStatus('Error: '+e.message,'error');
    addLog('Search error: '+e.message);
    resetSearchBtn();
  }
}


async function doScrape(tabId, params, page) {
  try {
    showStatus('Collecting profiles from page...', 'info');

    // Pass tabId directly so service worker scrapes the right tab
    const resp = await chrome.runtime.sendMessage({ action: 'MANUAL_SCRAPE', tabId });

    if (resp?.ok) {
      await syncFromStorage();

      const scrapeInfo = document.getElementById('scrape-info');
      if (scrapeInfo) {
        scrapeInfo.style.display = 'block';
        const siCount = document.getElementById('si-count');
        const siPages = document.getElementById('si-pages');
        if (siCount) siCount.textContent = S.profiles.length + ' profiles collected';
        if (siPages) siPages.textContent = 'Page ' + page;
      }

      const nextBtn = document.getElementById('btn-next-page');
      if (nextBtn) nextBtn.style.display = 'block';

      addLog('Page ' + page + ': +' + resp.added + ' profiles · "' + (params?.keywords||'') + '"');
      showStatus('✓ ' + resp.added + ' new profiles added! Total: ' + resp.total, 'success');

      renderProfiles();
      updateStats();

      setTimeout(() => document.querySelector('[data-tab="profiles"]')?.click(), 1200);
    } else {
      showStatus('Trying direct scrape...', 'info');
      await collectProfilesNow();
    }
  } catch(e) {
    console.error('[PingIN] doScrape error:', e);
    await collectProfilesNow();
  }
}


// ═══════════════════════════════════════════════════════════════
//  CLONE SEARCH — Rewritten for new screen structure
// ═══════════════════════════════════════════════════════════════
async function initCloneSearch() {
  const analyseBtn = document.getElementById('clone-analyse-btn');
  const urlInput   = document.getElementById('clone-url-input');
  const resultDiv  = document.getElementById('clone-result');
  const loadingBox = document.getElementById('clone-loading-box');
  const errorBox   = document.getElementById('clone-error');
  const searchBtn  = document.getElementById('clone-search-btn');

  if (!analyseBtn) return;
  analyseBtn.addEventListener('click', () => runCloneAnalyse());
  urlInput?.addEventListener('keydown', e => { if(e.key==='Enter') runCloneAnalyse(); });

  searchBtn?.addEventListener('click', async () => {
    // Check manual role input first — user may have typed there
    var manualRoleEl = document.getElementById('clone-manual-role');
    var manualRole = (manualRoleEl?.value || '').trim();

    if (!window._cloneSearchParams) {
      showCloneError('Please analyse a profile first.');
      return;
    }

    // If manual role was entered, update the params
    if (manualRole) {
      window._cloneSearchParams.keywords = manualRole;
      window._cloneSearchParams.tags = [{ label: '🔍 ' + manualRole, type: 'blue' }];
    }

    // Still no keywords? Don't block — use a sensible default
    if (!window._cloneSearchParams.keywords?.trim()) {
      var name = window._cloneSearchParams?.profileData?.name || '';
      if (!name) { showCloneError('Enter a role in the box above to search.'); return; }
      // Use name as last resort but warn user
      window._cloneSearchParams.keywords = name;
    }

    searchBtn.disabled = true;
    searchBtn.textContent = '⟳ Opening LinkedIn...';
    try {
      await applyCloneSearch(window._cloneSearchParams);
    } finally {
      searchBtn.disabled = false;
      searchBtn.innerHTML = '🧬 Search Similar Profiles on LinkedIn →';
    }
  });

  // ── Profile scraper function — reusable for both active tab and background tab ──
  async function scrapeLinkedInProfile(tabId) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          try {
            const d = {};
            // NAME
            const nameSels = ['h1.text-heading-xlarge','h1[class*="t-24"]','h1[class*="heading"]','h1[class*="inline"]','.pv-top-card--list h1','.ph5 h1','main h1','h1'];
            for (const s of nameSels) {
              const t = document.querySelector(s)?.textContent?.trim();
              if (t && t.length > 1 && t.length < 80) { d.name = t; break; }
            }
            if (!d.name) { const pt = document.title.split('|')[0].replace(/\s+/g,' ').trim(); if (pt && pt !== 'LinkedIn' && pt.length > 1) d.name = pt; }
            if (!d.name) { const og = document.querySelector('meta[property="og:title"]')?.content; if (og) d.name = og.split('|')[0].trim(); }

            // HEADLINE — 2025-26 LinkedIn uses many possible class combos
            // Strategy A: well-known class selectors (try all variants)
            const hlSels = [
              '.text-body-medium.break-words',
              '[class*="text-body-medium"][class*="break-words"]',
              '.pv-text-details__left-panel .text-body-medium',
              '.ph5 .text-body-medium',
              '.pv-top-card--list .text-body-medium',
              'div.text-body-medium.break-words',
              '.artdeco-card .text-body-medium',
              'section.artdeco-card .pv-text-details__left-panel div',
              '.pv-top-card .ph5 div.text-body-medium',
              '.scaffold-layout__main h2',
              'div[class*="t-16"][class*="t-black"]',
              'div[class*="t-16"][class*="break-words"]',
              '.pv-top-card h2',
              'h2.text-heading-large',
              '.profile-info-subheader',
            ];
            for (const s of hlSels) {
              const t = document.querySelector(s)?.textContent?.trim();
              if (t && t.length > 4 && t.length < 300 && !t.includes('linkedin.com') && !t.match(/^\d+\s+follower/i)) { d.headline = t; break; }
            }

            // Strategy B: scan ALL div/span text nodes for headline-looking string
            // Catches complex headlines like "Generative AI | AI/ML Leadership | MLOps"
            // and HR headlines like "Human Resources @ Tata Electronics"
            if (!d.headline) {
              const ROLE_HINT = /(engineer|manager|developer|analyst|scientist|director|lead|designer|architect|consultant|specialist|recruiter|officer|founder|head|vp|cto|ceo|intern|associate|executive|product|data|software|senior|junior|principal|generative|learning|capability|enterprise|transformation|hr|human|resources|talent|acquisition|operations|strategy|leadership|enablement|workforce|ai|ml|mlops|devops|cloud|fullstack|frontend|backend|platform|infra|security|mobile|sre)\b/i;
              const topCard = document.querySelector('main, .scaffold-layout__main, body');
              if (topCard) {
                const divs = Array.from(topCard.querySelectorAll('div,span,p')).slice(0, 120);
                for (const el of divs) {
                  const t = el.textContent?.trim() || '';
                  if (t.length < 5 || t.length > 400) continue;
                  if (t.includes('linkedin.com')) continue;
                  if (t.match(/^\d+/)) continue;
                  if (!ROLE_HINT.test(t)) continue;
                  // Accept leaf nodes OR nodes that look like headlines (contain | or @)
                  const isLeaf = el.children.length === 0;
                  const looksLikeHeadline = t.includes('|') || t.includes('@') || t.includes('·');
                  if (isLeaf || looksLikeHeadline) {
                    d.headline = t; break;
                  }
                }
              }
            }

            // Strategy C: og:description meta tag — LinkedIn sets this to
            // "Name | Role at Company - LinkedIn" or "Name | Headline - LinkedIn"
            if (!d.headline) {
              const ogD = document.querySelector('meta[property="og:description"]')?.content || '';
              // og:description format: "Name | Part1 | Part2 | ... - LinkedIn"
              const ogClean = ogD.replace(/-?\s*LinkedIn\s*$/, '').trim();
              const parts   = ogClean.split('|').map(p => p.trim()).filter(Boolean);
              if (parts.length >= 2) {
                // Skip first part (usually the name), take the rest as headline
                // e.g. "Kirtesh Tiwari | Generative AI | AI/ML Leadership | MLOps"
                // → take "Generative AI | AI/ML Leadership | MLOps"
                const headlineParts = parts.slice(1)
                  .filter(p => !p.match(/^\d+\s*(follower|connection)/i)) // skip "116k followers" etc
                  .filter(p => p.length > 2);
                if (headlineParts.length > 0) {
                  // Join with | to preserve full context for the parser
                  const candidate = headlineParts.join(' | ').substring(0, 300);
                  d.headline = candidate;
                }
              }
            }

            // Strategy D: page title "Name | Role - LinkedIn" 
            if (!d.headline) {
              const titleParts = document.title.split('|');
              if (titleParts.length >= 2) {
                const candidate = titleParts[1].replace(/-?\s*LinkedIn\s*$/, '').trim();
                if (candidate.length > 3 && candidate.length < 200 && !candidate.includes('LinkedIn')) d.headline = candidate;
              }
            }

            // LOCATION
            const locSels = ['.pb2.pv-top-card--list span.text-body-small','.pv-top-card--list .text-body-small','.pv-text-details__left-panel span.t-black--light','.ph5 span.t-black--light'];
            for (const s of locSels) {
              for (const el of document.querySelectorAll(s)) {
                const t = el?.textContent?.trim();
                if (t && (t.includes('India')||/\b(Hyderabad|Mumbai|Bangalore|Bengaluru|Delhi|Pune|Chennai|Noida|Gurgaon|Kolkata)\b/i.test(t))) { d.location=t; break; }
              }
              if (d.location) break;
            }

            // EXPERIENCE
            for (const s of ['#experience ~ .pvs-list__outer-container .pvs-entity','[id="experience"] ~ div .pvs-entity','section[id*="experience"] .pvs-entity']) {
              const cnt = document.querySelectorAll(s).length;
              if (cnt > 0) { d.experienceCount=cnt; break; }
            }
            // SCHOOL
            for (const s of ['#education ~ .pvs-list__outer-container .pvs-entity .mr1 span[aria-hidden="true"]','[id="education"] ~ div .pvs-entity span[aria-hidden="true"]']) {
              const t = document.querySelector(s)?.textContent?.trim();
              if (t) { d.school=t; break; }
            }
            // SKILLS
            for (const s of ['#skills ~ .pvs-list__outer-container .pvs-entity .mr1 span[aria-hidden="true"]','[id="skills"] ~ div .pvs-entity span[aria-hidden="true"]']) {
              const els = Array.from(document.querySelectorAll(s)).slice(0,5).map(el=>el.textContent.trim()).filter(Boolean);
              if (els.length) { d.skills=els; break; }
            }
            // COMPANY
            const expEls = document.querySelectorAll('#experience ~ .pvs-list__outer-container .pvs-entity, [id="experience"] ~ div .pvs-entity');
            if (expEls.length > 0) { const spans=expEls[0].querySelectorAll('span[aria-hidden="true"]'); if(spans.length>=2) d.company=spans[1]?.textContent?.trim()||''; }
            d.isOTW = !!(document.querySelector('.pv-member-badge--opentowork, [class*="open-to-work"], [class*="openToWork"]'));
            return d;
          } catch(e) { return {_error:e.message}; }
        }
      });
      return results?.[0]?.result || null;
    } catch(e) { return null; }
  }

  async function runCloneAnalyse() {
    const url = (urlInput?.value || '').trim();
    if (!url) { showCloneError('Please paste a LinkedIn profile URL.'); return; }
    const username = extractLinkedInUsername(url);
    if (!username) { showCloneError('Invalid URL. Use: linkedin.com/in/username'); return; }

    if (resultDiv)  resultDiv.style.display = 'none';
    if (errorBox)   { errorBox.style.display = 'none'; errorBox.classList.remove('show'); }
    if (loadingBox) { loadingBox.className = 'info-box info show'; loadingBox.innerHTML = '<span class="spinning">⟳</span> Reading profile...'; }
    analyseBtn.disabled = true;
    analyseBtn.textContent = '⟳';

    try {
      const profileUrl = url.startsWith('http') ? url : 'https://www.linkedin.com/in/'+username;
      let profile = null;

      // ── STEP 1: Try to read from any EXISTING open tab with this profile ──
      // User is likely already on this profile page — much more reliable than bg tab
      try {
        const allTabs = await chrome.tabs.query({});
        const matchingTab = allTabs.find(t =>
          t.url && (
            t.url.includes('/in/'+username) ||
            t.url.includes('/in/'+username+'/')
          )
        );
        if (matchingTab) {
          if (loadingBox) loadingBox.innerHTML = '<span class="spinning">⟳</span> Reading from open profile tab...';
          profile = await scrapeLinkedInProfile(matchingTab.id);
          if (profile?._error) profile = null;
        }
      } catch(e) {}

      // ── STEP 2: If not found in existing tabs, open background tab ──
      if (!profile?.name) {
        if (loadingBox) loadingBox.innerHTML = '<span class="spinning">⟳</span> Opening profile in background...';
        try {
          const bgTab = await chrome.tabs.create({ url: profileUrl, active: false });
          await new Promise(resolve => {
            const maxWait = setTimeout(resolve, 10000);
            const listener = (tabId, info) => {
              if (tabId === bgTab.id && info.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(listener);
                clearTimeout(maxWait);
                setTimeout(resolve, 3000);
              }
            };
            chrome.tabs.onUpdated.addListener(listener);
          });
          if (loadingBox) loadingBox.innerHTML = '<span class="spinning">⟳</span> Analysing profile with AI...';
          profile = await scrapeLinkedInProfile(bgTab.id);
          if (profile?._error) profile = null;
          try { await chrome.tabs.remove(bgTab.id); } catch(e) {}
        } catch(e) {}
      }

      // ── STEP 3: Use whatever we got ──
      if (profile?.name) {
        await showCloneResult(profile, username);
      } else {
        // Couldn't scrape — use clean name from slug, show manual role box
        var slugName = cleanNameFromSlug(username);
        var emptyProfile = { name: slugName || username.replace(/-/g,' '), headline:'', location:'', experienceCount:0, school:'', skills:[], isOTW:false, _noScrape:true };
        await showCloneResult(emptyProfile, username);
      }

    } catch(e) {
      // Outer catch — something unexpected failed
      var slugName2 = cleanNameFromSlug(username);
      var ep2 = { name: slugName2 || username.replace(/-/g,' '), headline:'', location:'', experienceCount:0, school:'', skills:[], isOTW:false, _noScrape:true };
      await showCloneResult(ep2, username);
    } finally {
      if (loadingBox) { loadingBox.className = 'info-box'; loadingBox.style.display = 'none'; }
      analyseBtn.disabled = false;
      analyseBtn.textContent = '🔍 Analyse';
    }
  }  // end runCloneAnalyse


  async function showCloneResult(profile, username) {
    let params;
    try {
      params = buildCloneSearchFromProfile(profile);
    } catch(e) {
      params = { keywords:'', location:'', experience:'3', tags:[], profileData:profile };
    }
    window._cloneSearchParams = params;

    const initials = (profile.name||'?').split(' ').map(n=>n[0]||'').join('').slice(0,2).toUpperCase() || 'DS';
    const card = document.getElementById('clone-profile-card');
    if (card) card.innerHTML = '<div class="clone-av">'+initials+'</div><div><div class="clone-name-text">'+(profile.name||'Profile')+'</div><div class="clone-role-text">'+(profile.headline||'—')+'</div></div>';

    const tagsEl = document.getElementById('clone-tags');
    if (tagsEl) {
      if (params.tags && params.tags.length) {
        tagsEl.innerHTML = params.tags.map(t=>'<span class="clone-tag '+(t.type||'blue')+'">'+t.label+'</span>').join('');
      } else {
        tagsEl.innerHTML = '<span class="clone-tag blue" style="opacity:.5;">No role extracted yet</span>';
      }
    }

    // Show manual role box if no headline was found
    var manualBox = document.getElementById('clone-manual-role-box');
    var manualInput = document.getElementById('clone-manual-role');
    var reasonEl = document.getElementById('clone-reason-text');
    var noHeadline = !profile.headline || profile._noScrape;

    if (manualBox) manualBox.style.display = noHeadline ? 'block' : 'none';

    // Pre-fill manual role input
    if (manualInput && noHeadline) {
      // Priority: extracted keywords → then clear so user knows to type
      var prefill = (params.keywords || '').replace(/"/g,'').trim();
      manualInput.value = prefill;
      // Auto-focus so user can type immediately
      if (!prefill) setTimeout(function(){ manualInput.focus(); }, 100);
    }

    // Wire manual role input → update search params live
    if (manualInput) {
      manualInput.oninput = function() {
        var roleVal = (manualInput.value || '').trim();
        if (!roleVal) return;
        window._cloneSearchParams = Object.assign({}, window._cloneSearchParams, {
          keywords: roleVal,
          tags: [
            { label: '🔍 ' + roleVal, type: 'blue' },
            ...(params.location ? [{ label: '📍 ' + params.location, type: 'green' }] : []),
          ],
          profileData: profile,
        });
        if (tagsEl) {
          tagsEl.innerHTML = window._cloneSearchParams.tags
            .map(t => '<span class="clone-tag '+(t.type||'blue')+'">'+t.label+'</span>').join('');
        }
      };
      // Enter key triggers search
      manualInput.onkeydown = function(e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          document.getElementById('clone-search-btn')?.click();
        }
      };
    }

    if (reasonEl) reasonEl.style.display = 'none';
    if (resultDiv) resultDiv.style.display = 'block';
  }

  function showCloneFallback(username) {
    // Clean the username — strip trailing auto-generated LinkedIn IDs
    var cleanName = cleanNameFromSlug(username);
    var displayName = cleanName || username.replace(/-/g,' ');
    window._cloneSearchParams = {
      keywords: '"' + displayName + '"',
      location: '',
      experience: '3',
      tags: [{label:'🔍 ' + displayName, type:'blue'}],
      profileData: {name: displayName, headline:''}
    };
    const card = document.getElementById('clone-profile-card');
    if (card) card.innerHTML = '<div class="clone-av">?</div><div><div class="clone-name-text">' + displayName + '</div><div class="clone-role-text">Basic search mode — profile not scraped</div></div>';
    const tagsEl = document.getElementById('clone-tags');
    if (tagsEl) tagsEl.innerHTML = '<span class="clone-tag blue">🔍 ' + displayName + '</span>';
    if (resultDiv) resultDiv.style.display = 'block';
  }

  function showCloneError(msg) {
    if (errorBox) { errorBox.className='info-box warning show'; errorBox.textContent='⚠️ '+msg; }
  }
}


// ═══════════════════════════════════════════════════════════════
//  JD SEARCH — Rewritten for new screen structure
// ═══════════════════════════════════════════════════════════════
async function initJDSearch() {
  const analyseBtn = document.getElementById('btn-jd-analyse');
  const searchBtn  = document.getElementById('btn-jd-search');
  const statusBox  = document.getElementById('jd-status');
  const tagsEl     = document.getElementById('jd-tags');
  const parsedRes  = document.getElementById('jd-parsed-result');
  const fileInput  = document.getElementById('jd-file');
  const fileBtn    = document.getElementById('jd-file-btn');
  const fileName   = document.getElementById('jd-file-name');

  // File upload
  fileBtn?.addEventListener('click', () => fileInput?.click());
  fileInput?.addEventListener('change', () => {
    const file = fileInput?.files?.[0];
    if (!file) return;
    if (fileName) fileName.textContent = file.name;
    if (file.name.endsWith('.txt')) {
      const reader = new FileReader();
      reader.onload = e => {
        const ta = document.getElementById('jd-text');
        if (ta) ta.value = e.target.result;
        showJDStatus('✓ File loaded! Click Analyse JD.', 'success');
      };
      reader.readAsText(file);
    } else {
      showJDStatus('⚠️ Only .txt files supported. Please copy-paste PDF/Word JD text below.', 'warning');
    }
  });

  // JD URL — Step 1: Open in foreground tab, SAVE tab id for extraction
  document.getElementById('btn-jd-open')?.addEventListener('click', async () => {
    const url = (document.getElementById('jd-url-input')?.value||'').trim();
    if (!url || !url.startsWith('http')) {
      showJDStatus('Enter a valid URL starting with https://', 'warning'); return;
    }
    const tab = await chrome.tabs.create({ url, active: true });
    // Save the tab ID so Extract button can find it even after popup reopens
    await chrome.storage.local.set({ jdExtractTabId: tab.id, jdExtractUrl: url });
    showJDStatus('✓ Job page opened in new tab — wait for it to load, reopen PingIN, then click Step 2', 'info');
  });

  // JD URL — Step 2: Extract JD from saved tab or active tab
  document.getElementById('btn-jd-extract')?.addEventListener('click', async () => {
    const extractBtn = document.getElementById('btn-jd-extract');
    extractBtn.disabled = true;
    extractBtn.textContent = '⏳ Step 2 — Extracting...';
    showJDStatus('Reading job page...', 'info');

    try {
      // Try saved tab ID first (from Open button), then fall back to active tab
      const stored = await chrome.storage.local.get(['jdExtractTabId']);
      let targetTabId = null;

      if (stored.jdExtractTabId) {
        try {
          const savedTab = await chrome.tabs.get(stored.jdExtractTabId);
          if (savedTab && !savedTab.discarded) targetTabId = savedTab.id;
        } catch(e) { /* tab was closed */ }
      }

      if (!targetTabId) {
        // Fall back to current active tab
        const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
        targetTabId = activeTab?.id;
      }

      if (!targetTabId) {
        showJDStatus('⚠️ Could not find the job page tab. Open the job URL first, then click Extract.', 'warning');
        extractBtn.disabled = false; extractBtn.textContent = 'Step 2 — Extract JD from this page'; return;
      }

      const results = await chrome.scripting.executeScript({
        target: { tabId: targetTabId },
        func: () => {
          // ── LinkedIn job page selectors (2024-25 DOM) ──────────────────────
          // LinkedIn keeps changing class names. Use multiple strategies.

          // Strategy 1: Direct ID selectors (most stable)
          const byId = ['job-details','jobDescriptionModule','job-description'];
          for (const id of byId) {
            const el = document.getElementById(id);
            if (el?.innerText?.trim().length > 100) return el.innerText.trim();
          }

          // Strategy 2: LinkedIn-specific class patterns
          const liSelectors = [
            '[class*="jobs-description__content"]',
            '[class*="description__text"]',
            '[class*="job-details-jobs-unified-top-card"]',
            '[class*="jobs-description-content"]',
            'section[class*="description"]',
            '.jobs-box__html-content',
            '[class*="show-more-less-html"]',
          ];
          for (const sel of liSelectors) {
            try {
              const el = document.querySelector(sel);
              if (el?.innerText?.trim().length > 100) return el.innerText.trim().substring(0, 6000);
            } catch(e) {}
          }

          // Strategy 3: Find the JD by scanning for "About the job" or "Responsibilities" heading
          const allEls = Array.from(document.querySelectorAll('section, article, div'));
          const jdAnchors = ['About the job', 'Job description', 'About this role',
                             'Responsibilities', 'Requirements', 'Qualifications', 'What you'];
          for (const el of allEls) {
            const text = el.innerText || '';
            if (text.length > 200 && jdAnchors.some(a => text.includes(a))) {
              // Don't take the whole page — find the smallest container that has JD text
              if (text.length < 8000) return text.substring(0, 6000);
            }
          }

          // Strategy 4: Job board specific selectors
          const boardSelectors = [
            // Naukri
            '.job-desc', '.jd-desc-container', '.dang-inner-html',
            // Indeed
            '#jobDescriptionText', '.jobsearch-jobDescriptionText', '.jobDescriptionContent',
            // Foundit / Monster
            '.job-desc-detail', '.jdescription',
            // Internshala
            '.internship_other_details_container',
            // Instahyre
            '.job-description',
          ];
          for (const sel of boardSelectors) {
            try {
              const el = document.querySelector(sel);
              if (el?.innerText?.trim().length > 100) return el.innerText.trim().substring(0, 6000);
            } catch(e) {}
          }

          // Strategy 5: Biggest text block that looks like a JD
          const blocks = Array.from(document.querySelectorAll('div, section, article'))
            .map(el => ({ el, text: (el.innerText || '').trim() }))
            .filter(b => b.text.length > 300 && b.text.length < 10000 &&
              /responsibilit|qualif|experience|requirement|skill|about the job/i.test(b.text))
            .sort((a,b) => {
              // Prefer smaller containers (more specific) over large ones (full page)
              const diff = Math.abs(a.text.length - 2000) - Math.abs(b.text.length - 2000);
              return diff;
            });
          if (blocks.length > 0) return blocks[0].text.substring(0, 6000);

          return '';
        }
      });

      const raw = (results?.[0]?.result || '').trim();
      // Clean navigation/footer noise
      const cleaned = raw.split('\n')
        .filter(l => {
          const t = l.trim().toLowerCase();
          return t.length > 0 &&
            !t.includes('sign in') && !t.includes('sign up') &&
            !t.includes('privacy') && !t.includes('cookie') &&
            !t.includes('copyright') && !t.startsWith('©') &&
            !t.includes('linkedin corporation') && !t.includes('talent solutions') &&
            !t.includes('show more') && !t.includes('see more') &&
            !t.includes('activate premium') && !t.includes('dismiss');
        })
        .join('\n').trim();

      if (cleaned.length > 100) {
        const ta = document.getElementById('jd-text');
        if (ta) ta.value = cleaned;
        await chrome.storage.local.remove('jdExtractTabId');
        showJDStatus(`✅ JD extracted (${cleaned.length} chars) — click Analyse JD to continue`, 'success');
      } else {
        showJDStatus('⚠️ Could not read JD text. Please copy the job description and paste it in the box below.', 'warning');
      }
    } catch(e) {
      showJDStatus('⚠️ Extraction failed — please copy-paste the JD text manually.', 'warning');
      console.log('[PingIN] JD extract error:', e.message);
    }
    extractBtn.disabled = false;
    extractBtn.textContent = 'Step 2 — Extract JD from this page';
  });

  // Analyse JD
  analyseBtn?.addEventListener('click', async () => {
    const text = document.getElementById('jd-text')?.value?.trim();
    if (!text || text.length < 30) {
      showJDStatus('Please paste a job description first.', 'warning'); return;
    }
    analyseBtn.disabled = true;
    analyseBtn.innerHTML = '<span class="spinning">⟳</span> Analysing with AI...';
    showJDStatus('🤖 AI is reading the JD...', 'info');
    try {
      const extracted = await extractFromJD(text);
      window._jdExtracted = extracted;
      showJDResult(extracted);
    } catch(e) {
      showJDStatus('Error: '+e.message, 'warning');
    } finally {
      analyseBtn.disabled = false;
      analyseBtn.textContent = '🤖 Analyse JD with AI';
    }
  });

  // Find candidates
  searchBtn?.addEventListener('click', async () => {
    if (!window._jdExtracted) return;
    searchBtn.disabled = true;
    searchBtn.innerHTML = '<span class="spinning">⟳</span> Opening LinkedIn...';
    await applyJDToSearch(window._jdExtracted);
    searchBtn.disabled = false;
    searchBtn.textContent = '📄→👥 Find Candidates';
  });

  function showJDStatus(msg, type) {
    if (!statusBox) return;
    statusBox.className = 'info-box '+type+' show';
    statusBox.textContent = msg;
  }

  function showJDResult(ext) {
    if (!tagsEl || !parsedRes) return;
    const tags = [];
    if (ext.title || ext.keywords) tags.push({ label:'💼 '+(ext.title||ext.keywords), cls:'' });
    if (ext.experience) tags.push({ label:'⏱ '+ext.experience, cls:'amber' });
    if (ext.locations && ext.locations.length > 1) {
      tags.push({ label:'📍 '+ext.locations.join(' / '), cls:'green' });
    } else if (ext.location) {
      tags.push({ label:'📍 '+ext.location, cls:'green' });
    }
    if (ext.education) tags.push({ label:'🎓 '+ext.education, cls:'' });
    (ext.topSkills||ext.skills||[]).slice(0,5).forEach(s => tags.push({ label:s, cls:'green' }));
    tagsEl.innerHTML = tags.map(t=>'<span class="jd-tag '+t.cls+'">'+t.label+'</span>').join('');
    parsedRes.style.display = 'block';
    if (statusBox) { statusBox.className = 'info-box'; statusBox.style.display = 'none'; }
    if (searchBtn) searchBtn.style.display = 'block';
    if (analyseBtn) analyseBtn.textContent = '🔄 Re-analyse';
  }
}


// ═══════════════════════════════════════════════════════════════
//  PLATFORM SEARCH
// ═══════════════════════════════════════════════════════════════
async function initPlatformSearch() {

  // ══════════════════════════════════════════════
  //  FEATURE 1 — GitHub Smart Search
  // ══════════════════════════════════════════════
  // ── GitHub skill input live query preview ────────────────────────────────
  function buildGhQuery() {
    const s1 = (document.getElementById('gh-skill1')?.value || '').trim();
    const s2 = (document.getElementById('gh-skill2')?.value || '').trim();
    const s3 = (document.getElementById('gh-skill3')?.value || '').trim();
    const loc = (document.getElementById('gh-location')?.value || '').trim();
    const minF = parseInt(document.getElementById('gh-followers')?.value || '0') || 0;
    const minR = parseInt(document.getElementById('gh-repos')?.value    || '0') || 0;

    const skills = [s1, s2, s3].filter(Boolean);
    let q = skills.join(' ');
    if (loc)    q += ' location:' + loc;
    if (minF > 0) q += ' followers:>=' + minF;
    if (minR > 0) q += ' repos:>='    + minR;

    const preview = document.getElementById('gh-query-preview');
    if (preview) {
      if (q.trim()) {
        preview.style.display = 'block';
        preview.textContent = 'GitHub search: ' + q;
      } else {
        preview.style.display = 'none';
      }
    }
    return { skills, q };
  }

  ['gh-skill1','gh-skill2','gh-skill3','gh-location','gh-followers','gh-repos'].forEach(id => {
    document.getElementById(id)?.addEventListener('input', buildGhQuery);
  });

  document.getElementById('btn-github-search')?.addEventListener('click', async () => {
    const { skills, q } = buildGhQuery();

    if (!skills.length || !skills[0]) {
      showPlatStatus('Enter at least Skill 1 — e.g. React, Python, Java', 'warning');
      document.getElementById('gh-skill1')?.focus();
      return;
    }

    if (skills.length > 3) {
      showPlatStatus('Maximum 3 skills supported for GitHub search.', 'warning');
      return;
    }

    const url = 'https://github.com/search?q=' + encodeURIComponent(q.trim()) +
                '&type=users&s=followers&o=desc';

    await chrome.tabs.create({ url, active: true });
    addLog('GitHub search: ' + skills.join(' + ') + (document.getElementById('gh-location')?.value?.trim() ? ' · ' + document.getElementById('gh-location').value.trim() : ''));
    showPlatStatus('✓ GitHub opened — results show developers matching ' + skills.join(' + ') + '. Browse profiles and click their LinkedIn link.', 'success');
  });

  // ── Stack Overflow Expert Search via SEDE ────────────────────────────────────
  document.getElementById('btn-so-search')?.addEventListener('click', async () => {
    const tag       = (document.getElementById('so-tag')?.value || '').trim();
    const location  = (document.getElementById('so-location')?.value || '').trim();
    const minRep    = document.getElementById('so-min-rep')?.value || '500';
    const limit     = document.getElementById('so-limit')?.value || '30';
    const goldOnly  = document.getElementById('so-gold-only')?.checked || false;
    const exStudents= document.getElementById('so-exclude-students')?.checked !== false;
    const statusEl  = document.getElementById('so-status');
    const resultsEl = document.getElementById('so-results');
    const listEl    = document.getElementById('so-profiles-list');
    const searchBtn = document.getElementById('btn-so-search');

    if (!tag) {
      if (statusEl) { statusEl.textContent = '⚠️ Enter a skill tag (e.g. java, react, python)'; statusEl.style.color='#f59e0b'; }
      document.getElementById('so-tag')?.focus();
      return;
    }

    searchBtn.disabled = true;
    searchBtn.textContent = '⏳ Searching Stack Overflow...';
    if (statusEl) { statusEl.textContent = 'Querying Stack Exchange database...'; statusEl.style.color='var(--ts)'; }
    if (resultsEl) resultsEl.style.display = 'none';

    try {
      // Call Stack Exchange API directly (no Worker needed)
      if (statusEl) { statusEl.textContent = 'Step 1: Getting top ' + tag + ' experts...'; statusEl.style.color='var(--ts)'; }
      
      // Step 1: Top answerers for the tag
      const step1 = await fetch(
        `https://api.stackexchange.com/2.3/tags/${encodeURIComponent(tag.toLowerCase())}/top-answerers/all_time?` +
        `site=stackoverflow&pagesize=100`,
        { headers: { 'Accept': 'application/json' } }
      );
      if (!step1.ok) throw new Error('SE API step1 error: ' + step1.status);
      const answersData = await step1.json();
      const topItems = answersData.items || [];
      if (topItems.length === 0) {
        if (statusEl) { statusEl.textContent = `No results for tag "${tag}". Try a different skill.`; statusEl.style.color='#f59e0b'; }
        searchBtn.disabled = false; searchBtn.textContent = '🔍 Search Stack Overflow Experts';
        return;
      }

      if (statusEl) { statusEl.textContent = `Step 2: Loading profiles for ${topItems.length} experts...`; statusEl.style.color='var(--ts)'; }

      // Step 2: Get user details — try multiple filters until we get location data
      const userIds = topItems.slice(0, 100).map(u => u.user.user_id).join(';');
      let users = [];

      // Try filters in order — SE API needs a specific filter to return location+website
      const filtersToTry = [
        '!9YdnSM*MS',          // includes location (documented in SE wrappers)
        '!-*jbN0IFDdW(b',      // includes location + website_url
        '!*236eb_eL9WT8y',     // full user object
        '',                    // no filter — default fields
      ];

      for (const filt of filtersToTry) {
        const url = `https://api.stackexchange.com/2.3/users/${userIds}?` +
          `site=stackoverflow&order=desc&sort=reputation&pagesize=100` +
          (filt ? `&filter=${encodeURIComponent(filt)}` : '');
        try {
          const r = await fetch(url, { headers: { 'Accept': 'application/json' } });
          if (!r.ok) continue;
          const d = await r.json();
          if (!d.items || d.items.length === 0) continue;
          users = d.items;
          // Check if we actually got location data
          const hasLoc = users.some(u => u.location && u.location.length > 0);
          console.log('[PingIN] SO filter', filt||'default', '→', users.length, 'users, hasLocation:', hasLoc);
          if (hasLoc || filt === '') break;  // found location data or exhausted all filters
        } catch(e) { continue; }
      }

      if (users.length === 0) throw new Error('Could not fetch user details from SE API');

      // ── Location filter ─────────────────────────────────────────────────────
      const INDIA_CITIES = [
        'india','hyderabad','bengaluru','bangalore','mumbai','delhi','new delhi',
        'pune','chennai','madras','kolkata','calcutta','noida','gurgaon','gurugram',
        'ahmedabad','kochi','cochin','chandigarh','jaipur','nagpur','indore','surat',
        'lucknow','mysuru','mysore','coimbatore','visakhapatnam','vizag','bhubaneswar',
        'trivandrum','thiruvananthapuram','patna','vadodara','baroda','rajkot',
        'mohali','panchkula','dehradun','navi mumbai','thane','hyd','blr','mum',
        'karnataka','telangana','maharashtra','andhra','tamil','kerala','india'
      ];
      const locLow = location.toLowerCase().trim();

      // Split users into: location confirmed + location empty
      let locMatched = [], locEmpty = [], locOther = [];
      users.forEach(u => {
        const ul = (u.location || '').toLowerCase().trim();
        if (!ul) { locEmpty.push(u); return; }
        // Check if matches search location
        if (locLow) {
          const isIndia = locLow === 'india' || INDIA_CITIES.includes(locLow);
          const matchesCity = ul.includes(locLow);
          const matchesIndia = isIndia && INDIA_CITIES.some(c => ul.includes(c));
          if (matchesCity || matchesIndia) { locMatched.push(u); return; }
          locOther.push(u);
        } else {
          locMatched.push(u); // no location filter — all match
        }
      });

      // Smart result selection:
      // If we have confirmed location matches → show those
      // If 0 matches but location was specified → show all (location likely not filled on SO)
      let displayUsers;
      if (!locLow) {
        displayUsers = users; // no filter
      } else if (locMatched.length > 0) {
        displayUsers = locMatched;
        if (statusEl) { statusEl.textContent = `Found ${locMatched.length} profiles in ${location} · ${locEmpty.length} more without location`; statusEl.style.color='var(--ts)'; }
      } else {
        // 0 confirmed matches — show ALL sorted: no-location first (likely Indian hidden), then others
        displayUsers = [...locEmpty, ...locOther, ...users.filter(u => !locEmpty.includes(u) && !locOther.includes(u))];
        if (statusEl) {
          statusEl.textContent = `⚠️ No location listed on SO for most ${tag} experts — showing all ${users.length}. Many Indian devs don't fill location on SO.`;
          statusEl.style.color = '#f59e0b';
        }
      }
      users = displayUsers;

      // Min reputation
      users = users.filter(u => (u.reputation || 0) >= parseInt(minRep));
      if (goldOnly) users = users.filter(u => (u.badge_counts?.gold || 0) > 0);

      // Build answer count lookup
      const ansLookup = {};
      topItems.forEach(i => { ansLookup[i.user.user_id] = i.answer_count || 0; });

      // Build profile objects
      const profiles = users.slice(0, parseInt(limit)).map(u => {
        const website     = (u.website_url || '').trim();
        const hasLinkedIn = website.toLowerCase().includes('linkedin.com');
        const hasGitHub   = website.toLowerCase().includes('github.com');
        const gold        = u.badge_counts?.gold   || 0;
        const silver      = u.badge_counts?.silver || 0;
        const answers     = ansLookup[u.user_id] || 0;
        const rep         = u.reputation || 0;
        return {
          name: u.display_name || 'Unknown',
          reputation: rep, location: u.location || '',
          website, profileUrl: u.link || `https://stackoverflow.com/users/${u.user_id}`,
          goldBadges: gold, silverBadges: silver, totalAnswers: answers,
          hasLinkedIn, hasGitHub,
          hasBlog: !hasLinkedIn && !hasGitHub && website.length > 4,
          linkedInUrl: hasLinkedIn ? website : '',
          gitHubUrl:   hasGitHub  ? website : '',
          signalScore: rep + gold*2000 + (answers>100?1000:0) + (hasLinkedIn?500:0),
        };
      }).sort((a,b) => b.signalScore - a.signalScore);

      const displayProfiles = profiles;
      const liCount   = displayProfiles.filter(p => p.hasLinkedIn).length;
      const goldCount = displayProfiles.filter(p => p.goldBadges > 0).length;
      const locCount  = displayProfiles.filter(p => p.location && p.location.length > 0).length;
      if (!statusEl?.textContent?.includes('⚠️')) {
        if (statusEl) { statusEl.textContent = `✅ ${displayProfiles.length} experts · ${locCount} with location · ${liCount} have LinkedIn · ${goldCount} 🥇 gold`; statusEl.style.color='#00d4aa'; }
      }
      const labelEl = document.getElementById('so-results-label');
      if (labelEl) labelEl.textContent = `${profiles.length} Stack Overflow Experts — "${tag}"${location ? ' · ' + location : ''}`;

      listEl.innerHTML = '';
      displayProfiles.forEach(p => {
        const signals = [];
        if (p.goldBadges > 0)     signals.push(`🥇 ${p.goldBadges} gold`);
        if (p.silverBadges > 0)   signals.push(`🥈 ${p.silverBadges} silver`);
        if (p.hasLinkedIn)        signals.push(`<span style="color:#00d4aa;font-weight:600;">🔗 LinkedIn</span>`);
        if (p.hasGitHub)          signals.push(`<span style="color:#38bdf8;font-weight:600;">💻 GitHub</span>`);
        if (p.hasBlog)            signals.push(`🌐 Blog`);
        if (p.totalAnswers > 100) signals.push(`💬 ${p.totalAnswers} ans`);

        const pIdx = profiles.indexOf(p);

        const card = document.createElement('div');
        card.style.cssText = 'background:var(--surf2);border:1px solid var(--border);border-radius:10px;padding:10px 12px;';
        card.innerHTML = `
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:6px;">
            <div style="flex:1;min-width:0;">
              <div style="font-size:13px;font-weight:700;color:var(--tp);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${p.name}</div>
              <div style="font-size:10px;color:var(--ts);margin-top:1px;">${p.location || '<span style="opacity:.4">Location not listed</span>'}</div>
            </div>
            <div style="font-size:12px;font-weight:700;color:#f48024;white-space:nowrap;">⭐ ${p.reputation.toLocaleString()}</div>
          </div>
          ${signals.length > 0 ? `<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px;">${signals.map(s=>`<span style="font-size:9px;background:var(--surf);border:1px solid var(--border2);border-radius:4px;padding:2px 6px;color:var(--ts);">${s}</span>`).join('')}</div>` : ''}
          <div style="display:flex;gap:6px;">
            <button data-url="${p.profileUrl}" data-action="open-so" style="flex:1;padding:6px;font-size:10px;background:transparent;border:1px solid var(--border2);border-radius:7px;color:var(--ts);cursor:pointer;font-family:inherit;">📚 SO Profile</button>
            <button data-pidx="${pIdx}" style="flex:2;padding:6px;font-size:10px;background:linear-gradient(135deg,#0055cc,#38bdf8);border:none;border-radius:7px;color:#fff;font-weight:700;cursor:pointer;font-family:inherit;" class="so-li-btn">${p.hasLinkedIn ? '🔗 Open LinkedIn →' : '🔍 Find on LinkedIn'}</button>
          </div>`;
        listEl.appendChild(card);
      });

      listEl.querySelectorAll('[data-action="open-so"]').forEach(b => {
        b.addEventListener('click', () => chrome.tabs.create({ url: b.dataset.url, active: true }));
      });
      listEl.querySelectorAll('.so-li-btn').forEach(b => {
        b.addEventListener('click', () => openLinkedInBridge(profiles[parseInt(b.dataset.pidx)]));
      });

      resultsEl.style.display = 'block';
      addLog('SO SEDE: tag=' + tag + ' loc=' + location + ' found=' + profiles.length);

    } catch(err) {
      if (statusEl) { statusEl.textContent = '❌ Error: ' + err.message; statusEl.style.color='#f87171'; }
      console.error('[PingIN] SO search:', err);
    }
    searchBtn.disabled = false;
    searchBtn.textContent = '🔍 Search Stack Overflow Experts';
  });

  // ── LinkedIn Bridge — direct link or popup with X-Ray strategies ─────────────
  function openLinkedInBridge(p) {
    if (p.hasLinkedIn && p.linkedInUrl) { chrome.tabs.create({ url: p.linkedInUrl, active: true }); return; }

    const modal  = document.getElementById('so-linkedin-modal');
    const nameEl = document.getElementById('modal-name');
    const metaEl = document.getElementById('modal-meta');
    const srch   = document.getElementById('modal-searches');
    const soBtn  = document.getElementById('modal-so-profile');
    if (!modal || !nameEl) return;

    nameEl.textContent = '🔍 Finding LinkedIn for ' + p.name;
    const sigs = [];
    if (p.goldBadges > 0) sigs.push('🥇 ' + p.goldBadges + ' gold badge');
    if (p.location)       sigs.push('📍 ' + p.location);
    if (p.hasGitHub)      sigs.push('💻 Has GitHub');
    metaEl.textContent = sigs.join('  ·  ');

    const name = (p.name || '').replace(/['"]/g, '');
    const city = ((p.location || '').split(',')[0] || '').trim();
    const tag  = (document.getElementById('so-tag')?.value || '').trim();

    const strategies = [
      ...(p.hasGitHub && p.gitHubUrl ? [{
        label: '✅ They have GitHub — check bio for LinkedIn',
        query: p.gitHubUrl,
        note: 'Many devs link LinkedIn in their GitHub bio',
        direct: p.gitHubUrl,
        btnLabel: '🌐 Open GitHub'
      }] : []),
      ...(city ? [{
        label: '① Name + City (most accurate)',
        query: `site:linkedin.com/in "${name}" "${city}"`,
        note: 'Best match — filters by city'
      }] : []),
      {
        label: '② Name + Skill (broader)',
        query: `site:linkedin.com/in "${name}" "${tag}"`,
        note: "Good if they didn't list city on LinkedIn"
      },
      ...(p.goldBadges > 0 ? [{
        label: '③ Name + Stack Overflow signal',
        query: `site:linkedin.com/in "${name}" "Stack Overflow" -"student"`,
        note: 'Gold badge holders often mention SO on LinkedIn'
      }] : [{
        label: '③ Name + Skill (exclude students)',
        query: `site:linkedin.com/in "${name}" "${tag}" -"student"`,
        note: 'Removes student profiles'
      }]),
      {
        label: '④ Name only (last resort)',
        query: `site:linkedin.com/in "${name}"`,
        note: 'May show multiple people with same name'
      }
    ];

    srch.innerHTML = '';
    strategies.forEach(s => {
      const googleUrl = s.direct ? s.direct : 'https://www.google.com/search?q=' + encodeURIComponent(s.query);
      const div = document.createElement('div');
      div.style.cssText = 'background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:9px 11px;';
      div.innerHTML = `
        <div style="font-size:11px;font-weight:600;color:var(--tp);margin-bottom:2px;">${s.label}</div>
        <div style="font-size:10px;color:#38bdf8;font-family:monospace;word-break:break-all;margin-bottom:5px;">${s.query}</div>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;">
          <span style="font-size:10px;color:var(--tm);">${s.note}</span>
          <button data-url="${googleUrl}" data-action="modal-search" style="background:linear-gradient(135deg,#0055cc,#38bdf8);border:none;border-radius:6px;color:#fff;font-size:10px;font-weight:600;padding:5px 10px;cursor:pointer;white-space:nowrap;font-family:inherit;">${s.btnLabel || '🔍 Search Google'}</button>
        </div>`;
      srch.appendChild(div);
    });

    // Bind modal search buttons (CSP: no inline onclick allowed)
    srch.querySelectorAll('[data-action="modal-search"]').forEach(b => {
      b.addEventListener('click', () => chrome.tabs.create({ url: b.dataset.url, active: true }));
    });
    if (soBtn) soBtn.onclick = () => chrome.tabs.create({ url: p.profileUrl, active: true });
    modal.style.display = 'block';
  }

  document.getElementById('so-modal-close')?.addEventListener('click',  () => { document.getElementById('so-linkedin-modal').style.display='none'; });
  document.getElementById('so-modal-close2')?.addEventListener('click', () => { document.getElementById('so-linkedin-modal').style.display='none'; });
  // ══════════════════════════════════════════════
  //  FEATURE 3 — GitHub Profile → LinkedIn Extractor
  //  Reads the active GitHub profile tab and finds LinkedIn URL
  // ══════════════════════════════════════════════
  document.getElementById('btn-extract-linkedin')?.addEventListener('click', async () => {
    const resultEl = document.getElementById('gh-extract-result');

    function showResult(msg, ok) {
      if (!resultEl) return;
      resultEl.style.display = 'block';
      resultEl.style.background = ok ? 'rgba(0,212,170,.1)'  : 'rgba(217,119,6,.1)';
      resultEl.style.border     = ok ? '1px solid rgba(0,212,170,.25)' : '1px solid rgba(217,119,6,.25)';
      resultEl.style.color      = ok ? 'var(--accent)' : 'var(--amber)';
      resultEl.textContent      = msg;
    }

    // Find the active GitHub profile tab
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const currentTab = tabs[0];

    // Check if current tab is a GitHub user profile
    const isGitHub = currentTab?.url?.match(/^https:\/\/github\.com\/([^/?#]+)\/?$/);

    let targetTab = null;

    if (isGitHub) {
      targetTab = currentTab;
    } else {
      // Look for any open GitHub profile tab
      const allTabs = await chrome.tabs.query({});
      targetTab = allTabs.find(t => t.url?.match(/^https:\/\/github\.com\/([^/?#]+)\/?$/));
    }

    if (!targetTab) {
      showResult("No GitHub profile tab found. Open a developer's GitHub profile page first, then click this button.", false);
      return;
    }

    showResult('Reading profile...', false);

    try {
      // Inject script to extract LinkedIn URL from GitHub profile page
      const results = await chrome.scripting.executeScript({
        target: { tabId: targetTab.id },
        func: () => {
          // GitHub shows social links in the profile sidebar
          // Look for linkedin.com links anywhere on the profile
          const allLinks = Array.from(document.querySelectorAll('a[href]'));
          const liLink = allLinks.find(a =>
            a.href && a.href.toLowerCase().includes('linkedin.com/in/')
          );
          if (liLink) return { found: true, url: liLink.href, type: 'direct' };

          // Check bio text for linkedin.com mention
          const bio = document.querySelector('.p-note, [data-bio-text], .user-profile-bio')?.textContent || '';
          const liMatch = bio.match(/linkedin\.com\/in\/[\w-]+/i);
          if (liMatch) return { found: true, url: 'https://www.' + liMatch[0], type: 'bio' };

          // Get developer name for fallback search
          const name = document.querySelector('[itemprop="name"], .p-name, h1.break-word')?.textContent?.trim() || '';
          const username = document.querySelector('[itemprop="additionalName"], .p-nickname')?.textContent?.trim() || '';
          const location = document.querySelector('[itemprop="homeLocation"], .p-label')?.textContent?.trim() || '';

          return { found: false, name, username, location };
        }
      });

      const data = results?.[0]?.result;

      if (!data) {
        showResult('Could not read GitHub profile. Make sure you are on a public GitHub profile page.', false);
        return;
      }

      if (data.found) {
        // Direct LinkedIn URL found — open it immediately
        await chrome.tabs.create({ url: data.url, active: true });
        showResult('✓ LinkedIn profile found and opened! ' + (data.type === 'bio' ? '(from bio text)' : '(from profile links)'), true);
        addLog('GitHub→LinkedIn extracted: ' + data.url);
      } else {
        // No LinkedIn link found — fall back to LinkedIn name search
        const name = data.name || data.username || '';
        const loc  = data.location || '';

        if (!name) {
          showResult('No LinkedIn link found in this GitHub profile, and could not read developer name. Try a different profile.', false);
          return;
        }

        // Open LinkedIn people search with their name
        const liSearchUrl = 'https://www.linkedin.com/search/results/people/?keywords=' +
          encodeURIComponent(name + (loc ? ' ' + loc : '')) +
          '&origin=GLOBAL_SEARCH_HEADER';

        await chrome.tabs.create({ url: liSearchUrl, active: true });
        showResult('No direct LinkedIn link in profile. Opened LinkedIn search for "' + name + '" — find them manually.', false);
        addLog('GitHub→LinkedIn fallback search: ' + name);
      }

    } catch(e) {
      showResult('Error reading GitHub page: ' + e.message + '. Make sure you are on a GitHub profile tab.', false);
    }
  });

  function showPlatStatus(msg, type) {
    const el = document.getElementById('platform-status');
    if (!el) return;
    el.style.display = 'block';
    el.className = 'info-box ' + type + ' show';
    el.textContent = msg;
  }
}


// ═══════════════════════════════════════════════════════════════
//  PREDICTIVE SOURCING — Find candidates before they're active
// ═══════════════════════════════════════════════════════════════
async function initPredictiveSearch() {
  const searchBtn = document.getElementById('btn-predictive-search');
  const status    = document.getElementById('pred-status');

  searchBtn?.addEventListener('click', async () => {
    const role = document.getElementById('pred-role')?.value?.trim();
    if (!role) {
      if(status){status.className='info-box warning show';status.textContent='Please enter a role to search for.';}
      return;
    }

    const signals = Array.from(document.querySelectorAll('.signal-chk:checked')).map(c=>c.value);
    if (!signals.length) {
      if(status){status.className='info-box warning show';status.textContent='Select at least one signal.';}
      return;
    }

    searchBtn.disabled = true;
    searchBtn.innerHTML = '<span class="spinning">⟳</span> Building predictive search...';
    if(status){status.className='info-box info show';status.textContent='🎯 AI building predictive search query...';}

    try {
      // Build signal-based LinkedIn search query
      const query = await buildPredictiveQuery(role, signals);

      // Clear old profiles
      S.profiles = []; S.sent = 0; S.failed = 0;
      await chrome.storage.local.set({ profiles:[], sent:0, failed:0 });

      // Set up scraping
      const searchUrl = 'https://www.linkedin.com/search/results/people/?keywords='+encodeURIComponent(query)+'&origin=GLOBAL_SEARCH_HEADER';
      await chrome.storage.local.set({
        pendingScrape: {
          url: searchUrl,
          params: { keywords:query, location:'', degree:'123', experience:'', profileType:'', college:'', degreeType:'', company:'', salaryRange:'', diversityFilters:[] },
          page:1, isNewSearch:true, requestedAt: Date.now()
        }
      });
      S.lastSearchParams = { keywords:query };

      const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tabs[0]) await chrome.tabs.update(tabs[0].id, {url:searchUrl});

      addLog('Predictive search: "'+role+'" with signals: '+signals.join(', '));
      if(status){status.className='info-box success show';status.textContent='✓ Searching for predictive candidates! Results will appear in Profiles tab.';}

      setTimeout(() => showScreen('screen-profiles','slide-up'), 800);

    } catch(e) {
      if(status){status.className='info-box warning show';status.textContent='Error: '+e.message;}
    } finally {
      searchBtn.disabled = false;
      searchBtn.textContent = '🎯 Find Predictive Candidates';
    }
  });
}

async function buildPredictiveQuery(role, signals) {
  // Map signals to LinkedIn search keywords
  const SIGNAL_KEYWORDS = {
    recently_promoted:  '"promoted" OR "new role" OR "excited to share"',
    new_certification:  '"AWS certified" OR "completed certification" OR "passed exam" OR "certified in"',
    company_at_risk:    '"Byjus" OR "Paytm" OR "PhonePe" OR "Ola" OR "Unacademy"',
    tenure_2yr:         '',  // handled via experience filter
    profile_updated:    '',  // use OTW as proxy
    startup_employee:   '"Series A" OR "Series B" OR "seed stage" OR "early stage startup"',
  };

  // Build signal part
  const signalParts = signals
    .map(s => SIGNAL_KEYWORDS[s])
    .filter(Boolean);

  // Use Claude AI to build the best predictive query
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        model:'claude-sonnet-4-20250514',
        max_tokens:200,
        messages:[{
          role:'user',
          content:`Build a LinkedIn search query to find passive candidates for this role: "${role}"

Selected predictive signals: ${signals.join(', ')}

The query should find people who are LIKELY to switch jobs soon based on these signals.
Return ONLY the search query string (max 100 chars), nothing else.
Example: "Senior Data Scientist" "AWS certified" Bangalore`
        }]
      })
    });
    if (response.ok) {
      const data = await response.json();
      const q = data.content?.[0]?.text?.trim() || '';
      if (q && q.length > 5) return q;
    }
  } catch(e) {}

  // Fallback: combine role + top signals
  const rolePart = role.includes('"') ? role : '"'+role+'"';
  const sigPart = signalParts[0] || '';
  return sigPart ? rolePart + ' ' + sigPart : rolePart;
}



// ═══════════════════════════════════════════════════════════════
//  SALARY INTELLIGENCE MODULE
//  Merged from SalaryIntel v3 — bugs fixed
// ═══════════════════════════════════════════════════════════════
const SI_TIERS = {
  faang:   ['google','microsoft','amazon','meta','apple','nvidia','adobe','salesforce','oracle','intel','qualcomm','cisco','goldman sachs','jpmorgan','morgan stanley','american express','mckinsey','bcg','bain','walmart global tech','samsung research'],
  unicorn: ['razorpay','cred','zerodha','groww','phonepe','meesho','nykaa','swiggy','zomato','ola','byju','freshworks','zoho','browserstack','postman','chargebee','darwinbox','lenskart','cars24','policybazaar','paytm','delhivery','shiprocket','dream11','miro','juspay','setu','slice','jupiter'],
  mnc:     ['ibm','sap','vmware','servicenow','workday','zendesk','atlassian','mongodb','datadog','snowflake','stripe','paypal','visa','mastercard','hsbc','barclays','ubs','ey','pwc','kpmg','deloitte','accenture','capgemini','thoughtworks','publicis'],
  startup: ['flipkart','myntra','bigbasket','blinkit','zepto','practo','cure.fit','1mg','healthifyme','cashfree','instamojo','payu','pine labs','khatabook','okcredit','finbox','smallcase','indmoney'],
  service: ['tcs','infosys','wipro','hcl','tech mahindra','ltimindtree','mphasis','hexaware','persistent','cyient','coforge','birlasoft','kpit','cognizant','genpact','wns','exlservice','niit','mastech'],
};

const SI_SALARY = {
  faang:   {intern:[8,15],  fresher:[15,25], junior:[22,38], mid:[38,68],  senior:[62,100], lead:[88,150],  principal:[135,220], director:[195,350]},
  unicorn: {intern:[5,10],  fresher:[10,18], junior:[16,28], mid:[26,48],  senior:[42,72],  lead:[66,108],  principal:[96,158],  director:[145,248]},
  mnc:     {intern:[4,8],   fresher:[7,13],  junior:[12,22], mid:[20,38],  senior:[34,58],  lead:[52,88],   principal:[76,128],  director:[116,198]},
  startup: {intern:[3,7],   fresher:[6,12],  junior:[9,18],  mid:[16,30],  senior:[26,48],  lead:[42,72],   principal:[62,102],  director:[92,158]},
  service: {intern:[2,4],   fresher:[3,6],   junior:[5,10],  mid:[8,17],   senior:[14,27],  lead:[22,40],   principal:[34,58],   director:[52,88]},
  other:   {intern:[1,3],   fresher:[2,5],   junior:[3,7],   mid:[6,13],   senior:[10,20],  lead:[16,32],   principal:[26,48],   director:[40,72]},
};

const SI_CITY = {
  'bengaluru':1.00,'bangalore':1.00,'mumbai':0.95,'hyderabad':0.88,
  'pune':0.87,'delhi':0.92,'ncr':0.92,'gurgaon':0.90,'gurugram':0.90,
  'noida':0.88,'chennai':0.85,'kolkata':0.78,'ahmedabad':0.76,
};

const SI_TIER_L = {
  faang:'FAANG / Top GCC', unicorn:'Unicorn / Product', mnc:'MNC India Office',
  startup:'Indian Startup', service:'IT Services', other:'SME / Other',
};
const SI_SEN_L = {
  intern:'Intern / Trainee', fresher:'Fresher (0–1 yr)', junior:'Junior (1–3 yr)',
  mid:'Mid Level (3–6 yr)', senior:'Senior (6–9 yr)', lead:'Lead / Manager',
  principal:'Principal / Architect', director:'Director / VP',
};

function siGetTier(company) {
  const c = (company || '').toLowerCase();
  for (const [tier, list] of Object.entries(SI_TIERS)) {
    if (list.some(name => c.includes(name))) return tier;
  }
  return 'other';
}

// FIX: expanded getSen to handle SDE-2, L4, Staff, etc.
function siGetSen(title, expOverride) {
  if (expOverride) return expOverride;
  const t = (title || '').toLowerCase();
  if (/intern|trainee/.test(t))                                           return 'intern';
  if (/fresher|entry.?level|graduate|0.?year/.test(t))                   return 'fresher';
  if (/sde.?1|l3|level.?3|junior|\bjr\.?\b|associate(?!.*(senior|lead))/.test(t)) return 'junior';
  if (/principal|architect|distinguished|fellow|sde.?5|l7|l8/.test(t))   return 'principal';
  if (/director|\bvp\b|vice.?pres|head of|\bchief\b|cto|cpo|cfo|ceo/.test(t)) return 'director';
  if (/lead|manager|\bmgr\b|tech lead|team lead/.test(t))              return 'lead';
  if (/senior|\bsr\.?\b|staff|sde.?3|sde.?4|l5|l6|level.?5|level.?6/.test(t)) return 'senior';
  if (/sde.?2|l4|level.?4|mid/.test(t))                                  return 'mid';
  return 'mid';
}

function siGetCityMult(city) {
  const c = (city || '').toLowerCase();
  for (const [key, mult] of Object.entries(SI_CITY)) {
    if (c.includes(key)) return mult;
  }
  return 0.85;
}

function siFmt(n) { return n >= 100 ? (n/100).toFixed(1)+' Cr' : n+'L'; }

function siCalc(title, company, city, expOverride) {
  const tier = siGetTier(company);
  const sen  = siGetSen(title, expOverride);
  const mult = siGetCityMult(city);
  const row  = (SI_SALARY[tier] || SI_SALARY.other)[sen] || SI_SALARY.other.mid;
  return {
    min: Math.round(row[0] * mult),
    max: Math.round(row[1] * mult),
    tier, sen,
    tierLabel: SI_TIER_L[tier],
    senLabel:  SI_SEN_L[sen],
  };
}

// ── Salary Intel screen init ──────────────────────────────────
function initSalaryIntel() {
  // Check if on LinkedIn and update status badge
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
    const url  = tabs?.[0]?.url || '';
    const stat = document.getElementById('si-li-status');
    if (!stat) return;
    if (url.includes('linkedin.com')) {
      stat.className = 'screen-subtitle active';
      stat.textContent = '● Active on LinkedIn';
    } else {
      stat.className = 'screen-subtitle inactive';
      stat.textContent = '○ Open LinkedIn first';
    }
  });

  document.getElementById('btn-si-calc')?.addEventListener('click', () => {
    const title   = document.getElementById('si-title')?.value?.trim() || '';
    const company = document.getElementById('si-company')?.value?.trim() || '';
    const city    = document.getElementById('si-city')?.value || 'bengaluru';
    const exp     = document.getElementById('si-exp')?.value || '';

    if (!title && !company) {
      const card = document.getElementById('si-result-card');
      if (card) {
        card.style.display = 'block';
        card.style.borderColor = 'rgba(217,119,6,.3)';
        card.style.background = 'rgba(217,119,6,.06)';
        document.getElementById('si-res-range').textContent = '⚠️ Enter a title or company';
        document.getElementById('si-res-rows').innerHTML = '';
      }
      return;
    }

    const r = siCalc(title, company, city, exp || null);

    const cityEl  = document.getElementById('si-city');
    const cityLbl = cityEl?.options[cityEl?.selectedIndex]?.text || city;

    const card = document.getElementById('si-result-card');
    if (card) {
      card.style.display = 'block';
      card.style.borderColor = 'rgba(91,181,255,.25)';
      card.style.background = '#0D1117';
    }

    const rangeEl = document.getElementById('si-res-range');
    if (rangeEl) rangeEl.textContent = '₹' + siFmt(r.min) + ' – ₹' + siFmt(r.max) + ' PA';

    const rowsEl = document.getElementById('si-res-rows');
    if (rowsEl) {
      const rows = [
        ['Company Tier',  r.tierLabel],
        ['Seniority',     r.senLabel],
        ['City',          cityLbl + ' (' + Math.round(siGetCityMult(city)*100) + '% of BLR)'],
        ['Data Sources',  'Glassdoor · AmbitionBox · Levels.fyi'],
      ];
      rowsEl.innerHTML = rows.map(([l,v]) =>
        `<div class="si-res-row"><span>${l}</span><span>${v}</span></div>`
      ).join('');
    }
  });

  // Enter key triggers calc
  ['si-title','si-company'].forEach(id => {
    document.getElementById(id)?.addEventListener('keydown', e => {
      if (e.key === 'Enter') document.getElementById('btn-si-calc')?.click();
    });
  });
}

// ═══════════════════════════════════════════════════════════════
//  BOOT
// ═══════════════════════════════════════════════════════════════

// ── Manual profile collection — user triggers after LinkedIn loads ────────────
async function collectProfilesNow() {
  // Lock for Free and Starter — Pro/Annual only
  if (!['pro','annual'].includes(S.plan)) {
    showStatus('🔒 Profile collection is a Pro feature. Upgrade at pingin.in/pricing', 'warning');
    setTimeout(() => { window.open('https://pingin.in/pricing.html','_blank'); }, 1500);
    return;
  }
  const btn = document.getElementById('btn-collect');
  const btn2 = document.getElementById('btn-co-collect');
  const activeBtn = btn?.style.display !== 'none' ? btn : btn2;
  if (activeBtn) { activeBtn.disabled = true; activeBtn.textContent = '⏳ Collecting...'; }
  showStatus('Looking for LinkedIn profiles...', 'info');

  // Check Pro plan before collecting
  if (!['pro','annual'].includes(S.plan || 'free')) {
    showStatus('🔒 Collecting profiles requires Pro plan. Upgrade at pingin.in/pricing.html', 'warning');
    if (activeBtn) { activeBtn.disabled = false; activeBtn.textContent = '🔒 Get Profiles (Pro Plan)'; }
    return;
  }

  try {
    // Find the LinkedIn search tab — prefer the ACTIVE tab in the focused
    // window first, since that's almost certainly the tab the user is
    // looking at right now (fixes stale-tab bugs when multiple LinkedIn
    // tabs are open, e.g. an old page-1 tab plus a newer page-2 tab).
    const tabs = await chrome.tabs.query({});
    const activeTabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    const activeLiTab = activeTabs.find(t => t.url && t.url.includes('linkedin.com'));
    const liTab = activeLiTab
      || tabs.find(t => t.url && t.url.includes('linkedin.com') && (
           t.url.includes('/search/results/') ||
           t.url.includes('/company/') ||
           t.url.includes('linkedin.com/in/')
         ))
      || tabs.find(t => t.url && t.url.includes('linkedin.com'));
    if (!liTab) {
      showStatus('LinkedIn is not open. Click "Step 1 — Search LinkedIn" first, wait 5-10 seconds for results to load, then click this button.', 'warning');
      if (activeBtn) { activeBtn.disabled = false; activeBtn.textContent = '📥 Get Profiles from Page'; }
      return;
    }

    // Send message to content script (more reliable than executeScript)
    let scraped = [];
    try {
      const resp = await chrome.tabs.sendMessage(liTab.id, { action: 'SCRAPE_PAGE' });
      if (resp?.ok && resp.profiles?.length > 0) {
        scraped = resp.profiles;
        console.log('[PingIN] Content script returned ' + scraped.length + ' profiles');
      }
    } catch(e) {
      console.log('[PingIN] Content script failed, trying executeScript: ' + e.message);
    }

    // Fallback: inject scraper directly
    if (scraped.length === 0) {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: liTab.id },
          func: scrapeFromPopup,
        });
        scraped = results?.[0]?.result || [];
        console.log('[PingIN] executeScript returned ' + scraped.length + ' profiles');
      } catch(e) {
        console.log('[PingIN] executeScript also failed: ' + e.message);
      }
    }

    if (scraped.length === 0) {
      showStatus('⏳ LinkedIn may still be loading. Wait 5-10 seconds after results appear, then click "Get Profiles from Page" again.', 'warning');
      if (activeBtn) { activeBtn.disabled = false; activeBtn.textContent = '📥 Get Profiles from Page'; }
      return;
    }

    // Apply location filter — soft mode: only reject explicit mismatches
    // If LinkedIn doesn't show city in card → KEEP (can't determine)
    // Only reject if city IS shown AND doesn't match
    const wantLoc = (S.lastSearchParams?.location || '').trim();
    const filtered = wantLoc
      ? scraped.filter(p => {
          if (!p.city || p.city.trim() === '') return true;  // no city shown → keep
          return matchesCityLocal(p.city, wantLoc);          // city shown → check match
        })
      : scraped;

    const locationRejected = scraped.length - filtered.length;

    // ── Strict title-match filter ────────────────────────────────────────────
    // LinkedIn's own People Search loosens quoted-phrase keywords when results
    // are thin — it silently falls back to matching individual words, so a
    // search for "Product Manager" can surface "Talent Acquisition Manager"
    // or "Operations Manager" (anything containing just "Manager"). Since we
    // can't control LinkedIn's matching, we re-verify locally: every
    // significant word from the search phrase must appear in the scraped
    // role/headline before we keep the profile.
    const coreWords = extractCoreKeywordWords(S.lastSearchParams?.keywords || '');
    const titleFiltered = coreWords
      ? filtered.filter(p => matchesRoleStrict(p, coreWords))
      : filtered;
    const titleRejected = filtered.length - titleFiltered.length;

    // Save to storage (avoid duplicates)
    const stored = await chrome.storage.local.get('profiles');
    const existing = new Set((stored.profiles || []).map(p => p.profileUrl));
    const fresh = titleFiltered.filter(p => p.profileUrl && !existing.has(p.profileUrl));
    const allProfiles = [...(stored.profiles || []), ...fresh];
    await chrome.storage.local.set({ profiles: allProfiles });
    S.profiles = allProfiles;


    // Clean names (apply cleanScrapedName in popup context after scraping)
    allProfiles = allProfiles.map(p => ({ ...p, name: cleanScrapedName(p.name) }));

    // Run AI scoring in background
    const aiScored = await scoreProfilesWithAI(allProfiles, S.lastSearchParams);
    if (aiScored) {
      S.profiles = aiScored;
      await chrome.storage.local.set({ profiles: aiScored });
    }

    updateAllCounts();
    renderProfiles();

    const locMsg   = locationRejected > 0 ? ` · ${locationRejected} different city` : '';
    const titleMsg = titleRejected    > 0 ? ` · ${titleRejected} unrelated title removed` : '';
    const pageMsg  = (() => {
      const m = (liTab.url || '').match(/[?&]page=(\d+)/);
      return m ? ` (page ${m[1]})` : '';
    })();
    if (fresh.length > 0) {
      showStatus(`✅ Added ${fresh.length} new profiles${pageMsg}!${locMsg}${titleMsg} → click View Profiles`, 'success');
      // Show the view profiles button
      const smartAfter = document.getElementById('smart-after-search');
      if (smartAfter) smartAfter.style.display = 'block';
      const inlineCount = document.getElementById('smart-inline-count');
      if (inlineCount) inlineCount.textContent = allProfiles.length;
    } else if (titleFiltered.length > 0) {
      showStatus(`No new profiles${pageMsg} — ${titleFiltered.length} already collected.${locMsg}${titleMsg}`, 'info');
    } else if (titleRejected > 0) {
      showStatus(`0 matching profiles${pageMsg} — all ${titleRejected} results had unrelated titles (e.g. "Manager" without "Product"). Try a broader phrase.`, 'warning');
    } else {
      showStatus(`0 profiles for this location.${locMsg} Try without location filter, or wait for page to load fully.`, 'warning');
    }
  } catch(e) {
    console.error('[PingIN] Collect error:', e);
    showStatus('Collection failed: ' + (e?.message || e), 'error');
  }
  if (activeBtn) { activeBtn.disabled = false; activeBtn.textContent = '📥 Get Profiles from Page'; }
}


// ── Strict title-match helpers ────────────────────────────────────────────────
// LinkedIn's free People Search loosens quoted-phrase keyword matching when
// results are thin, surfacing profiles that only match ONE word of a
// multi-word title (e.g. "Product Manager" search returning "Talent
// Acquisition Manager"). These two functions re-verify locally using the
// scraped headline text, which we fully control.
function extractCoreKeywordWords(rawKeywords) {
  if (!rawKeywords) return null;
  // Compound boolean queries (AND/OR/NOT, parentheses) are intentional —
  // don't second-guess them with a strict word filter.
  if (/\b(AND|OR|NOT)\b|[()]/i.test(rawKeywords)) return null;
  const words = rawKeywords.replace(/"/g, '').trim().split(/\s+/)
    .map(w => w.trim()).filter(w => w.length >= 3);
  return words.length > 0 ? words : null;
}

function matchesRoleStrict(profile, words) {
  if (!words || words.length === 0) return true;
  // The scraper's 2-line heuristic sometimes puts the real current title
  // (e.g. "Associate Technical Product Manager at Optum") into the
  // `company` field when the headline line is a separate summary like
  // "AI Product Management". Check both fields combined so a real match
  // isn't missed just because of which line LinkedIn rendered first.
  const combined = `${profile.role || ''} ${profile.company || ''}`.trim();
  if (!combined) return true; // can't verify — soft-allow
  const lower = combined.toLowerCase();
  return words.every(w => lower.includes(w.toLowerCase()));
}

function matchesCityLocal(profileCity, wantedLoc) {
  if (!wantedLoc) return true;
  if (!profileCity) return false;
  const city = profileCity.toLowerCase();
  const want = wantedLoc.toLowerCase();
  // LinkedIn often shows metro area names instead of exact city
  // e.g. Noida users show "Delhi NCR" · Gurgaon users show "Delhi NCR"
  // e.g. Bengaluru users show "Bengaluru Metropolitan Area"
  const ALIASES = {
    'bengaluru': ['bengaluru','bangalore','bengaluru metropolitan'],
    'hyderabad': ['hyderabad','secunderabad','cyberabad','hyderabad metropolitan'],
    'mumbai':    ['mumbai','bombay','mumbai metropolitan','greater mumbai'],
    'navi mumbai':['navi mumbai','navimumbai'],
    'thane':     ['thane','thane district'],
    'delhi':     ['delhi','new delhi','delhi ncr','ncr','national capital'],
    'new delhi': ['new delhi','delhi','delhi ncr'],
    'noida':     ['noida','greater noida','delhi ncr','ncr','national capital region'],
    'gurgaon':   ['gurgaon','gurugram','delhi ncr','ncr','national capital region'],
    'faridabad': ['faridabad','delhi ncr','ncr'],
    'ghaziabad': ['ghaziabad','delhi ncr','ncr'],
    'chennai':   ['chennai','madras','chennai metropolitan'],
    'pune':      ['pune','pimpri','pune metropolitan','pune district'],
    'kolkata':   ['kolkata','calcutta','kolkata metropolitan'],
    'ahmedabad': ['ahmedabad','ahmedabad metropolitan'],
    'jaipur':    ['jaipur','jaipur metropolitan'],
    'kochi':     ['kochi','cochin','ernakulam'],
    'coimbatore':['coimbatore','coimbatore metropolitan'],
    'chandigarh':['chandigarh','tricity','tri-city'],
    'lucknow':   ['lucknow','lucknow metropolitan'],
    'indore':    ['indore','indore metropolitan'],
    'nagpur':    ['nagpur','nagpur metropolitan'],
  };
  if (city.includes(want)) return true;
  const aliases = ALIASES[want] || [want];
  return aliases.some(a => city.includes(a));
}

// This function runs IN the LinkedIn tab context via executeScript
function scrapeFromPopup() {
  // IMPORTANT: this function runs inside LinkedIn's tab via executeScript.
  // It must be completely self-contained — no calls to popup.js functions.
  var profiles  = [];
  var seenUrl   = {};
  var allLinks  = document.querySelectorAll('a[href*="/in/"]');

  // ── Group all /in/ links by their enclosing result card ──────────────────────
  // A LinkedIn search result card contains MULTIPLE /in/ links:
  //   1. The main candidate's title link (the actual search result)
  //   2. Small avatar links inside "X, Y and N other mutual connections" facepile
  // Without grouping, mutual-connection avatars get scraped as fake duplicate
  // "candidates" whose role/company end up being the mutual-connections sentence.
  var cardGroups = []; // [{ card, links: [...] }]
  var cardIndex  = new Map();

  allLinks.forEach(function(link) {
    var url = (link.href || '').split('?')[0];
    if (url.indexOf('linkedin.com/in/') < 0) return;
    var card = link.closest('li') || link.closest('[class*="result"]') || link.parentElement;
    if (!card) return;
    if (!cardIndex.has(card)) {
      var group = { card: card, links: [] };
      cardIndex.set(card, group);
      cardGroups.push(group);
    }
    cardIndex.get(card).links.push(link);
  });

  cardGroups.forEach(function(group) {
    try {
      var card     = group.card;
      var cardText = card.innerText || card.textContent || '';

      // Pick the PRIMARY link for this card: the one whose extracted name
      // appears EARLIEST in the card text (the heading name always comes
      // first; mutual-connection names appear later, inside the facepile line).
      var best = null, bestPos = Infinity;
      group.links.forEach(function(link) {
        var url = (link.href || '').split('?')[0];
        var slug = url.split('/in/')[1];
        if (!slug || slug.length < 2) return;
        var nameEl  = link.querySelector('span[aria-hidden="true"]');
        var rawName = nameEl ? (nameEl.innerText || nameEl.textContent || '') : (link.innerText || link.textContent || '');
        var name    = rawName.split('\n')[0].trim();
        if (!name || name.length < 2 || name === 'LinkedIn Member') return;
        var pos = cardText.indexOf(name);
        if (pos === -1) pos = Infinity;
        if (pos < bestPos) { bestPos = pos; best = { link: link, url: url, name: name }; }
      });
      if (!best) return;

      if (seenUrl[best.url]) return;
      seenUrl[best.url] = true;

      var name = best.name;
      var link = best.link;
      var url  = best.url;

      var lines = cardText.split('\n').map(function(l){return l.trim();}).filter(function(l){return l.length > 1;});

      var role = '', city = '', degree = '', company = '';
      var degMatch = (link.innerText || link.textContent || '').match(/[\u00b7\u2022]\s*([123](st|nd|rd)\+?)/i);
      if (degMatch) degree = degMatch[1];

      lines.forEach(function(line) {
        var lineLow = line.toLowerCase();
        if (lineLow === name.toLowerCase()) return;
        // Never let mutual-connections text leak into role/company fields
        if (lineLow.indexOf('mutual connection') > -1 || lineLow.indexOf('other mutual') > -1) return;
        if (lineLow.indexOf('open to work') > -1 || lineLow.indexOf('opentowork') > -1) return;
        if (/^[123](st|nd|rd)\+?$/.test(line.trim())) { if (!degree) degree = line.trim(); return; }
        if (lineLow.indexOf('india') > -1 || lineLow.indexOf(' area') > -1 || lineLow.indexOf(', ma') > -1 || lineLow.indexOf(' division') > -1) { if (!city) city = line; return; }
        if (!role && line.length > 5 && line.length < 120) role = line;
        else if (role && !company && line.length > 2 && line.length < 80) company = line;
      });

      var isOTW = cardText.toLowerCase().indexOf('open to work') > -1 || cardText.indexOf('#OpenToWork') > -1;
      var photo = '';
      var img = card.querySelector('img[src*="licdn"]') || card.querySelector('img[src*="media"]');
      if (img) photo = img.src;

      profiles.push({
        name: name, profileUrl: url,
        role: role, company: company, city: city,
        degree: degree, isOTW: isOTW, photo: photo,
        status: 'pending', scrapedAt: new Date().toISOString()
      });
    } catch(e) {}
  });

  return profiles.filter(function(p){ return p.name && p.profileUrl; });
}


// ── Company People Search ──────────────────────────────────────────────────────
function extractCompanySlug(input) {
  // Handle: full URL, partial URL, or just slug
  const trimmed = (input || '').trim();
  // linkedin.com/company/microsoft/people → microsoft
  // linkedin.com/company/tata-consultancy-services → tata-consultancy-services
  const urlMatch = trimmed.match(/linkedin\.com\/company\/([^/\?]+)/i);
  if (urlMatch) return urlMatch[1].toLowerCase();
  // Just a slug like "microsoft" or "tata-consultancy-services"
  // Remove any leading https:// www. etc
  const cleaned = trimmed.replace(/^https?:\/\//i,'').replace(/^www\./i,'');
  if (!cleaned.includes('/')) return cleaned.toLowerCase().replace(/\s+/g,'-');
  return null;
}

document.getElementById('btn-co-search')?.addEventListener('click', async function() {
  const rawInput = (document.getElementById('co-url')?.value || '').trim();
  const keywords = (document.getElementById('co-keywords')?.value || '').trim();
  const location = (document.getElementById('co-location')?.value || '').trim();
  const statusEl = document.getElementById('co-status');

  if (!rawInput) {
    if (statusEl) { statusEl.style.display='block'; statusEl.className='info-box warning'; statusEl.textContent='Enter a company name or LinkedIn URL'; }
    document.getElementById('co-url')?.focus();
    return;
  }

  const slug = extractCompanySlug(rawInput);
  if (!slug) {
    if (statusEl) { statusEl.style.display='block'; statusEl.className='info-box warning'; statusEl.textContent='Could not read company slug. Try: microsoft OR linkedin.com/company/microsoft'; }
    return;
  }

  // Build URL: /company/slug/people/?keywords=skills location
  const kwParts = [keywords, location].filter(Boolean).join(' ');
  let url = `https://www.linkedin.com/company/${encodeURIComponent(slug)}/people/`;
  if (kwParts) url += `?keywords=${encodeURIComponent(kwParts)}`;

  if (statusEl) { statusEl.style.display='block'; statusEl.className='info-box info'; statusEl.textContent=`Opening ${slug} employee page...`; }

  // Store search params
  S.lastSearchParams = { keywords: kwParts, location, company: slug, source: 'company' };
  await chrome.storage.local.set({
    lastSearchParams: S.lastSearchParams,
    pendingScrape: { url, params: S.lastSearchParams, page: 1, isNewSearch: true, requestedAt: Date.now() }
  });

  // Reuse or open tab
  try {
    const tabs = await chrome.tabs.query({});
    const liTab = tabs.find(t => t.url && t.url.includes('linkedin.com'));
    if (liTab) {
      await chrome.tabs.update(liTab.id, { url, active: true });
    } else {
      await chrome.tabs.create({ url, active: true });
    }
  } catch(e) {
    await chrome.tabs.create({ url, active: true });
  }

  // Show collect button
  const collectBtn = document.getElementById('btn-co-collect');
  if (collectBtn) collectBtn.style.display = 'block';
  if (statusEl) { statusEl.textContent = `${slug} page opening... Wait for it to load, then click Collect Profiles.`; }
});

document.getElementById('btn-co-collect')?.addEventListener('click', async function() {
  const btn = this;
  btn.disabled = true; btn.textContent = '⏳ Collecting...';
  await collectProfilesNow();
  btn.disabled = false; btn.textContent = '📥 Get Profiles from Page';
  const cnt = document.getElementById('co-sb-count');
  if (cnt) cnt.textContent = S.profiles?.length || 0;
});

document.getElementById('co-view-btn')?.addEventListener('click', function() {
  document.querySelector('[data-screen="screen-profiles"]')?.click() ||
  (() => {
    if (!['pro','annual'].includes(S.plan)) {
      showUpgradePopup('View Profiles & AI Scoring is a Pro feature. Upgrade to view, score and manage collected profiles.');
      return;
    }
    navigateTo('screen-profiles');
    setTimeout(initJDScoring, 100);
  })();
});


function scoreAllProfiles(profiles, searchParams) {
  if (!profiles || profiles.length === 0) return [];
  return profiles.map(p => ({
    ...p,
    score: scoreProfile(p, searchParams || S.lastSearchParams || {})
  })).sort((a,b) => (b.score||0) - (a.score||0));
}


// ── AI Profile Ranker — calls PingIN Cloudflare Worker (no user API key needed) ─
const PINGIN_AI_WORKER = 'https://pingin-ai.hr-kiranm.workers.dev';

async function scoreProfilesWithAI(profiles, searchParams) {
  try {
    if (!profiles || profiles.length === 0) return null;

    const resp = await fetch(PINGIN_AI_WORKER, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'scoreProfiles',
        profiles: profiles.slice(0, 30),
        searchParams
      })
    });

    if (!resp.ok) {
      console.log('[PingIN] AI worker returned', resp.status, '— using local scoring');
      return null;
    }

    const data = await resp.json();
    if (!data.ok || !data.scores) return null;

    console.log('[PingIN] AI scored', data.scores.length, 'profiles');
    return data.scores;
  } catch(e) {
    console.log('[PingIN] AI scoring unavailable:', e.message, '— using local scoring');
    return null;
  }
}




// ── Clean scraped name: remove OTW badge, degree, duplication ─────────────────
function cleanScrapedName(raw) {
  if (!raw) return '';
  let name = raw
    .replace(/is open to work/gi, '')
    .replace(/open to work/gi, '')
    .replace(/#OpenToWork/gi, '')
    .replace(/[·•]\s*[123](st|nd|rd)\+?.*/i, '')
    .replace(/\s+[123](st|nd|rd)\+?\s*$/i, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
  // Detect and remove repeated name (e.g. "Sunny Varaiya Sunny Varaiya")
  const words = name.split(' ');
  for (let i = 1; i < words.length; i++) {
    const a = words.slice(0, i).join(' ');
    const b = words.slice(i).join(' ');
    if (b.toLowerCase().startsWith(a.toLowerCase()) || a.toLowerCase() === b.toLowerCase()) {
      name = a; break;
    }
  }
  return name.trim();
}



// ── JD-based AI profile scoring ────────────────────────────────────────────────
async function scoreProfilesWithJD(profiles, jdText) {
  try {
    if (!profiles || profiles.length === 0 || !jdText || jdText.trim().length < 30) return null;
    const resp = await fetch(PINGIN_AI_WORKER, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'scoreProfilesVsJD', profiles: profiles.slice(0, 30), jdText })
    });
    if (!resp.ok) { console.log('[PingIN] JD scoring failed:', resp.status); return null; }
    const data = await resp.json();
    if (!data.ok || !data.scores) return null;
    console.log('[PingIN] JD scored', data.scores.length, 'profiles');
    return data.scores;
  } catch(e) {
    console.log('[PingIN] JD scoring error:', e.message);
    return null;
  }
}


  // ── JD Scoring — score profiles against pasted JD ──────────────────────────
  function initJDScoring() {
    const section  = document.getElementById('jd-scoring-section');
    const textarea = document.getElementById('jd-scoring-text');
    const btnScore = document.getElementById('btn-score-vs-jd');
    const btnClear = document.getElementById('btn-clear-jd-score');
    const btnClose = document.getElementById('jd-scoring-close');
    const status   = document.getElementById('jd-scoring-status');
    if (!section || !textarea || !btnScore) return;

    // Show section only for Pro/Annual
    function refreshVisibility() {
      section.style.display = ['pro','annual'].includes(S.plan) ? 'block' : 'none';
    }
    refreshVisibility();

    // Auto-populate from JD Search if user came from there
    const savedJD = document.getElementById('jd-text')?.value?.trim();
    if (savedJD && savedJD.length > 30 && !textarea.value) {
      textarea.value = savedJD;
      if (status) status.textContent = '✓ JD pre-filled from your JD Search';
    }

    btnClose?.addEventListener('click', () => { section.style.display = 'none'; });

    btnClear?.addEventListener('click', () => {
      textarea.value = '';
      if (status) status.textContent = '';
      // Reset scores back to AI/local scoring
      renderProfiles();
    });

    btnScore?.addEventListener('click', async () => {
      const jdText = textarea.value.trim();
      if (!jdText || jdText.length < 30) {
        if (status) { status.textContent = '⚠️ Paste a job description first (min 30 chars)'; status.style.color = '#f59e0b'; }
        return;
      }
      if (S.profiles.length === 0) {
        if (status) { status.textContent = '⚠️ Collect profiles first using Smart Search or Clone Search'; status.style.color = '#f59e0b'; }
        return;
      }
      btnScore.disabled = true;
      btnScore.textContent = '⏳ Scoring ' + Math.min(S.profiles.length, 30) + ' profiles...';
      if (status) { status.textContent = 'Sending to AI — this takes ~10 seconds...'; status.style.color = '#38bdf8'; }

      const scored = await scoreProfilesWithJD(S.profiles, jdText);
      if (scored) {
        // Save JD scores back to profiles
        S.profiles = scored;
        await chrome.storage.local.set({ profiles: scored });
        renderProfiles();
        const topCount = scored.filter(p => (p._score||0) >= 65).length;
        if (status) { status.textContent = `✅ Done! ${topCount} strong matches (score ≥65). Top Picks updated.`; status.style.color = '#00d4aa'; }
      } else {
        if (status) { status.textContent = '❌ Scoring failed — check Cloudflare Worker is deployed with API key'; status.style.color = '#f87171'; }
      }
      btnScore.disabled = false;
      btnScore.textContent = '🎯 Score profiles against this JD';
    });
  }

document.addEventListener('DOMContentLoaded', async () => {

  // Navigation
  initNavigation();

  // Init search screens
  initCloneSearch();
  initJDSearch();
  initPlatformSearch();
  initPredictiveSearch();

  // Smart search form wiring
  initSmartSearch();
  initSalaryIntel();

  // ── API Key management ────────────────────────────────────────
  (async () => {
    const stored = await chrome.storage.local.get('anthropicApiKey');
    const keyInput = document.getElementById('anthropic-key-input');
    if (stored.anthropicApiKey && keyInput) {
      keyInput.value = '••••••••' + stored.anthropicApiKey.slice(-8);
      keyInput.dataset.saved = '1';
    }
    document.getElementById('btn-save-api-key')?.addEventListener('click', async () => {
      const val = (keyInput?.value||'').trim();
      const st  = document.getElementById('api-key-status');
      const show = (msg, color) => { if(st){st.style.display='block';st.style.color=color;st.textContent=msg;} };

      // If field shows masked value, it's already saved
      if(val.startsWith('••')) {
        show('✓ Key already saved. Clear field and re-enter to change.','var(--ts)');
        return;
      }
      if(!val){
        show('⚠️ Paste your Anthropic API key first.','var(--amber)');
        return;
      }
      if(!val.startsWith('sk-ant-')){
        show('⚠️ Key must start with sk-ant-...','var(--red)');
        return;
      }
      await chrome.storage.local.set({ anthropicApiKey: val });
      if(keyInput){ keyInput.value='••••••••'+val.slice(-8); keyInput.dataset.saved='1'; }
      show('✓ Saved! Open any LinkedIn profile to test.','var(--accent)');
      setTimeout(()=>{ if(st) st.style.display='none'; }, 4000);
    });
    document.getElementById('btn-clear-api-key')?.addEventListener('click', async () => {
      await chrome.storage.local.remove('anthropicApiKey');
      if(keyInput) { keyInput.value=''; keyInput.dataset.saved='0'; }
      const st = document.getElementById('api-key-status');
      if(st){st.style.display='block';st.style.color='var(--ts)';st.textContent='API key cleared.';}
      setTimeout(()=>{ if(st) st.style.display='none'; }, 2000);
    });
    // Allow editing saved key
    keyInput?.addEventListener('focus', () => {
      if(keyInput.dataset.saved==='1') { keyInput.value=''; keyInput.dataset.saved='0'; }
    });
  })();

  // Load state
  await syncFromStorage();
  await checkPlanStatus();
  updatePlanBar();
  updateAllCounts();
  renderProfiles();
  renderLog();
  checkLoginState();

  // Auto-show collect button if LinkedIn search is already open
  try {
    const allTabs = await chrome.tabs.query({});
    const liSearch = allTabs.find(t => t.url && t.url.includes('linkedin.com/search/results/people'));
    const liCompany= allTabs.find(t => t.url && t.url.includes('linkedin.com/company/') && t.url.includes('/people'));
    if (liSearch) {
      const cb = document.getElementById('btn-collect');
      if (cb) {
        cb.disabled = false;
        cb.style.cursor = 'pointer';
        cb.style.background = 'linear-gradient(135deg,#0055CC,#0099DD)';
        cb.style.border = 'none';
        cb.style.color = '#fff';
        cb.style.opacity = '1';
        cb.textContent = '📥 Step 2 — Get Profiles from Page';
      }
    }
    if (liCompany) {
      const cob = document.getElementById('btn-co-collect');
      if (cob) cob.style.display = 'block';
    }
  } catch(e) {}

  // ── Auto-detect GitHub profile on active tab ──────────────────
  initGitHubBanner();

  // ── Restore last screen on popup open ────────────────────────
  const savedScreen = await chrome.storage.local.get(['campaignScreen', 'campaign']);
  const lastScreen  = savedScreen.campaignScreen;
  const liveCamp    = savedScreen.campaign;

  if (liveCamp?.running) {
    setTimeout(async () => {
      CMP.running = true;
      CMP.paused  = liveCamp.paused || false;
      await initCampaignScreen();
    }, 200);
  } else if (S.profiles.length > 0) {
    const si  = document.getElementById('scrape-info');
    const siC = document.getElementById('si-count');
    if (si)  si.classList.add('show');
    if (siC) siC.textContent = S.profiles.length + ' profiles found';
    setTimeout(() => {
      showScreen('screen-profiles', 'slide-up');
      renderProfiles();
      updateAllCounts();
    }, 200);
  }

  // On popup open — show searching indicator if scrape is in progress
  const _pendingCheck = await chrome.storage.local.get('pendingScrape');
  if (_pendingCheck.pendingScrape && (Date.now() - _pendingCheck.pendingScrape.requestedAt) < 120000) {
    const kw = _pendingCheck.pendingScrape.params?.keywords || '';
    showStatus('⏳ Collecting profiles for "' + kw + '"... Reopen PingIN in a few seconds.', 'info');
  }

  // Poll every 2s — picks up profiles after service worker scrapes
  let _lastProfileCount = S.profiles.length;
  setInterval(async () => {
    try {
      const d = await chrome.storage.local.get(['profiles','lastSearchParams','pendingScrape']);
      const newCount = (d.profiles || []).length;

      if (newCount !== _lastProfileCount) {
        _lastProfileCount = newCount;
        S.profiles = d.profiles || [];
        if (d.lastSearchParams) S.lastSearchParams = d.lastSearchParams;
        renderProfiles();
        updateAllCounts();
        updateStats();
        if (newCount > 0) {
          const si  = document.getElementById('scrape-info');
          const siC = document.getElementById('si-count');
          if (si)  si.classList.add('show');
          if (siC) siC.textContent = newCount + ' profiles found';
          showScreen('screen-profiles', 'slide-up');
          showStatus('✓ ' + newCount + ' profiles collected! Click any profile to open on LinkedIn.', 'success');
        }
      }
    } catch(e) {}
  }, 2000);

  // SCRAPE_DONE — fires if popup is open when scrape completes
  chrome.runtime.onMessage.addListener(async (msg) => {
    if (msg.action === 'SCRAPE_DONE') {
      await syncFromStorage();
      if (!S.lastSearchParams?.keywords) {
        const stored = await chrome.storage.local.get('lastSearchParams');
        if (stored.lastSearchParams) S.lastSearchParams = stored.lastSearchParams;
      }
      renderProfiles();
      updateAllCounts();
      updateStats();
      const si = document.getElementById('scrape-info');
      const siCount = document.getElementById('si-count');
      if (si) si.classList.add('show');
      if (siCount) siCount.textContent = msg.total + ' profiles found';
      addLog('✓ Scraped: ' + msg.added + ' new · ' + msg.total + ' total (page ' + msg.page + ')');
      if (msg.total > 0) setTimeout(() => showScreen('screen-profiles','slide-up'), 800);
    }
  });

  // Today's search count stat
  const hist = (await chrome.storage.local.get('searchHistory'))?.searchHistory || [];
  const today = new Date().toDateString();
  const todayCount = hist.filter(h => new Date(h.searchedAt).toDateString() === today).length;
  const statSearches = document.getElementById('stat-searches');
  if (statSearches) statSearches.textContent = todayCount;
});

// ═══════════════════════════════════════════════════════════════
//  SMART SEARCH INIT
// ═══════════════════════════════════════════════════════════════
function initSmartSearch() {
  // Keyword dropdown
  const kwInput = document.getElementById('s-keywords');
  const kwDd = document.getElementById('kw-dropdown');
  if (kwInput && kwDd) {
    kwInput.addEventListener('input', () => {
      const q = kwInput.value.trim();
      if (!q || q.length < 2) { kwDd.style.display='none'; return; }
      if (typeof KW_SUGGESTIONS !== 'undefined') {
        const matches = KW_SUGGESTIONS.filter(s => s.toLowerCase().includes(q.toLowerCase())).slice(0,6);
        if (matches.length) {
          kwDd.innerHTML = matches.map(s => '<div class="kw-dd-item"><div class="kw-dd-kw">'+s+'</div></div>').join('');
          kwDd.style.display = 'block';
          kwDd.querySelectorAll('.kw-dd-item').forEach(item => {
            item.addEventListener('click', () => { kwInput.value = item.querySelector('.kw-dd-kw').textContent; kwDd.style.display='none'; });
          });
        } else kwDd.style.display='none';
      }
    });
    document.addEventListener('click', e => { if(!kwInput.contains(e.target)) kwDd.style.display='none'; });
  }

  // Bool chips
  document.getElementById('bool-and')?.addEventListener('click', () => insertKeyword(' AND '));
  document.getElementById('bool-or')?.addEventListener('click',  () => insertKeyword(' OR '));
  document.getElementById('bool-not')?.addEventListener('click', () => insertKeyword(' NOT '));
  document.getElementById('bool-quote')?.addEventListener('click', () => wrapInQuotes());
  document.getElementById('bool-paren')?.addEventListener('click', () => insertKeyword('('));

  // Company search — multi-chip
  const coInput = document.getElementById('s-company');
  const coDd = document.getElementById('company-dropdown');
  if (coInput && coDd) {
    coInput.addEventListener('input', () => filterCompanyDropdown(coInput.value));
    coInput.addEventListener('focus', () => filterCompanyDropdown(coInput.value));
    coInput.addEventListener('blur', () => setTimeout(()=>{ coDd.style.display='none'; },200));
    coInput.addEventListener('keydown', function(e) {
      var v = coInput.value.trim();
      if ((e.key === 'Enter' || e.key === ',') && v) {
        e.preventDefault();
        e.stopPropagation();
        addCompanyChip(v);
        if (coDd) coDd.style.display = 'none';
        return false;
      }
      if (e.key === 'Backspace' && !coInput.value) {
        var arr = getCompanyList();
        if (arr.length) { arr.pop(); setCompanyList(arr); }
      }
    });
    // Handle paste of comma-separated list
    coInput.addEventListener('paste', (e) => {
      setTimeout(() => filterCompanyDropdown(coInput.value), 10);
    });
  }

  // College search
  const collInput = document.getElementById('college-search');
  if (collInput) {
    collInput.addEventListener('input', () => filterDropdown(collInput.value,'s-college','college-dropdown'));
    collInput.addEventListener('focus', () => filterDropdown(collInput.value,'s-college','college-dropdown'));
    collInput.addEventListener('blur', () => setTimeout(()=>{ document.getElementById('college-dropdown').style.display='none'; },200));
  }

  // Degree search
  const degInput = document.getElementById('deg-search');
  if (degInput) {
    degInput.addEventListener('input', () => filterDropdown(degInput.value,'s-degree-type','deg-dropdown'));
    degInput.addEventListener('focus', () => filterDropdown(degInput.value,'s-degree-type','deg-dropdown'));
    degInput.addEventListener('blur', () => setTimeout(()=>{ document.getElementById('deg-dropdown').style.display='none'; },200));
  }

  // Profile type — enable immediately
  const ptEl = document.getElementById('s-profile-type');
  if (ptEl) ptEl.disabled = false;
  document.getElementById('s-profile-type')?.addEventListener('change', updateProfileTypeState);

  // Diversity toggle
  const divToggle = document.getElementById('diversity-toggle');
  const divSub = document.getElementById('diversity-sub');
  divToggle?.addEventListener('change', () => {
    if (divSub) divSub.style.display = divToggle.checked ? 'block' : 'none';
  });

  // Salary info
  document.getElementById('s-salary-range')?.addEventListener('change', function() {
    const box = document.getElementById('salary-info-box');
    if (!box) return;
    if (!this.value) { box.style.display='none'; return; }
    const info = getSalaryInfo(this.value);
    if (info) {
      box.innerHTML = '<span class="s-range">'+info.range+'</span>'+info.tip;
      box.style.display = 'block';
    }
  });

  // Search button
  document.getElementById('btn-search')?.addEventListener('click', startSearch);
  document.getElementById('btn-collect')?.addEventListener('click', collectProfilesNow);

  // Save search
  document.getElementById('btn-save-search')?.addEventListener('click', saveCurrentSearch);

  // Next page
  document.getElementById('btn-next-page')?.addEventListener('click', async () => {
    S.currentPage = (S.currentPage||1) + 1;
    const p = S.lastSearchParams;
    const url = buildSearchUrl(p.keywords,p.location,p.degree,p.experience,p.profileType,p.college,p.company,S.currentPage,p.salaryRange||'',p.diversityFilters||[]);
    await chrome.storage.local.set({ pendingScrape:{ url, params:p, page:S.currentPage, isNewSearch:false, requestedAt:Date.now() } });
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tabs[0]) chrome.tabs.update(tabs[0].id,{url});
    addLog('Scraping page '+S.currentPage+'...');
  });

  // Status bar exports
  document.getElementById('sb-export-btn')?.addEventListener('click', exportCSV);

  // Smart screen exports
  document.getElementById('smart-export-btn')?.addEventListener('click', exportCSV);
}

// Insert keyword helper
function insertKeyword(kw) {
  const el = document.getElementById('s-keywords');
  if (!el) return;
  const pos = el.selectionStart || el.value.length;
  el.value = el.value.slice(0,pos) + kw + el.value.slice(pos);
  el.focus();
  el.setSelectionRange(pos+kw.length, pos+kw.length);
}

function wrapInQuotes() {
  const el = document.getElementById('s-keywords');
  if (!el) return;
  const start = el.selectionStart, end = el.selectionEnd;
  if (start !== end) {
    el.value = el.value.slice(0,start)+'"'+el.value.slice(start,end)+'"'+el.value.slice(end);
  } else {
    insertKeyword('"');
  }
}

// Salary info helper
function getSalaryInfo(val) {
  const MAP = {
    'fresher':      { range:'₹3–8 LPA',  tip:'Entry level · 0–2 yrs · Service/Startup companies' },
    'junior_startup':{ range:'₹8–18 LPA', tip:'Junior · 2–5 yrs · Funded startups (Razorpay, Swiggy)' },
    'junior_product':{ range:'₹12–25 LPA',tip:'Product companies · SDE-1/2 level · 2–5 yrs' },
    'mid_service':  { range:'₹10–20 LPA', tip:'Mid level · 5–8 yrs · TCS/Infosys/Wipro' },
    'mid_product':  { range:'₹20–40 LPA', tip:'Mid level · 5–8 yrs · Flipkart/Freshworks/Zerodha' },
    'mid_gcc':      { range:'₹15–30 LPA', tip:'GCC roles · Google/Amazon/Cisco · 5–8 yrs' },
    'senior_product':{ range:'₹35–65 LPA',tip:'Senior · 8–12 yrs · Product/unicorn companies' },
    'senior_gcc':   { range:'₹40–80 LPA', tip:'GCC senior · 8–12 yrs · FAANG India' },
    'lead_manager': { range:'₹50–100 LPA',tip:'Lead/Manager · 10–15 yrs · Top companies' },
    'director_vp':  { range:'₹80–200 LPA',tip:'Director/VP · 15+ yrs · Large enterprises/startups' },
  };
  return MAP[val] || null;
}

// ═══════════════════════════════════════════════════════════════
//  PROFILES SCREEN INIT
// ═══════════════════════════════════════════════════════════════
async function renderLog() {
  const el = document.getElementById('activity-log');
  if (!el) return;
  if (!S.log || !S.log.length) {
    el.innerHTML = '<div class="log-empty">No activity yet.</div>';
    return;
  }
  el.innerHTML = [...S.log].reverse().slice(0,20).map(entry =>
    '<div class="log-entry"><span class="log-time">' + (entry.time||'') + '</span>' + (entry.msg||entry) + '</div>'
  ).join('');
}

// Wire profiles screen buttons on load
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('btn-export-csv')?.addEventListener('click', exportCSV);
  document.getElementById('btn-export-xlsx')?.addEventListener('click', exportXLSX);
  document.getElementById('btn-clear-profiles')?.addEventListener('click', async () => {
    if (confirm('Clear all '+S.profiles.length+' profiles?')) {
      await clearProfiles();
      renderProfiles();
      updateAllCounts();
    }
  });

  // Smart Outreach button

  // ── Profile card clicks — event delegation (MV3 safe) ──────
  // Main profiles list
  document.getElementById('profiles-list')?.addEventListener('click', e => {
    const card = e.target.closest('.profile-item');
    if (!card) return;
    const url = card.dataset.url;
    if (url && url.startsWith('http')) {
      chrome.tabs.create({ url, active: true });
    } else if (url) {
      chrome.tabs.create({ url: 'https://www.linkedin.com' + url, active: true });
    }
  });

  // Top profiles banner
  document.getElementById('top-profiles-list')?.addEventListener('click', e => {
    const card = e.target.closest('.top-profile-card');
    if (!card) return;
    const url = card.dataset.url;
    if (url && url.startsWith('http')) {
      chrome.tabs.create({ url, active: true });
    } else if (url) {
      chrome.tabs.create({ url: 'https://www.linkedin.com' + url, active: true });
    }
  });

  // Filter buttons
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderProfiles(btn.dataset.filter);
    });
  });

  // Settings screen
  document.getElementById('btn-activate-key')?.addEventListener('click', activateLicenseKey);
  document.getElementById('set-random-delay')?.addEventListener('change', saveSettings);
  document.getElementById('set-biz-hours')?.addEventListener('change', saveSettings);
  document.getElementById('set-skip-connected')?.addEventListener('change', saveSettings);
  document.getElementById('btn-clear-log')?.addEventListener('click', async () => {
    S.log = [];
    await chrome.storage.local.set({ log:[] });
    renderLog();
  });
});

// License key activation
async function activateLicenseKey() {
  const input = document.getElementById('license-key-input');
  const status = document.getElementById('key-status');
  const key = (input?.value||'').trim().toUpperCase();

  if (!key.match(/^PING-[A-Z]{2}-[A-Z0-9]{4}-[A-Z0-9]{4}$/)) {
    if(status){status.style.display='block';status.style.background='rgba(220,38,38,.1)';status.style.color='var(--red)';status.textContent='Invalid key format. Expected: PING-XX-XXXX-XXXX';}
    return;
  }

  const planMap = { FR:'free', ST:'starter', PR:'pro', AN:'annual' };
  const daysMap = { FR:5, ST:15, PR:30, AN:365 };
  const msgMap  = { FR:5, ST:50, PR:50, AN:50 };
  const planCode = key.split('-')[1];
  const plan  = planMap[planCode] || 'pro';
  const days  = daysMap[planCode] || 30;
  const msgs  = msgMap[planCode]  || 50;
  const expiry = new Date(Date.now() + days*86400000).toISOString();

  await chrome.storage.local.set({ licenseKey:key, planStatus:plan, planExpiry:expiry, dailyLimit:msgs });
  S.plan = plan;
  S.planExpiry = expiry;
  S.dailyLimit = msgs;

  const box = document.getElementById('current-key-box');
  const keyVal = document.getElementById('current-key-val');
  const planVal = document.getElementById('current-plan-val');
  if(box) box.style.display='block';
  if(keyVal) keyVal.textContent = key;
  if(planVal) planVal.textContent = plan.charAt(0).toUpperCase()+plan.slice(1)+' · '+days+' days';

  if(status){status.style.display='block';status.style.background='rgba(0,196,154,.1)';status.style.color='var(--accent)';status.textContent='✓ License activated! Plan: '+plan.charAt(0).toUpperCase()+plan.slice(1);}
  updatePlanBar();
}

async function saveSettings() {
  S.settings.randomDelay   = document.getElementById('set-random-delay')?.checked || false;
  S.settings.bizHours      = document.getElementById('set-biz-hours')?.checked || false;
  S.settings.skipConnected = document.getElementById('set-skip-connected')?.checked || false;
  await chrome.storage.local.set({ settings: S.settings });
}

// ── Smart Outreach — open campaign page ──────────

// ══════════════════════════════════════════════════════════════
//  SMART OUTREACH — PERSISTENT IN-POPUP CAMPAIGN (v4)
//  State lives in chrome.storage — survives popup close/reopen
//  Navigates existing LinkedIn tab — no new windows
// ══════════════════════════════════════════════════════════════

// Smart Outreach removed


// ── State ──────────────────────────────────────────────────────
const CMP = {
  type:      'connect',
  limit:     20,
  running:   false,
  paused:    false,
  pollTimer: null,
};

const CMP_TEMPLATES = {
  connect: 'Hi {{first_name}}, I came across your profile at {{company}} and have an exciting opportunity matching your background. Would love to connect!\n\nBest,\nRecruiter',
  message: 'Hi {{first_name}}, hope you\'re doing well. I noticed your experience at {{company}} — have an exciting opportunity I\'d love to share. Would love to chat!\n\nBest,\nRecruiter',
  visit:   '',
  github:  'Hi {{first_name}}, I came across your work on GitHub and was genuinely impressed by your {{role}} skills. We have an exciting opportunity in {{location}} that matches your technical background. Would love to connect and share more details!\n\nBest,\nRecruiter',
};

let _cmpInited = false;

async function initCampaignScreen() {
  // ── Read live state from storage ────────────────────────────
  const d = await chrome.storage.local.get([
    'profiles', 'campaign', 'dailySent', 'sentUrls', 'log'
  ]);
  const camp     = d.campaign || {};
  const profiles = d.profiles || [];
  const sentUrls = new Set(d.sentUrls || []);

  CMP.running = camp.running || false;
  CMP.paused  = camp.paused  || false;

  // ── Header ────────────────────────────────────────────────────
  const hdr = document.getElementById('cmp-hdr-count');
  const sent    = profiles.filter(p => p.status === 'sent').length;
  const failed  = profiles.filter(p => p.status === 'failed').length;
  const pending = profiles.filter(p => ['pending','queued'].includes(p.status)).length;
  const total   = profiles.length;

  if (hdr) {
    if (CMP.running) {
      hdr.textContent = sent + ' sent · ' + pending + ' pending';
    } else {
      hdr.textContent = total + ' candidate' + (total !== 1 ? 's' : '');
    }
  }

  // ── Show correct view ─────────────────────────────────────────
  const setup   = document.getElementById('cmp-setup');
  const running = document.getElementById('cmp-running');
  if (CMP.running) {
    if (setup)   setup.style.display = 'none';
    if (running) running.classList.add('show');
    cmpRefreshRunningUI(d);
  } else {
    if (setup)   setup.style.display = 'block';
    if (running) running.classList.remove('show');
  }

  // ── Restore log from storage ──────────────────────────────────
  if (d.log && d.log.length) {
    const list = document.getElementById('cmp-log-list');
    if (list) {
      list.innerHTML = '';
      d.log.slice(0, 15).forEach(item => {
        const el = document.createElement('div');
        const msg = typeof item === 'string' ? item : (item.msg || '');
        const isOk   = msg.includes('✓') || msg.includes('Sent');
        const isWarn = msg.includes('paused') || msg.includes('limit');
        const isErr  = msg.includes('✗') || msg.includes('error') || msg.includes('failed');
        el.className = 'cmp-log-item' + (isOk ? ' ok' : isWarn ? ' warn' : isErr ? ' err' : '');
        const t = typeof item === 'object' && item.t ? item.t : '';
        el.innerHTML = '<span class="cmp-log-time">' + t + '</span><span>' + msg + '</span>';
        list.appendChild(el);
      });
    }
  }

  // ── Default message ───────────────────────────────────────────
  const ta = document.getElementById('cmp-message');
  if (ta && !ta.value.trim()) {
    ta.value = CMP_TEMPLATES.connect;
    cmpUpdateCharCount();
  }

  // ── Wire buttons ONCE ─────────────────────────────────────────
  if (!_cmpInited) {
    _cmpInited = true;

    document.getElementById('cmp-back-btn')?.addEventListener('click', async () => {
      if (CMP.running && !confirm('Campaign is running. Go back? It continues in background.')) return;
      showScreen('screen-profiles', 'slide-back');
      try { chrome.runtime.sendMessage({ action: 'SAVE_SCREEN', screen: 'profiles' }).catch(() => {}); } catch(e) {}
    });

    document.querySelectorAll('.cmp-type-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const t = btn.dataset.cmpType;
        CMP.type = t;
        document.querySelectorAll('.cmp-type-btn').forEach(b => b.classList.remove('on'));
        btn.classList.add('on');
        const msgTa = document.getElementById('cmp-message');
        if (msgTa) { msgTa.value = CMP_TEMPLATES[t] || ''; cmpUpdateCharCount(); }
      });
    });

    document.querySelectorAll('.cmp-limit-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        CMP.limit = parseInt(btn.dataset.cmpLimit) || 20;
        document.querySelectorAll('.cmp-limit-btn').forEach(b => b.classList.remove('on'));
        btn.classList.add('on');
      });
    });

    document.querySelectorAll('.cmp-var').forEach(btn => {
      btn.addEventListener('click', () => {
        // Variable chip — insert at cursor
        if (btn.dataset.var) {
          cmpInsertVar(btn.dataset.var);
          return;
        }
        // Template chip — replace whole textarea
        if (btn.dataset.tmpl) {
          const ta = document.getElementById('cmp-message');
          if (ta) {
            ta.value = CMP_TEMPLATES[btn.dataset.tmpl] || '';
            cmpUpdateCharCount();
            ta.focus();
          }
        }
      });
    });

    document.getElementById('cmp-message')?.addEventListener('input', cmpUpdateCharCount);
    document.getElementById('cmp-launch-btn')?.addEventListener('click', cmpLaunch);
    document.getElementById('cmp-btn-pause')?.addEventListener('click',  cmpPause);
    document.getElementById('cmp-btn-resume')?.addEventListener('click', cmpResume);
    document.getElementById('cmp-btn-stop')?.addEventListener('click',   cmpStop);
  }

  // ── Start polling if running ──────────────────────────────────
  if (CMP.running) startCmpPolling();
}

function cmpRefreshRunningUI(d) {
  const profiles  = d.profiles  || [];
  const camp      = d.campaign  || {};
  const dailySent = d.dailySent || 0;
  const sent      = profiles.filter(p => p.status === 'sent').length;
  const failed    = profiles.filter(p => p.status === 'failed').length;
  const pending   = profiles.filter(p => ['pending','queued'].includes(p.status)).length;
  const total     = profiles.length;
  const done      = sent + failed;
  const pct       = total > 0 ? Math.round((done / total) * 100) : 0;

  // Status banner
  const sDot  = document.getElementById('cmp-status-dot');
  const sTxt  = document.getElementById('cmp-status-txt');
  const sSub  = document.getElementById('cmp-status-sub');
  const banner = document.getElementById('cmp-status-banner');

  if (camp.paused) {
    if (banner) { banner.style.background = 'rgba(217,119,6,.06)'; banner.style.borderBottomColor = 'rgba(217,119,6,.15)'; }
    if (sDot) sDot.className = 'cmp-status-dot paused';
    if (sTxt) { sTxt.className = 'cmp-status-txt paused'; sTxt.textContent = 'Paused'; }
    if (sSub) sSub.textContent = 'Resume to continue sending';
  } else if (!camp.running && done === total && total > 0) {
    if (banner) { banner.style.background = 'rgba(0,119,181,.06)'; banner.style.borderBottomColor = 'rgba(0,119,181,.15)'; }
    if (sDot) sDot.className = 'cmp-status-dot done';
    if (sTxt) { sTxt.className = 'cmp-status-txt done'; sTxt.textContent = 'Complete'; }
    if (sSub) sSub.textContent = sent + ' connections sent · ' + failed + ' failed';
  } else {
    if (banner) { banner.style.background = 'rgba(0,212,170,.06)'; banner.style.borderBottomColor = 'rgba(0,212,170,.15)'; }
    if (sDot) sDot.className = 'cmp-status-dot';
    if (sTxt) { sTxt.className = 'cmp-status-txt'; sTxt.textContent = 'Running'; }
    if (sSub) sSub.textContent = 'Navigating LinkedIn in background';
  }

  // Progress
  const pf = document.getElementById('cmp-prog-fill');
  const pp = document.getElementById('cmp-prog-pct');
  const pl = document.getElementById('cmp-prog-label');
  const pe = document.getElementById('cmp-prog-eta');
  if (pf) pf.style.width = pct + '%';
  if (pp) pp.textContent = pct + '%';
  if (pl) pl.textContent = done + ' of ' + total + ' actioned';
  if (pe) pe.textContent = pending > 0 ? '~' + Math.ceil(pending * 0.75) + ' min remaining' : done === total ? 'Complete' : '';

  // Stats
  const ss = document.getElementById('cmp-stat-sent');
  const sf = document.getElementById('cmp-stat-failed');
  const sp = document.getElementById('cmp-stat-pending');
  if (ss) ss.textContent = sent;
  if (sf) sf.textContent = failed;
  if (sp) sp.textContent = pending;

  // Safety meter
  const sfill = document.getElementById('cmp-safety-fill');
  const sval  = document.getElementById('cmp-safety-val');
  const safePct = Math.min((dailySent / 25) * 100, 100);
  if (sfill) {
    sfill.style.width = safePct + '%';
    sfill.style.background = safePct >= 90 ? 'var(--red)' : safePct >= 75 ? 'var(--amber)' : 'var(--accent)';
  }
  if (sval) {
    sval.textContent = dailySent + '/25';
    sval.style.color = safePct >= 75 ? 'var(--amber)' : 'var(--accent)';
  }

  // Current candidate
  const queued = profiles.find(p => p.status === 'queued');
  const dot    = document.getElementById('cmp-action-dot');
  if (queued) {
    const ini  = (queued.name || '?').split(' ').map(w => w[0] || '').join('').slice(0, 2).toUpperCase();
    const sub  = [queued.role, queued.company].filter(Boolean).join(' · ');
    const nEl  = document.getElementById('cmp-now-name');
    const sEl  = document.getElementById('cmp-now-sub-text');
    const aEl  = document.getElementById('cmp-now-av');
    if (nEl) nEl.textContent = queued.name || 'Unknown';
    if (sEl) sEl.textContent = sub || '—';
    if (aEl) aEl.textContent = ini;
    if (dot) dot.style.display = 'block';
  } else if (done === total && total > 0) {
    const nEl = document.getElementById('cmp-now-name');
    const sEl = document.getElementById('cmp-now-sub-text');
    const aEl = document.getElementById('cmp-now-av');
    if (nEl) nEl.textContent = '✓ All done!';
    if (sEl) sEl.textContent = sent + ' connections sent';
    if (aEl) aEl.textContent = '✓';
    if (dot) dot.style.display = 'none';
  }

  // Pause/Resume button visibility
  const bp = document.getElementById('cmp-btn-pause');
  const br = document.getElementById('cmp-btn-resume');
  if (bp) bp.style.display = camp.paused ? 'none' : 'flex';
  if (br) br.style.display = camp.paused ? 'flex' : 'none';
}

async function cmpLaunch() {
  const template = document.getElementById('cmp-message')?.value.trim() || '';
  if (CMP.type !== 'visit' && !template) {
    alert('Please write a message before launching.');
    return;
  }
  if (!S.profiles.length) { alert('No profiles to send to. Collect profiles first.'); return; }

  // Save profiles to storage (service worker reads from here)
  await chrome.storage.local.set({
    profiles: S.profiles.map(p => ({ ...p, status: 'pending' })),
  });

  let resp;
  try {
    resp = await // Smart Outreach removed
console.log("[PingIN] Smart Outreach has been removed.");
  } catch(e) { alert('Error: ' + e.message); return; }

  if (!resp?.ok) {
    alert(resp?.error || 'Could not start campaign');
    return;
  }

  CMP.running = true;
  CMP.paused  = false;

  const setup   = document.getElementById('cmp-setup');
  const running = document.getElementById('cmp-running');
  if (setup)   setup.style.display = 'none';
  if (running) running.classList.add('show');

  cmpLog('Campaign started · ' + resp.total + ' candidates', 'ok');
  cmpLog('LinkedIn tab will be navigated to each profile', 'ok');
  cmpLog('Keep LinkedIn open — you can switch tabs freely', 'ok');
  startCmpPolling();
}

async function cmpPause() {
  try {
    const r = await chrome.runtime.sendMessage({ action: 'PAUSE_CAMPAIGN' });
    CMP.paused = r?.paused || true;
    const bp = document.getElementById('cmp-btn-pause');
    const br = document.getElementById('cmp-btn-resume');
    const dot = document.getElementById('cmp-action-dot');
    if (bp) bp.style.display = 'none';
    if (br) br.style.display = 'flex';
    if (dot) dot.style.display = 'none';
    cmpLog('Campaign paused', 'warn');
  } catch(e) {}
}

async function cmpResume() {
  try {
    await chrome.runtime.sendMessage({ action: 'PAUSE_CAMPAIGN' });
    CMP.paused = false;
    const bp = document.getElementById('cmp-btn-pause');
    const br = document.getElementById('cmp-btn-resume');
    const dot = document.getElementById('cmp-action-dot');
    if (bp) bp.style.display = 'flex';
    if (br) br.style.display = 'none';
    if (dot) dot.style.display = 'block';
    cmpLog('Campaign resumed', 'ok');
  } catch(e) {}
}

async function cmpStop() {
  if (!confirm('Stop campaign? Remaining candidates will not be contacted.')) return;
  try { await chrome.runtime.sendMessage({ action: 'STOP_CAMPAIGN' }); } catch(e) {}
  CMP.running = false; CMP.paused = false;
  if (CMP.pollTimer) { clearInterval(CMP.pollTimer); CMP.pollTimer = null; }
  cmpLog('Campaign stopped', 'warn');
  const setup   = document.getElementById('cmp-setup');
  const running = document.getElementById('cmp-running');
  const lb = document.getElementById('cmp-launch-btn');
  if (lb) { lb.disabled = false; lb.innerHTML = '▶&nbsp; Start Outreach'; }
  if (setup)   setup.style.display = 'block';
  if (running) running.classList.remove('show');
}

// ── Poll storage every 2s for live updates ────────────────────
function startCmpPolling() {
  if (CMP.pollTimer) clearInterval(CMP.pollTimer);
  CMP.pollTimer = setInterval(async () => {
    try {
      const d = await chrome.storage.local.get([
        'profiles', 'campaign', 'dailySent', 'sentUrls', 'log'
      ]);
      const camp    = d.campaign || {};
      const profiles = d.profiles || [];
      const done     = profiles.filter(p => ['sent','failed'].includes(p.status)).length;
      const total    = profiles.length;

      CMP.running = camp.running || false;
      CMP.paused  = camp.paused  || false;

      cmpRefreshRunningUI(d);

      // Campaign finished
      if (!camp.running && CMP.running === false && total > 0 && done === total) {
        clearInterval(CMP.pollTimer);
        CMP.pollTimer = null;
        const sent   = profiles.filter(p => p.status === 'sent').length;
        const failed = profiles.filter(p => p.status === 'failed').length;
        cmpLog('✓ Campaign complete · ' + sent + ' sent · ' + failed + ' failed', 'ok');
        cmpLog('Verify: linkedin.com/mynetwork/invitation-manager/sent', 'ok');
        const lb = document.getElementById('cmp-launch-btn');
        if (lb) { lb.disabled = false; lb.innerHTML = '▶&nbsp; Start New Campaign'; }
      }

    } catch(e) {}
  }, 2000);
}

// ── CAMPAIGN_UPDATE from service worker ───────────────────────
// (fires if popup is open during action)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'CAMPAIGN_UPDATE') {
    // Will be picked up by polling — just trigger immediate poll
    chrome.storage.local.get(['profiles','campaign','dailySent'], d => {
      cmpRefreshRunningUI(d);
      if (msg.event === 'sent' || msg.event === 'failed') {
        cmpLog((msg.event === 'sent' ? '✓ Sent → ' : '✗ Failed → ') + (msg.profile?.name || ''), msg.event === 'sent' ? 'ok' : 'err');
      }
      if (msg.event === 'daily_limit') cmpLog('⚠️ Daily limit reached — paused', 'warn');
      if (msg.event === 'complete')    cmpLog('✓ All done!', 'ok');
    });
  }
});

function cmpUpdateCharCount() {
  const ta = document.getElementById('cmp-message');
  const el = document.getElementById('cmp-char-count');
  if (!ta || !el) return;
  const n = ta.value.length;
  el.textContent = n + ' / 300';
  el.style.color = n > 280 ? 'var(--amber)' : 'var(--tm)';
}

function cmpInsertVar(v) {
  const ta = document.getElementById('cmp-message');
  if (!ta) return;
  const s = ta.selectionStart, e = ta.selectionEnd;
  ta.value = ta.value.slice(0, s) + v + ta.value.slice(e);
  ta.selectionStart = ta.selectionEnd = s + v.length;
  ta.focus();
  cmpUpdateCharCount();
}

function cmpLog(msg, type) {
  const list = document.getElementById('cmp-log-list');
  if (!list) return;
  if (list.children.length === 1 && list.children[0].textContent === 'Waiting to start...') list.innerHTML = '';
  const el = document.createElement('div');
  el.className = 'cmp-log-item' + (type === 'ok' ? ' ok' : type === 'warn' ? ' warn' : type === 'err' ? ' err' : '');
  const t = new Date().toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
  el.innerHTML = '<span class="cmp-log-time">' + t + '</span><span>' + msg + '</span>';
  list.insertBefore(el, list.firstChild);
  while (list.children.length > 20) list.removeChild(list.lastChild);
}

// ══════════════════════════════════════════════════════════════
//  GITHUB PROFILE AUTO-DETECTION & LINKEDIN EXTRACTOR
// ══════════════════════════════════════════════════════════════

async function initGitHubBanner() {
  const banner    = document.getElementById('gh-banner');
  const nameEl    = document.getElementById('gh-banner-name');
  const subEl     = document.getElementById('gh-banner-sub');
  const resultEl  = document.getElementById('gh-banner-result');
  const extractBtn = document.getElementById('btn-banner-extract');

  if (!banner || !extractBtn) return;

  // Check active tab URL
  let tabs;
  try {
    tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  } catch(e) { return; }

  const tab = tabs?.[0];
  if (!tab?.url) return;

  // Match github.com/username (not github.com/search, /trending etc.)
  const ghMatch = tab.url.match(/^https:\/\/github\.com\/([a-zA-Z0-9_.-]+)\/?(\?.*)?$/);
  if (!ghMatch) return;

  const username = ghMatch[1];
  // Skip GitHub system pages
  const systemPages = ['login','signup','explore','trending','topics','collections','marketplace','features','enterprise','about','pricing','contact','security','team','site','sponsors','notifications','settings','orgs','issues','pulls','codespaces'];
  if (systemPages.includes(username.toLowerCase())) return;

  // Read profile info from the GitHub tab
  let profileData = { name: username, bio: '', location: '', linkedin: null, skills: '' };
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        // Name
        const name = document.querySelector('[itemprop="name"], .p-name, h1.break-word')?.textContent?.trim() ||
                     document.querySelector('.vcard-fullname')?.textContent?.trim() || '';
        // Bio
        const bio  = document.querySelector('[data-bio-text], .p-note, .user-profile-bio div')?.textContent?.trim() || '';
        // Location
        const loc  = document.querySelector('[itemprop="homeLocation"], .p-label, [aria-label="Home location"]')?.textContent?.trim() ||
                     document.querySelector('li[itemprop="homeLocation"] span')?.textContent?.trim() || '';
        // LinkedIn direct link
        const links = Array.from(document.querySelectorAll('a[href*="linkedin.com/in/"], li a[href*="linkedin.com"]'));
        const liUrl = links[0]?.href || null;
        // Top languages from pinned repos
        const langs = Array.from(document.querySelectorAll('[data-language]')).map(el => el.dataset.language).filter(Boolean);
        const uniqueLangs = [...new Set(langs)].slice(0, 3).join(', ');

        return { name, bio, location: loc, linkedin: liUrl, skills: uniqueLangs };
      }
    });
    if (results?.[0]?.result) profileData = { ...profileData, ...results[0].result };
  } catch(e) {
    // Cannot inject (e.g. page not loaded) — use username only
    profileData = { name: username, bio: '', location: '', linkedin: null, skills: '' };
  }

  // Show banner
  banner.style.display = 'block';
  if (nameEl) nameEl.textContent = profileData.name || username;
  if (subEl) {
    const parts = [];
    if (profileData.skills)   parts.push(profileData.skills);
    if (profileData.location) parts.push(profileData.location);
    subEl.textContent = parts.join(' · ') || '@' + username;
  }

  // Wire extract button
  extractBtn.addEventListener('click', async () => {
    extractBtn.disabled = true;
    extractBtn.textContent = 'Searching...';

    function showResult(msg, ok) {
      if (!resultEl) return;
      resultEl.style.display = 'block';
      resultEl.style.background = ok
        ? 'rgba(0,212,170,.12)' : 'rgba(255,180,0,.12)';
      resultEl.style.border = ok
        ? '1px solid rgba(0,212,170,.3)' : '1px solid rgba(255,180,0,.3)';
      resultEl.style.color  = ok ? '#00D4AA' : '#FFC107';
      resultEl.textContent  = msg;
      extractBtn.disabled   = false;
      extractBtn.textContent = '🔗 Find LinkedIn';
    }

    try {
      // Level 1 — Direct LinkedIn link in profile
      if (profileData.linkedin) {
        await chrome.tabs.create({ url: profileData.linkedin, active: true });
        showResult('✅ LinkedIn profile found and opened directly!', true);
        addLog('GitHub→LinkedIn direct: ' + profileData.linkedin);
        return;
      }

      // Level 2 — Search by name + location
      const name = profileData.name || username;
      const loc  = profileData.location || '';

      if (name && name !== username) {
        // Real name available — do LinkedIn people search
        const liUrl = 'https://www.linkedin.com/search/results/people/?keywords=' +
          encodeURIComponent(name + (loc ? ' ' + loc : '')) +
          '&origin=GLOBAL_SEARCH_HEADER';
        await chrome.tabs.create({ url: liUrl, active: true });
        showResult('🔍 No direct LinkedIn link found. Opened LinkedIn search for "' + name + '"' + (loc ? ' in ' + loc : '') + ' — select the right profile from results.', false);
        addLog('GitHub→LinkedIn name search: ' + name);
        return;
      }

      // Level 3 — No real name, use skills to find similar profiles
      const skills = profileData.skills || profileData.bio?.split(' ').slice(0,3).join(' ') || username;
      const loc3   = profileData.location || '';
      const liUrl3 = 'https://www.linkedin.com/search/results/people/?keywords=' +
        encodeURIComponent(skills + (loc3 ? ' ' + loc3 : '')) +
        '&origin=GLOBAL_SEARCH_HEADER';
      await chrome.tabs.create({ url: liUrl3, active: true });
      showResult("🔍 Direct profile not found. Opened LinkedIn with matching skills instead — you might find someone even better.", false);
      addLog('GitHub→LinkedIn skills fallback: ' + skills);

    } catch(e) {
      showResult('Error: ' + e.message, false);
      extractBtn.disabled   = false;
      extractBtn.textContent = '🔗 Find LinkedIn';
    }
  });
}

// ══════════════════════════════════════════════════════════════
//  FEATURE 1 — SEARCH HISTORY
// ══════════════════════════════════════════════════════════════

function initSearchHistory() {
  const toggleBtn = document.getElementById('btn-show-history');
  const panel     = document.getElementById('search-history-panel');
  const clearBtn  = document.getElementById('btn-clear-history');

  toggleBtn?.addEventListener('click', () => {
    const open = panel.style.display === 'block';
    panel.style.display = open ? 'none' : 'block';
    if (!open) renderSearchHistory();
  });

  clearBtn?.addEventListener('click', async () => {
    if (!confirm('Clear all search history?')) return;
    S.history = [];
    await chrome.storage.local.set({ searchHistory: [] });
    renderSearchHistory();
  });
}

function renderSearchHistory() {
  const list = document.getElementById('search-history-list');
  if (!list) return;

  if (!S.history?.length) {
    list.innerHTML = '<div style="font-size:11px;color:var(--tm);padding:6px 0;">No searches yet.</div>';
    return;
  }

  list.innerHTML = S.history.map((h, i) => {
    const kw   = h.keywords || '—';
    const loc  = h.location  ? ' · ' + h.location  : '';
    const co   = h.company   ? ' · @' + h.company   : '';
    const time = h.searchedAt ? new Date(h.searchedAt).toLocaleDateString('en-IN', { day:'numeric', month:'short' }) : '';
    return `<div class="history-item" data-idx="${i}" style="display:flex;align-items:center;gap:8px;padding:7px 9px;background:var(--surf);border:1px solid var(--border);border-radius:8px;cursor:pointer;transition:border-color .15s;">
      <div style="flex:1;min-width:0;">
        <div style="font-size:11px;font-weight:600;color:var(--tp);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${kw}</div>
        <div style="font-size:10px;color:var(--tm);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${loc}${co}</div>
      </div>
      <div style="font-size:9px;color:var(--tm);flex-shrink:0;">${time}</div>
      <span style="font-size:11px;color:var(--blue-l);flex-shrink:0;font-weight:700;">↩</span>
    </div>`;
  }).join('');

  // Click to re-run search
  list.querySelectorAll('.history-item').forEach(item => {
    item.addEventListener('mouseenter', () => item.style.borderColor = 'var(--border2)');
    item.addEventListener('mouseleave', () => item.style.borderColor = 'var(--border)');
    item.addEventListener('click', () => {
      const h = S.history[parseInt(item.dataset.idx)];
      if (!h) return;
      const set = (id, val) => { const el = document.getElementById(id); if (el && val) el.value = val; };
      set('s-keywords',  h.keywords);
      set('s-location',  h.location);
      // Restore company chips from history
      if (h.companyList && h.companyList.length) {
        setCompanyList(h.companyList);
      } else if (h.company) {
        // legacy history entries — split on OR
        const parts = h.company.split(' OR ').map(s => s.trim().replace(/^"|"$/g,'').trim()).filter(Boolean);
        setCompanyList(parts.length ? parts : [h.company]);
      } else {
        setCompanyList([]);
      }
      set('s-degree',    h.degree);
      set('s-experience',h.experience);
      set('s-college',   h.college);
      document.getElementById('search-history-panel').style.display = 'none';
      // Trigger search
      document.getElementById('btn-search')?.click();
    });
  });
}

// ══════════════════════════════════════════════════════════════
//  FEATURE 2 — CANDIDATE NOTES
// ══════════════════════════════════════════════════════════════

function initCandidateNotes() {
  // Use capture:true so this fires BEFORE the profile-item click handler
  document.getElementById('profiles-list')?.addEventListener('click', e => {
    const noteBtn = e.target.closest('.p-note-btn');
    if (!noteBtn) return;
    e.stopPropagation();
    e.preventDefault();
    const url = noteBtn.dataset.url;
    if (!url) return;
    openNoteModal(url);
  }, true);
}

function openNoteModal(profileUrl) {
  // Find the profile
  const profile = S.profiles.find(p => p.profileUrl === profileUrl);
  if (!profile) return;

  // Remove any existing modal
  document.getElementById('note-modal')?.remove();

  const modal = document.createElement('div');
  modal.id = 'note-modal';
  modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';

  modal.innerHTML = `
    <div style="background:var(--surf);border:1px solid var(--border2);border-radius:14px;padding:16px;width:100%;max-width:340px;box-shadow:0 8px 32px rgba(0,0,0,.5);">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">
        <span style="font-size:18px;">📝</span>
        <div style="flex:1;min-width:0;">
          <div style="font-size:13px;font-weight:700;color:var(--tp);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${profile.name}</div>
          <div style="font-size:10px;color:var(--tm);">${[profile.role, profile.company].filter(Boolean).join(' · ')}</div>
        </div>
        <button id="note-modal-close" style="background:none;border:none;color:var(--ts);font-size:18px;cursor:pointer;padding:2px 6px;">✕</button>
      </div>
      <textarea id="note-textarea" rows="5" placeholder="Add your notes here...&#10;e.g. Called 12 Jan — not interested now&#10;Follow up in March&#10;Salary expects 28L+" style="width:100%;padding:10px 12px;background:var(--surf2);border:1.5px solid var(--border2);border-radius:9px;color:var(--tp);font-size:12px;font-family:inherit;outline:none;resize:none;line-height:1.6;box-sizing:border-box;transition:border-color .15s;">${profile.notes || ''}</textarea>
      <div style="display:flex;gap:8px;margin-top:10px;">
        <button id="note-clear-btn" class="btn-ghost" style="flex:1;padding:8px;font-size:11px;color:var(--tm);">Clear Note</button>
        <button id="note-save-btn" style="flex:2;padding:8px;background:linear-gradient(135deg,#0055CC,#00A890);border:none;border-radius:8px;color:#fff;font-size:12px;font-weight:700;cursor:pointer;font-family:inherit;">💾 Save Note</button>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  const ta = document.getElementById('note-textarea');
  ta?.focus();
  ta?.addEventListener('focus', () => ta.style.borderColor = 'rgba(26,154,222,.45)');
  ta?.addEventListener('blur',  () => ta.style.borderColor = 'var(--border2)');

  async function saveNote() {
    const note = ta?.value?.trim() || '';
    const idx  = S.profiles.findIndex(p => p.profileUrl === profileUrl);
    if (idx !== -1) {
      S.profiles[idx].notes = note;
      await chrome.storage.local.set({ profiles: S.profiles });
      renderProfiles();
    }
    modal.remove();
  }

  document.getElementById('note-save-btn')?.addEventListener('click', saveNote);
  document.getElementById('note-clear-btn')?.addEventListener('click', async () => {
    if (ta) ta.value = '';
    const idx = S.profiles.findIndex(p => p.profileUrl === profileUrl);
    if (idx !== -1) { S.profiles[idx].notes = ''; await chrome.storage.local.set({ profiles: S.profiles }); }
    renderProfiles();
    modal.remove();
  });
  document.getElementById('note-modal-close')?.addEventListener('click', () => modal.remove());
  modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
}

// ══════════════════════════════════════════════════════════════
//  FEATURE 3 — BOOLEAN BUILDER (in Smart Search)
// ══════════════════════════════════════════════════════════════

let boolSkills  = [];
let boolLogic   = 'OR';

function initBooleanBuilder() {
  const toggleBtn  = document.getElementById('bool-builder-toggle');
  const panel      = document.getElementById('bool-builder-panel');
  const addBtn     = document.getElementById('bool-skill-add');
  const skillInput = document.getElementById('bool-skill-input');
  const buildBtn   = document.getElementById('bool-build-btn');
  const logicOR    = document.getElementById('bool-logic-or');
  const logicAND   = document.getElementById('bool-logic-and');

  toggleBtn?.addEventListener('click', () => {
    const open = panel?.style.display === 'block';
    if (panel) panel.style.display = open ? 'none' : 'block';
    if (toggleBtn) toggleBtn.style.background = open ? 'rgba(0,212,170,.1)' : 'rgba(0,212,170,.18)';
  });

  function addSkill() {
    const skill = skillInput?.value?.trim();
    if (!skill) return;
    if (boolSkills.includes(skill)) { if (skillInput) skillInput.value = ''; return; }
    boolSkills.push(skill);
    if (skillInput) skillInput.value = '';
    renderBoolChips();
  }

  addBtn?.addEventListener('click', addSkill);
  skillInput?.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addSkill(); } });

  logicOR?.addEventListener('click', () => {
    boolLogic = 'OR';
    logicOR.style.cssText  += 'background:rgba(0,119,181,.12);border-color:rgba(91,181,255,.3);color:var(--blue-l);';
    logicAND.style.cssText += 'background:var(--surf2);border-color:var(--border);color:var(--ts);';
    document.getElementById('bool-logic-label').textContent = 'OR (any skill)';
  });

  logicAND?.addEventListener('click', () => {
    boolLogic = 'AND';
    logicAND.style.cssText += 'background:rgba(0,119,181,.12);border-color:rgba(91,181,255,.3);color:var(--blue-l);';
    logicOR.style.cssText  += 'background:var(--surf2);border-color:var(--border);color:var(--ts);';
    document.getElementById('bool-logic-label').textContent = 'AND (all skills)';
  });

  buildBtn?.addEventListener('click', () => {
    if (!boolSkills.length) { alert('Add at least one skill first.'); return; }
    // Build Boolean string
    const quoted = boolSkills.map(s => s.includes(' ') ? '"' + s + '"' : s);
    const boolStr = quoted.join(' ' + boolLogic + ' ');
    const kwInput = document.getElementById('s-keywords');
    if (kwInput) kwInput.value = boolStr;
    // Hide builder
    if (panel) panel.style.display = 'none';
    addLog('Boolean built: ' + boolStr);
  });
}

function renderBoolChips() {
  const container = document.getElementById('bool-skill-chips');
  if (!container) return;
  container.innerHTML = boolSkills.map((skill, i) =>
    `<span style="display:inline-flex;align-items:center;gap:4px;padding:3px 8px;background:rgba(0,119,181,.12);border:1px solid rgba(91,181,255,.25);border-radius:5px;font-size:10px;font-weight:600;color:var(--blue-l);">
      ${skill}
      <span data-idx="${i}" class="bool-remove" style="cursor:pointer;color:var(--ts);font-size:12px;line-height:1;">×</span>
    </span>`
  ).join('');

  container.querySelectorAll('.bool-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      boolSkills.splice(parseInt(btn.dataset.idx), 1);
      renderBoolChips();
    });
  });
}

// ══════════════════════════════════════════════════════════════
//  FEATURE 4 — JD LIBRARY (inside JD Search)
// ══════════════════════════════════════════════════════════════

const JD_STORE_KEY = 'jdLibrary';

async function loadJDLibrary() {
  const d = await chrome.storage.local.get(JD_STORE_KEY);
  return d[JD_STORE_KEY] || [];
}

async function saveJDLibrary(library) {
  await chrome.storage.local.set({ [JD_STORE_KEY]: library });
}

async function initJDLibrary() {
  const saveBtn = document.getElementById('btn-save-jd');

  saveBtn?.addEventListener('click', async () => {
    const text = document.getElementById('jd-text')?.value?.trim();
    if (!text || text.length < 30) {
      alert('Paste a job description first (at least 30 characters).');
      return;
    }
    // Extract a title from first line
    const firstLine = text.split('\n')[0].trim().slice(0, 60);
    const title = prompt('Name this JD (for easy recall):', firstLine);
    if (!title) return;

    const library = await loadJDLibrary();
    // Max 10 saved JDs
    if (library.length >= 10) {
      alert('JD Library is full (max 10). Delete one first.');
      return;
    }
    library.unshift({ id: Date.now(), title, text, savedAt: new Date().toISOString() });
    await saveJDLibrary(library);
    renderJDLibrary(library);
    addLog('JD saved: ' + title);
  });

  const library = await loadJDLibrary();
  renderJDLibrary(library);
}

function renderJDLibrary(library) {
  const list = document.getElementById('jd-library-list');
  if (!list) return;

  if (!library?.length) {
    list.innerHTML = '<div style="font-size:11px;color:var(--tm);text-align:center;padding:10px 0;">No saved JDs yet. Paste a JD and click Save.</div>';
    return;
  }

  list.innerHTML = library.map((jd, i) =>
    `<div style="display:flex;align-items:center;gap:8px;padding:8px 10px;background:var(--surf);border:1px solid var(--border);border-radius:9px;">
      <div style="flex:1;min-width:0;cursor:pointer;" class="jd-lib-load" data-idx="${i}">
        <div style="font-size:11px;font-weight:600;color:var(--tp);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${jd.title}</div>
        <div style="font-size:9px;color:var(--tm);margin-top:1px;">${jd.text.slice(0,50)}...</div>
      </div>
      <button class="btn-ghost jd-lib-delete" data-idx="${i}" style="padding:4px 8px;font-size:10px;color:var(--tm);flex-shrink:0;">🗑</button>
    </div>`
  ).join('');

  // Load JD on click
  list.querySelectorAll('.jd-lib-load').forEach(el => {
    el.addEventListener('click', () => {
      const jd  = library[parseInt(el.dataset.idx)];
      const ta  = document.getElementById('jd-text');
      if (ta && jd) {
        ta.value = jd.text;
        ta.scrollTop = 0;
        addLog('JD loaded: ' + jd.title);
        // Auto-trigger analysis
        setTimeout(() => document.getElementById('btn-jd-analyse')?.click(), 300);
      }
    });
  });

  // Delete JD
  list.querySelectorAll('.jd-lib-delete').forEach(btn => {
    btn.addEventListener('click', async () => {
      const idx = parseInt(btn.dataset.idx);
      if (!confirm('Delete "' + library[idx]?.title + '"?')) return;
      library.splice(idx, 1);
      await saveJDLibrary(library);
      renderJDLibrary(library);
    });
  });
}

// ── Wire all 4 features in DOMContentLoaded ───────────────────
document.addEventListener('DOMContentLoaded', () => {
  initSearchHistory();
  initCandidateNotes();
  initBooleanBuilder();
  initJDLibrary();
});
