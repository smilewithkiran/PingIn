'use strict';

// Plan details
const PLANS = {
  pro:  { name:'Pro Plan', price:'₹999/month',  amount: 99900 },
  team: { name:'Team Plan', price:'₹3,499/month', amount: 349900 },
};
let selectedPlan = null;

document.addEventListener('DOMContentLoaded', async () => {
  // Back button
  document.getElementById('back-btn').addEventListener('click', () => {
    window.location.href = 'popup.html';
  });

  // Load trial/limit status
  const data = await chrome.storage.local.get(['planStatus','trialDaysLeft','dailySent','dailyLimit']);
  const status = data.planStatus || 'trial';
  const daysLeft = data.trialDaysLeft || 0;
  const dailySent = data.dailySent || 0;
  const dailyLimit = data.dailyLimit || 10;

  const title = document.getElementById('tb-title');
  const sub   = document.getElementById('tb-sub');

  if (status === 'limit_reached') {
    title.textContent = 'Daily message limit reached';
    sub.textContent   = `You have sent ${dailySent} of ${dailyLimit} messages today. Limit resets at midnight IST.`;
  } else if (status === 'trial_expired') {
    title.textContent = '7-day free trial has ended';
    sub.textContent   = 'Upgrade to Pro to continue searching and sending connection requests.';
  } else {
    title.textContent = `${daysLeft} day${daysLeft===1?'':'s'} left in your free trial`;
    sub.textContent   = 'Upgrade now to unlock multi-page scraping, saved searches, and 50 msgs/day.';
  }

  // Plan buttons
  document.getElementById('btn-pro').addEventListener('click',  () => selectPlan('pro'));
  document.getElementById('btn-team').addEventListener('click', () => selectPlan('team'));

  // Card number formatting
  document.getElementById('pf-card').addEventListener('input', function() {
    this.value = this.value.replace(/\D/g,'').replace(/(.{4})/g,'$1 ').trim();
  });
  document.getElementById('pf-exp').addEventListener('input', function() {
    this.value = this.value.replace(/\D/g,'').replace(/^(\d{2})(\d)/,'$1 / $2');
  });

  // Pay button
  document.getElementById('btn-pay').addEventListener('click', processPayment);
});

function selectPlan(plan) {
  selectedPlan = plan;
  const p = PLANS[plan];
  document.getElementById('pf-plan-name').textContent = p.name + ' — ' + p.price;
  document.getElementById('pay-btn-text').textContent = 'Pay ' + p.price + ' & Activate';

  const form = document.getElementById('payment-form');
  form.style.display = 'block';
  form.scrollIntoView({ behavior:'smooth' });
}

async function processPayment() {
  const name   = document.getElementById('pf-name').value.trim();
  const email  = document.getElementById('pf-email').value.trim();
  const mobile = document.getElementById('pf-mobile').value.trim();
  const card   = document.getElementById('pf-card').value.replace(/\s/g,'');
  const exp    = document.getElementById('pf-exp').value.trim();
  const cvv    = document.getElementById('pf-cvv').value.trim();

  if (!name || !email || !mobile || card.length < 16 || !exp || cvv.length < 3) {
    alert('Please fill in all payment details correctly.');
    return;
  }

  const btn = document.getElementById('btn-pay');
  btn.disabled = true;
  document.getElementById('pay-btn-text').textContent = 'Processing...';

  // Simulate payment processing (replace with real Razorpay integration)
  await new Promise(r => setTimeout(r, 2000));

  // On success — activate premium
  await chrome.storage.local.set({
    planStatus:    selectedPlan,          // 'pro' or 'team'
    planActivated: new Date().toISOString(),
    planExpiry:    new Date(Date.now() + 30*24*3600*1000).toISOString(),
    dailyLimit:    selectedPlan === 'team' ? 50 : 50,
    userEmail:     email,
    userName:      name,
  });

  // Show success
  btn.style.display = 'none';
  document.getElementById('pay-success').style.display = 'block';
  document.querySelector('.pay-secure').style.display  = 'none';

  // Redirect back to app after 2.5s
  setTimeout(() => { window.location.href = 'popup.html'; }, 2500);
}
