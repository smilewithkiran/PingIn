'use strict';

// ═══════════════════════════════════════════════════════════════
//  PingIN Content Script v5
//  LinkedIn: Profile Scraper + Salary Estimate Overlay
// ═══════════════════════════════════════════════════════════════

// ── Profile scraping (search results) ───────────────────────────
let lastUrl = location.href;

const _observer = new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    if (location.href.includes('linkedin.com/search/results/people')) {
      setTimeout(() => chrome.runtime.sendMessage({ action: 'PAGE_CHANGED', url: location.href }).catch(() => {}), 3000);
    }
    // Re-run salary overlay on LinkedIn SPA navigation
    setTimeout(siRun, 1500);
  }
});
_observer.observe(document.body, { childList: true, subtree: true });

function scrapeProfilesFromPage() {
  const results = [];
  try {
    const cards = document.querySelectorAll(
      '.reusable-search__result-container, .search-results-container li, [data-view-name="search-entity-result-universal-template"]'
    );
    cards.forEach(card => {
      try {
        const nameEl = card.querySelector(
          '.entity-result__title-text a span[aria-hidden="true"], .entity-result__title span[aria-hidden="true"], a.app-aware-link span[aria-hidden="true"]'
        );
        const name = nameEl?.textContent?.trim();
        if (!name || name.toLowerCase().includes('linkedin member')) return;
        const linkEl = card.querySelector('a[href*="/in/"]');
        const profileUrl = linkEl ? 'https://www.linkedin.com' + new URL(linkEl.href).pathname : null;
        if (!profileUrl) return;
        const subEl  = card.querySelector('.entity-result__primary-subtitle');
        const role   = subEl?.textContent?.trim() || '';
        const secEl  = card.querySelector('.entity-result__secondary-subtitle');
        const company = secEl?.textContent?.trim() || '';
        const locEl  = card.querySelector('.entity-result__tertiary-subtitle, .entity-result__simple-insight-text');
        const city   = locEl?.textContent?.trim() || '';
        const photoEl = card.querySelector('img.presence-entity__image, .entity-result__universal-image img');
        const photo  = photoEl?.src || '';
        const isOTW  = !!card.querySelector('[aria-label*="Open to work"], .open-to-work-badge');
        const degEl  = card.querySelector('.entity-result__badge-text, .dist-value, [class*="distance"]');
        const degree = degEl?.textContent?.trim() || '';
        results.push({ name, profileUrl, role, company, city, photo, isOTW, degree, status: 'pending', scrapedAt: new Date().toISOString() });
      } catch(e) {}
    });
  } catch(e) {}
  return results;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'SCRAPE_PAGE') {
    sendResponse({ ok: true, profiles: scrapeProfilesFromPage() });
  }
  return true;
});

if (location.href.includes('linkedin.com/search/results/people')) {
  setTimeout(() => {
    const count = scrapeProfilesFromPage().length;
    if (count > 0) chrome.runtime.sendMessage({ action: 'RESULTS_READY', count }).catch(() => {});
  }, 3000);
}

// ═══════════════════════════════════════════════════════════════
//  SALARY ESTIMATE OVERLAY
//  Appears on every LinkedIn profile page automatically
//  Pure client-side — no API call, instant result
// ═══════════════════════════════════════════════════════════════

// ── Salary bands (India 2025-26) ─────────────────────────────
const SI_TIERS = {
  faang:   ['google','microsoft','amazon','meta','apple','nvidia','adobe','salesforce','oracle','intel','qualcomm','cisco','goldman sachs','jpmorgan','morgan stanley','american express','mckinsey','bcg','bain','walmart global tech','samsung research','bloomberg','citadel','two sigma'],
  unicorn: ['razorpay','cred','zerodha','groww','phonepe','meesho','nykaa','swiggy','zomato','ola','byju','freshworks','zoho','browserstack','postman','chargebee','darwinbox','lenskart','cars24','policybazaar','paytm','delhivery','shiprocket','dream11','miro','juspay','setu','slice','jupiter','khatabook','okcredit','finbox','smallcase','indmoney','epifi','niyo','open','fi money','uni cards','onecard','insurance dekho'],
  mnc:     ['ibm','sap','vmware','servicenow','workday','zendesk','atlassian','mongodb','datadog','snowflake','stripe','paypal','visa','mastercard','hsbc','barclays','ubs','standard chartered','deutsche bank','ey','pwc','kpmg','deloitte','accenture','capgemini','thoughtworks','publicis','optum','unitedhealthcare','astrazeneca','novartis','pfizer','abbott','shell','bp','honeywell','siemens','bosch','ge','philips','3m','caterpillar','cummins','target','walmart'],
  startup: ['flipkart','myntra','bigbasket','blinkit','zepto','practo','cure.fit','1mg','healthifyme','cashfree','instamojo','payu','pine labs','ather','ola electric','rapido','porter','shadowfax','moglix','ofbusiness','udaan','zetwerk','mamaearth','boat','noise','licious','urban company','pristyn care','healthifyme','stanza living','awfis'],
  service: ['tcs','infosys','wipro','hcl','tech mahindra','ltimindtree','mphasis','hexaware','persistent','cyient','coforge','birlasoft','kpit','cognizant','genpact','wns','exlservice','niit','mastech','firstsource','sutherland','concentrix','teleperformance','igate','syntel'],
};

const SI_SALARY = {
  faang:   { intern:[8,15],   fresher:[15,25],  junior:[22,38],  mid:[38,68],   senior:[62,100],  lead:[88,150],  principal:[135,220], director:[195,350] },
  unicorn: { intern:[5,10],   fresher:[10,18],  junior:[16,28],  mid:[26,48],   senior:[42,72],   lead:[66,108],  principal:[96,158],  director:[145,248] },
  mnc:     { intern:[4,8],    fresher:[7,13],   junior:[12,22],  mid:[20,38],   senior:[34,58],   lead:[52,88],   principal:[76,128],  director:[116,198] },
  startup: { intern:[3,7],    fresher:[6,12],   junior:[9,18],   mid:[16,30],   senior:[26,48],   lead:[42,72],   principal:[62,102],  director:[92,158]  },
  service: { intern:[2,4],    fresher:[3,6],    junior:[5,10],   mid:[8,17],    senior:[14,27],   lead:[22,40],   principal:[34,58],   director:[52,88]   },
  other:   { intern:[1,3],    fresher:[2,5],    junior:[3,7],    mid:[6,13],    senior:[10,20],   lead:[16,32],   principal:[26,48],   director:[40,72]   },
};

const SI_CITY_MULT = {
  'bengaluru':1.00,'bangalore':1.00,'mumbai':0.95,'hyderabad':0.88,
  'pune':0.87,'delhi':0.92,'gurgaon':0.90,'gurugram':0.90,
  'noida':0.88,'chennai':0.85,'kolkata':0.78,'ahmedabad':0.76,
};

const SI_TIER_LABEL = {
  faang:'FAANG / Top GCC', unicorn:'Unicorn / Product',
  mnc:'MNC India', startup:'Indian Startup',
  service:'IT Services', other:'SME / Other',
};

function siGetTier(company) {
  const c = (company || '').toLowerCase();
  for (const [tier, list] of Object.entries(SI_TIERS)) {
    if (list.some(n => c.includes(n))) return tier;
  }
  return 'other';
}

function siGetExp(title) {
  const t = (title || '').toLowerCase();
  if (/intern|trainee/.test(t))                                         return 'intern';
  if (/fresher|graduate|entry.?level|0.?[–-].?1/.test(t))              return 'fresher';
  if (/junior|associate|sde.?1|l3|sde-i\b/.test(t))                    return 'junior';
  if (/mid|sde.?2|l4|sr\.?\s+associate|staff\s+eng/.test(t))           return 'mid';
  if (/senior|sde.?3|l5|sr\.?\s+eng|principal\s+assoc/.test(t))        return 'senior';
  if (/lead|manager|l6|engineering\s+manager|tech\s+lead/.test(t))      return 'lead';
  if (/principal|staff|l7|architect|distinguished/.test(t))             return 'principal';
  if (/director|vp|vice\s+president|l8|fellow|head\s+of/.test(t))      return 'director';
  return 'mid'; // default
}

function siGetCityMult(city) {
  const c = (city || '').toLowerCase();
  for (const [key, mult] of Object.entries(SI_CITY_MULT)) {
    if (c.includes(key)) return mult;
  }
  return 0.85; // default outside tier-1
}

function siFmt(n) {
  return n >= 100 ? (n / 100).toFixed(1) + ' Cr' : n + 'L';
}

function siCalc(role, company, city) {
  const tier   = siGetTier(company);
  const sen    = siGetExp(role);
  const mult   = siGetCityMult(city);
  const band   = SI_SALARY[tier][sen];
  const min    = Math.round(band[0] * mult);
  const max    = Math.round(band[1] * mult);
  return { min, max, tier, sen, tierLabel: SI_TIER_LABEL[tier] };
}

// ── Read profile data from LinkedIn DOM ──────────────────────
function readProfileData() {
  // Role / headline
  const role =
    document.querySelector('.text-heading-xlarge, .top-card-layout__headline, [data-generated-suggestion-target] h2')?.textContent?.trim() ||
    document.querySelector('.pv-text-details__left-panel h2, .ph5 h2')?.textContent?.trim() || '';

  // Current company from experience section
  let company = '';
  const expItems = document.querySelectorAll('#experience ~ .pvs-list__outer-container li, .pv-profile-section__card-item, [data-view-name="profile-component-entity"]');
  for (const item of expItems) {
    const co = item.querySelector('.hoverable-link-text span[aria-hidden="true"], .pv-entity__secondary-title, .t-14.t-normal span[aria-hidden="true"]')?.textContent?.trim();
    if (co && co.length > 1) { company = co; break; }
  }
  // Fallback — extract from headline "Senior Dev at Razorpay"
  if (!company && role.includes(' at ')) {
    company = role.split(' at ').slice(-1)[0].trim();
  }

  // Location
  const city =
    document.querySelector('.pv-text-details__left-panel span.text-body-small:not(.visually-hidden), .top-card-layout__first-subline + .top-card-layout__second-subline')?.textContent?.trim() ||
    document.querySelector('[class*="location"]')?.textContent?.trim() || '';

  // Name
  const name =
    document.querySelector('h1.text-heading-xlarge, h1.top-card__title, [data-generated-suggestion-target] h1')?.textContent?.trim() ||
    document.querySelector('.pv-text-details__left-panel h1')?.textContent?.trim() || 'This person';

  return { name, role, company, city };
}

// ── Inject salary overlay on profile page ────────────────────
const OVERLAY_ID = 'pingin-salary-overlay';

function siInjectOverlay(data) {
  // Remove existing
  document.getElementById(OVERLAY_ID)?.remove();

  const { name, role, company, city } = data;
  if (!role && !company) return; // not enough data

  const r = siCalc(role, company, city);
  const rangeText = '₹' + siFmt(r.min) + ' – ₹' + siFmt(r.max) + ' PA';

  const overlay = document.createElement('div');
  overlay.id = OVERLAY_ID;
  overlay.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 99999;
    width: 252px;
    background: #0D0F14;
    border: 1.5px solid rgba(91,181,255,.28);
    border-radius: 14px;
    overflow: hidden;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    box-shadow: 0 8px 32px rgba(0,0,0,.6), 0 0 0 1px rgba(255,255,255,.04);
    transition: opacity .3s, transform .3s;
    opacity: 0;
    transform: translateY(8px);
  `;

  overlay.innerHTML = `
    <div style="
      padding:9px 12px 7px;
      background:linear-gradient(135deg,#0A0C10,#111827);
      border-bottom:1px solid rgba(255,255,255,.07);
      position:relative;
    ">
      <div style="position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,#0077B5,#00C49A);"></div>
      <div style="display:flex;align-items:center;justify-content:space-between;">
        <div style="font-size:11px;font-weight:800;color:#fff;letter-spacing:-.2px;">
          💰 PingIN <span style="background:linear-gradient(90deg,#5BB5FF,#00C49A);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">Salary Intel</span>
        </div>
        <button id="pingin-si-close" style="
          background:none;border:none;color:rgba(255,255,255,.35);
          font-size:14px;cursor:pointer;padding:0;line-height:1;
        ">✕</button>
      </div>
      <div style="font-size:9px;color:rgba(255,255,255,.35);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
        ${name.split(' ')[0]}${company ? ' · ' + company.split(',')[0].slice(0,22) : ''}
      </div>
    </div>

    <div style="padding:10px 12px 12px;">
      <div style="
        font-size:22px;font-weight:800;color:#5BB5FF;
        letter-spacing:-.4px;line-height:1;margin-bottom:10px;
      ">${rangeText}</div>

      <div style="display:flex;flex-direction:column;gap:5px;margin-bottom:10px;">
        <div style="display:flex;justify-content:space-between;font-size:10px;">
          <span style="color:rgba(255,255,255,.4);">Company tier</span>
          <span style="color:rgba(255,255,255,.75);font-weight:600;">${r.tierLabel}</span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:10px;">
          <span style="color:rgba(255,255,255,.4);">Seniority</span>
          <span style="color:rgba(255,255,255,.75);font-weight:600;">${r.sen.charAt(0).toUpperCase() + r.sen.slice(1)}</span>
        </div>
        ${city ? `<div style="display:flex;justify-content:space-between;font-size:10px;">
          <span style="color:rgba(255,255,255,.4);">Location</span>
          <span style="color:rgba(255,255,255,.75);font-weight:600;">${city.split(',')[0].slice(0,18)}</span>
        </div>` : ''}
      </div>

      <div style="
        background:rgba(255,180,0,.07);border:1px solid rgba(255,180,0,.15);
        border-radius:7px;padding:6px 9px;font-size:9px;
        color:rgba(255,200,80,.7);line-height:1.5;
      ">
        ⚡ Estimation only · Based on India market data 2025–26<br>
        Glassdoor · AmbitionBox · Levels.fyi
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  // Animate in
  requestAnimationFrame(() => {
    overlay.style.opacity = '1';
    overlay.style.transform = 'translateY(0)';
  });

  // Close button
  document.getElementById('pingin-si-close')?.addEventListener('click', () => {
    overlay.style.opacity = '0';
    overlay.style.transform = 'translateY(8px)';
    setTimeout(() => overlay.remove(), 300);
  });

  // Auto-hide after 12 seconds
  setTimeout(() => {
    if (document.getElementById(OVERLAY_ID)) {
      overlay.style.opacity = '0';
      overlay.style.transform = 'translateY(8px)';
      setTimeout(() => overlay.remove(), 300);
    }
  }, 12000);
}

// ── Run on LinkedIn profile pages ────────────────────────────
function siRun() {
  const url = location.href;

  // Only on individual profile pages — not search results
  const isProfile = url.includes('linkedin.com/in/') &&
    !url.includes('/search') &&
    !url.includes('/messaging') &&
    !url.includes('/feed');

  if (!isProfile) return;

  // Wait for React to render profile content
  setTimeout(() => {
    const data = readProfileData();
    if (data.role || data.company) {
      siInjectOverlay(data);
    }
  }, 2500);
}

// Run on initial load
siRun();
