'use strict';
// ══════════════════════════════════════════════════
//  PingIN Smart Outreach — campaign.js
//  All event binding via addEventListener (MV3 safe)
// ══════════════════════════════════════════════════

const C = {
  profiles:     [],
  filterMode:   'all',
  campaignType: 'connect',
  dailyLimit:   20,
  delay:        60,
  spread:       1,
  schedule:     'now',
  yourName:     '',
  template:     '',
  running:      false,
  paused:       false,
  currentIdx:   0,
  timer:        null,
  connToday:    0,
  msgToday:     0,
  visitToday:   0,
  logs:         [],
};

const TEMPLATES = {
  job:      `Hi {{first_name}},\n\nI noticed your experience at {{company}} and think you would be a great fit for an exciting opportunity we are currently working on.\n\nWould love to connect and share more details.\n\nBest,\n{{your_name}}`,
  passive:  `Hi {{first_name}},\n\nCame across your impressive background at {{company}}. We occasionally work on exclusive roles for senior profiles — would be great to have you in my network for future opportunities.\n\nBest,\n{{your_name}}`,
  referral: `Hi {{first_name}},\n\nI am currently hiring for a {{role}} role in {{location}} and thought your network might have the right person. Would love to connect and discuss.\n\nBest,\n{{your_name}}`,
};

// ── DOM ready ─────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  bindAllEvents();
  loadProfiles();
  setDefaultTemplate();
});

// ── Bind ALL events here — no inline handlers ─────
function bindAllEvents() {

  // Filter tabs
  const ftabs = document.querySelectorAll('.ftab');
  const filterModes = ['all','pending','sent','accepted','replied'];
  ftabs.forEach((btn, i) => {
    btn.addEventListener('click', () => {
      ftabs.forEach(b => b.classList.remove('on'));
      btn.classList.add('on');
      C.filterMode = filterModes[i] || 'all';
      renderCandidates();
    });
  });

  // Right panel tabs
  const rtabNames = ['setup','template','schedule','stats','log'];
  document.querySelectorAll('.rtab').forEach((btn, i) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.rtab').forEach(b => b.classList.remove('on'));
      document.querySelectorAll('.rtab-pane').forEach(p => p.classList.remove('active'));
      btn.classList.add('on');
      const pane = document.getElementById('tab-' + rtabNames[i]);
      if (pane) pane.classList.add('active');
    });
  });

  // Campaign type cards
  const typeCards = document.querySelectorAll('.type-card');
  const typeNames = ['connect','message','visit'];
  typeCards.forEach((card, i) => {
    card.addEventListener('click', () => {
      const type = typeNames[i];
      C.campaignType = type;
      typeCards.forEach(c => c.classList.remove('on'));
      card.classList.add('on');
      updateSummary();
    });
  });

  // Daily limit buttons
  const limitVals = [5, 10, 20, 25];
  document.querySelectorAll('#limit-btns .lbtn').forEach((btn, i) => {
    btn.addEventListener('click', () => {
      C.dailyLimit = limitVals[i];
      document.querySelectorAll('#limit-btns .lbtn').forEach(b => b.classList.remove('on'));
      btn.classList.add('on');
      updateSummary();
    });
  });

  // Delay buttons
  const delayVals = [30, 60, 120, 'random'];
  document.querySelectorAll('#delay-btns .sbtn').forEach((btn, i) => {
    btn.addEventListener('click', () => {
      C.delay = delayVals[i];
      document.querySelectorAll('#delay-btns .sbtn').forEach(b => b.classList.remove('on'));
      btn.classList.add('on');
    });
  });

  // Campaign controls
  document.getElementById('btn-launch')?.addEventListener('click', launchCampaign);
  document.getElementById('btn-pause')?.addEventListener('click', pauseCampaign);
  document.getElementById('btn-resume')?.addEventListener('click', resumeCampaign);

  // Stop button (3rd in ctrl-row)
  const ctrlBtns = document.querySelectorAll('.ctrl-row .ctrl-btn');
  if (ctrlBtns[2]) ctrlBtns[2].addEventListener('click', stopCampaign);

  // Template textarea char count
  const ta = document.getElementById('msg-template');
  if (ta) ta.addEventListener('input', updateCharCount);

  // Variable chips
  const varNames = ['{{first_name}}','{{company}}','{{role}}','{{location}}','{{your_name}}'];
  document.querySelectorAll('.vc').forEach((btn, i) => {
    btn.addEventListener('click', () => insertVar(varNames[i] || ''));
  });

  // Quick template buttons — schedule tab sbtn items
  const tmplBtns = document.querySelectorAll('#tab-template .sbtn');
  const tmplKeys = ['job','passive','referral'];
  tmplBtns.forEach((btn, i) => {
    btn.addEventListener('click', () => {
      const ta = document.getElementById('msg-template');
      if (ta) { ta.value = TEMPLATES[tmplKeys[i]] || ''; updateCharCount(); }
      tmplBtns.forEach(b => b.classList.remove('on'));
      btn.classList.add('on');
    });
  });

  // Schedule tab buttons
  const schedBtns = document.querySelectorAll('#tab-schedule .sbtn:not([data-spread])');
  const schedVals = ['now','tomorrow','custom'];
  schedBtns.forEach((btn, i) => {
    if (btn.closest('[id]')?.id === 'spread-btns') return;
    btn.addEventListener('click', () => {
      C.schedule = schedVals[i] || 'now';
      schedBtns.forEach(b => b.classList.remove('on'));
      btn.classList.add('on');
      const cf = document.getElementById('custom-time-field');
      if (cf) cf.style.display = C.schedule === 'custom' ? 'block' : 'none';
      const ss = document.getElementById('sum-start');
      if (ss) ss.textContent = C.schedule === 'now' ? 'Now' : C.schedule === 'tomorrow' ? 'Tomorrow 9 AM' : 'Custom';
    });
  });

  // Spread buttons
  const spreadVals = [1,2,3,7];
  document.querySelectorAll('#spread-btns .sbtn').forEach((btn, i) => {
    btn.addEventListener('click', () => {
      C.spread = spreadVals[i];
      document.querySelectorAll('#spread-btns .sbtn').forEach(b => b.classList.remove('on'));
      btn.classList.add('on');
      updateSummary();
    });
  });
}

// ── Load profiles from extension storage ──────────
async function loadProfiles() {
  try {
    const data = await chrome.storage.local.get(['campaignProfiles','profiles','lastSearch']);
    const raw  = data.campaignProfiles || data.profiles || [];
    C.profiles = raw.map(p => ({ ...p, campaignStatus: p.campaignStatus || 'pending' }));
    const search = data.lastSearch || 'Smart Search';
    const sub = document.getElementById('hdr-subtitle');
    if (sub) sub.textContent = `${C.profiles.length} candidates · from ${search}`;
    renderCandidates();
    updateStats();
    updateSummary();
    updateSafety();
    addLog(`Loaded ${C.profiles.length} profiles from PingIN extension`, 'ok');
  } catch (e) {
    addLog('Could not load profiles: ' + e.message, 'err');
  }
}

function setDefaultTemplate() {
  const ta = document.getElementById('msg-template');
  if (ta) { ta.value = TEMPLATES.job; updateCharCount(); }
}

// ── Render candidate list ──────────────────────────
const AV_COLORS = [
  ['rgba(0,119,181,.25)','#5BB5FF'],['rgba(124,58,237,.25)','#C084FC'],
  ['rgba(0,196,154,.2)','#00D4AA'], ['rgba(217,119,6,.2)','#FCD34D'],
  ['rgba(239,68,68,.2)','#FCA5A5'],['rgba(5,150,105,.2)','#6EE7B7'],
  ['rgba(255,112,85,.2)','#FF7055'],['rgba(99,130,200,.2)','#7A9ABE'],
];

function getIni(n){ return (n||'??').split(' ').map(w=>w[0]||'').join('').slice(0,2).toUpperCase(); }

function getStatusPill(s){
  const m={pending:['sp-pending','Pending'],sending:['sp-sending','Sending...'],sent:['sp-sent','Sent'],accepted:['sp-accepted','Accepted'],replied:['sp-replied','Replied'],failed:['sp-failed','Failed']};
  const[cls,lbl]=m[s]||m.pending;
  return `<span class="status-pill ${cls}">${lbl}</span>`;
}

function renderCandidates() {
  const list = document.getElementById('cand-list');
  const meta = document.getElementById('panel-meta');
  const filtered = C.filterMode === 'all' ? C.profiles : C.profiles.filter(p => p.campaignStatus === C.filterMode);
  if (meta) meta.textContent = `${filtered.length} of ${C.profiles.length} shown`;
  if (!C.profiles.length) {
    list.innerHTML = `<div class="empty"><div class="empty-icon">👥</div><div class="empty-title">No profiles loaded</div><div class="empty-sub">Collect profiles using Smart Search, Clone Search or JD Search in the PingIN extension, then click Smart Outreach.</div></div>`;
    return;
  }
  list.innerHTML = filtered.map((p,i) => {
    const [bg,tc] = AV_COLORS[i % AV_COLORS.length];
    const sub = [p.role,p.company,p.city].filter(Boolean).join(' · ');
    const rowCls = p.campaignStatus==='sending'?'is-running':p.campaignStatus==='accepted'?'is-accepted':p.campaignStatus==='replied'?'is-replied':'';
    const otwBadge = p.isOTW ? '<span style="font-size:8px;background:rgba(0,196,154,.12);color:#00C49A;border-radius:3px;padding:1px 4px;margin-left:5px">OTW</span>' : '';
    return `<div class="cand-row ${rowCls}" id="crow-${i}">
      <div class="cand-num">${i+1}</div>
      <div class="cand-av" style="background:${bg};color:${tc}">${getIni(p.name)}</div>
      <div class="cand-info">
        <div class="cand-name">${p.name||'Unknown'}${otwBadge}</div>
        <div class="cand-sub">${sub||'—'}</div>
      </div>
      ${getStatusPill(p.campaignStatus)}
    </div>`;
  }).join('');
}

// ── Stats ─────────────────────────────────────────
function updateStats() {
  const total    = C.profiles.length;
  const sent     = C.profiles.filter(p=>['sent','accepted','replied'].includes(p.campaignStatus)).length;
  const accepted = C.profiles.filter(p=>['accepted','replied'].includes(p.campaignStatus)).length;
  const replied  = C.profiles.filter(p=>p.campaignStatus==='replied').length;
  const pending  = C.profiles.filter(p=>['pending','sending'].includes(p.campaignStatus)).length;
  const set = (id,v) => { const el=document.getElementById(id); if(el) el.textContent=v; };
  set('st-total',total); set('st-sent',sent); set('st-accepted',accepted);
  set('st-replied',replied); set('st-pending',pending);
  set('s-sent',sent); set('s-accepted',accepted);
  set('s-replied',replied); set('s-pending',pending);
  const ar = sent>0 ? Math.round((accepted/sent)*100) : 0;
  const rr = accepted>0 ? Math.round((replied/accepted)*100) : 0;
  const setBar = (bid,vid,pct,col) => {
    const b=document.getElementById(bid); const v=document.getElementById(vid);
    if(b){b.style.width=pct+'%';} if(v){v.textContent=pct+'%';v.style.color=col;}
  };
  setBar('rate-accept-bar','rate-accept-val',ar,'var(--accent)');
  setBar('rate-reply-bar','rate-reply-val',rr,'#8B5CF6');
  if (total>0) {
    const pct=Math.round((sent/total)*100);
    set('prog-pct',pct+'%');
    const pf=document.getElementById('prog-fill'); if(pf) pf.style.width=pct+'%';
    set('prog-meta-left',`${sent} of ${total} actioned`);
    const rem=total-sent;
    const mins=rem>0?Math.ceil((rem*C.delay)/60):0;
    set('prog-meta-right',mins>0?`~${mins} min remaining`:'Complete');
  }
}

// ── Safety meters ─────────────────────────────────
function updateSafety() {
  const limits = {conn:25, msg:40, visit:50};
  const vals   = {conn:C.connToday, msg:C.msgToday, visit:C.visitToday};
  let maxPct = 0;
  for (const key of ['conn','msg','visit']) {
    const pct = Math.min((vals[key]/limits[key])*100, 100);
    maxPct = Math.max(maxPct, pct);
    const fill = document.getElementById('m-'+key);
    const val  = document.getElementById('mv-'+key);
    if (fill) { fill.style.width=pct+'%'; fill.className='m-fill '+(pct>=90?'m-danger':pct>=75?'m-warn':'m-safe'); }
    const col  = pct>=90?'var(--red)':pct>=75?'var(--amber)':'var(--accent)';
    if (val) { val.style.color=col; val.textContent=`${vals[key]}/${limits[key]}`; }
  }
  const pill = document.getElementById('safe-pill');
  if (!pill) return;
  if (maxPct>=90){ pill.className='safe-pill warn'; pill.textContent='⚠️ Limit Reached — Pausing'; }
  else if(maxPct>=75){ pill.className='safe-pill warn'; pill.textContent='⚠️ Monitor Activity'; }
  else { pill.className='safe-pill ok'; pill.textContent='✅ Account Safe'; }
}

function updateSummary() {
  const total = C.profiles.length;
  const days  = total>0 ? Math.ceil(total/C.dailyLimit) : 0;
  const set = (id,v) => { const el=document.getElementById(id); if(el) el.textContent=v; };
  set('sum-total', total);
  set('sum-limit', C.dailyLimit+' / day');
  set('sum-days',  days>0?(days===1?'Today':days+' days'):'—');
}

// ── Campaign controls ─────────────────────────────
async function launchCampaign() {
  if (!C.profiles.length) {
    alert('No profiles loaded. Use PingIN extension to collect profiles first.');
    return;
  }
  if (C.running) return;

  const template = document.getElementById('msg-template')?.value.trim() || '';
  if ((C.campaignType==='connect'||C.campaignType==='message') && !template) {
    alert('Please write a message in the Template tab before launching.');
    document.querySelectorAll('.rtab')[1]?.click();
    return;
  }

  C.template = template;
  C.yourName = document.getElementById('your-name')?.value.trim() || 'Recruiter';

  // ── Build personalised message using first profile as preview ──
  const previewMsg = buildMessage(C.profiles[0] || {});

  // ── Save profiles to extension storage so service worker can use them ──
  await chrome.storage.local.set({
    profiles: C.profiles.map(p => ({
      ...p,
      status: 'pending',
      campaignStatus: 'pending',
    })),
  });

  // ── Hand off to service worker — it handles the real LinkedIn actions ──
  try {
    const resp = await chrome.runtime.sendMessage({
      action: 'START_CAMPAIGN',
      count:  C.profiles.length,
      message: previewMsg,
      delay:  typeof C.delay === 'number' ? C.delay : 60,
      randomDelay: C.delay === 'random',
    });

    if (!resp?.ok) {
      alert('Could not start campaign: ' + (resp?.error || 'Unknown error'));
      return;
    }

    C.running = true;
    C.paused  = false;
    setStatus('running');

    const bl = document.getElementById('btn-launch');
    if (bl) bl.style.display = 'none';
    const pc = document.getElementById('prog-card');
    if (pc) pc.style.display = 'block';
    const cr = document.getElementById('ctrl-row');
    if (cr) cr.style.display = 'flex';

    addLog('Campaign started · ' + C.profiles.length + ' candidates · service worker active', 'ok');
    addLog('LinkedIn connection requests are being sent in background tabs', 'ok');

    // Start polling service worker for real-time updates
    startStatusPolling();

  } catch(e) {
    alert('Error starting campaign: ' + e.message);
  }
}

// ── Poll service worker every 3s for real status updates ──────────
let _pollInterval = null;

function startStatusPolling() {
  if (_pollInterval) clearInterval(_pollInterval);
  _pollInterval = setInterval(async () => {
    try {
      const resp = await chrome.runtime.sendMessage({ action: 'GET_STATUS' });
      if (!resp?.ok) return;

      const profiles  = resp.profiles || [];
      const campaign  = resp.campaign || {};

      // Sync local profile statuses from storage
      profiles.forEach((p, i) => {
        const local = C.profiles.find(lp => lp.profileUrl === p.profileUrl);
        if (local) {
          // Map extension status to campaign display status
          local.campaignStatus =
            p.status === 'sent'    ? 'sent'     :
            p.status === 'queued'  ? 'sending'  :
            p.status === 'failed'  ? 'failed'   : 'pending';
        }
      });

      // Update counters
      C.connToday  = resp.dailySent || 0;
      C.msgToday   = resp.dailySent || 0;

      renderCandidates();
      updateStats();
      updateSafety();

      // Check if campaign finished
      if (!campaign.running && C.running) {
        C.running = false;
        clearInterval(_pollInterval);
        setStatus('done');

        const bl = document.getElementById('btn-launch');
        if (bl) { bl.style.display='flex'; bl.disabled=true; bl.innerHTML='✓ Campaign Complete'; }
        const cr = document.getElementById('ctrl-row');
        if (cr) cr.style.display='none';

        const sent = profiles.filter(p=>p.status==='sent').length;
        const failed = profiles.filter(p=>p.status==='failed').length;
        addLog('Campaign complete · ' + sent + ' sent · ' + failed + ' failed', 'ok');
        addLog('Check LinkedIn Invitations > Sent to verify', 'ok');
      }

      // Update progress bar
      const total  = profiles.length;
      const done   = profiles.filter(p=>['sent','failed'].includes(p.status)).length;
      const pct    = total > 0 ? Math.round((done/total)*100) : 0;
      const pf = document.getElementById('prog-fill');
      const pp = document.getElementById('prog-pct');
      const pm = document.getElementById('prog-meta-left');
      const pr = document.getElementById('prog-meta-right');
      if (pf) pf.style.width = pct + '%';
      if (pp) pp.textContent = pct + '%';
      if (pm) pm.textContent = done + ' of ' + total + ' actioned';
      const remaining = total - done;
      const delay = typeof C.delay === 'number' ? C.delay : 60;
      if (pr) pr.textContent = remaining > 0 ? '~' + Math.ceil((remaining*delay)/60) + ' min remaining' : 'Complete';

    } catch(e) {
      // Service worker may be sleeping — normal
    }
  }, 3000);
}

async function pauseCampaign() {
  try {
    await chrome.runtime.sendMessage({ action: 'PAUSE_CAMPAIGN' });
    C.paused = true;
    setStatus('paused');
    const bp = document.getElementById('btn-pause');
    const br = document.getElementById('btn-resume');
    if (bp) bp.style.display='none';
    if (br) br.style.display='flex';
    addLog('Campaign paused — LinkedIn actions stopped', 'warn');
  } catch(e) { addLog('Pause error: ' + e.message, 'err'); }
}

async function resumeCampaign() {
  try {
    await chrome.runtime.sendMessage({ action: 'PAUSE_CAMPAIGN' }); // toggles pause
    C.paused = false;
    setStatus('running');
    const bp = document.getElementById('btn-pause');
    const br = document.getElementById('btn-resume');
    if (bp) bp.style.display='flex';
    if (br) br.style.display='none';
    addLog('Campaign resumed', 'ok');
  } catch(e) { addLog('Resume error: ' + e.message, 'err'); }
}

async function stopCampaign() {
  if (!confirm('Stop this campaign? Remaining candidates will not be contacted.')) return;
  try {
    await chrome.runtime.sendMessage({ action: 'STOP_CAMPAIGN' });
  } catch(e) {}
  C.running = false;
  C.paused  = false;
  if (_pollInterval) { clearInterval(_pollInterval); _pollInterval = null; }
  setStatus('idle');
  const bl = document.getElementById('btn-launch');
  if (bl) { bl.style.display='flex'; bl.disabled=false; bl.innerHTML='▶&nbsp; Start Outreach Campaign'; }
  const pc = document.getElementById('prog-card');
  if (pc) pc.style.display='none';
  const cr = document.getElementById('ctrl-row');
  if (cr) cr.style.display='none';
  addLog('Campaign stopped by user', 'warn');
  saveCampaignState();
}

async function openAndAction(profile, msg) {
  // Delegated to service worker — this function is no longer used
}

function buildMessage(p) {
  return (C.template||'')
    .replace(/{{first_name}}/g, (p.name||'').split(' ')[0]||'there')
    .replace(/{{company}}/g,    p.company||'your company')
    .replace(/{{role}}/g,       p.role||'this role')
    .replace(/{{location}}/g,   p.city||'your city')
    .replace(/{{your_name}}/g,  C.yourName||'Recruiter');
}

function updateCandidateRow(idx) {
  const p   = C.profiles[idx];
  const row = document.getElementById(`crow-${idx}`);
  if (!row) { renderCandidates(); return; }
  const oldPill = row.querySelector('.status-pill');
  if (oldPill) oldPill.outerHTML = getStatusPill(p.campaignStatus);
  row.className = 'cand-row' + (p.campaignStatus==='sending'?' is-running':p.campaignStatus==='accepted'?' is-accepted':p.campaignStatus==='replied'?' is-replied':'');
}

async function saveCampaignState() {
  try { await chrome.storage.local.set({ campaignProfiles: C.profiles, campaignLogs: C.logs.slice(-50) }); } catch(e) {}
}

// ── UI helpers ─────────────────────────────────────
function setStatus(state) {
  const badge = document.getElementById('status-badge');
  const dot   = document.getElementById('status-dot');
  const txt   = document.getElementById('status-txt');
  if (!badge||!dot||!txt) return;
  const map = { idle:['sb-idle','dot-idle','Ready'], running:['sb-running','dot-run','Running'], paused:['sb-paused','dot-pause','Paused'], done:['sb-done','dot-done','Complete'] };
  const [bc,dc,label] = map[state]||map.idle;
  badge.className='status-badge '+bc;
  dot.className='status-dot '+dc;
  txt.textContent=label;
}

function updateCharCount() {
  const ta = document.getElementById('msg-template');
  const el = document.getElementById('char-count');
  if (!ta||!el) return;
  const len = ta.value.length;
  el.textContent = len+' / 300';
  el.style.color = len>280?'var(--amber)':'var(--tm)';
}

function insertVar(v) {
  const ta = document.getElementById('msg-template');
  if (!ta) return;
  const s = ta.selectionStart, e = ta.selectionEnd;
  ta.value = ta.value.slice(0,s)+v+ta.value.slice(e);
  ta.selectionStart = ta.selectionEnd = s+v.length;
  ta.focus();
  updateCharCount();
}

function addLog(msg, type) {
  const now = new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
  C.logs.unshift({time:now,msg,type:type||''});
  const list = document.getElementById('log-list');
  if (!list) return;
  const el = document.createElement('div');
  el.className = 'log-item'+(type==='ok'?' log-ok':type==='warn'?' log-warn':type==='err'?' log-err':'');
  el.innerHTML = `<span class="log-time">${now}</span><span>${msg}</span>`;
  list.insertBefore(el, list.firstChild);
  while (list.children.length>50) list.removeChild(list.lastChild);
}

function sleep(ms) { return new Promise(r=>setTimeout(r,ms)); }
