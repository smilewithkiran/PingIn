'use strict';
// PingIN v2.0 — India's Talent Search Engine

const TRIAL_DAYS   = 5;
const TRIAL_MSGS   = 5; // 5 messages/day for free trial

// ─────────────────────────────────────────────
//  State
// ─────────────────────────────────────────────
const S = {
  plan:'free', trialDaysLeft:5, trialMsgsLeft:5,
  planExpiry:null, dailyLimit:50, dailyMsgsLeft:50,
  profiles:[], sent:0, failed:0,
  lastSearchParams:{}, currentPage:1, totalPages:1,
  log:[], savedSearches:[], history:[],
  currentFilter: 'all',
  settings:{ randomDelay:true, bizHours:false, skipConnected:true },
};

// Avatar colour palette
const AV = [
  ['rgba(0,119,181,.25)','#5BB5FF'],
  ['rgba(124,58,237,.25)','#C084FC'],
  ['rgba(0,196,154,.2)', '#00C49A'],
  ['rgba(217,119,6,.2)', '#FCD34D'],
  ['rgba(219,39,119,.2)','#F9A8D4'],
  ['rgba(5,150,105,.2)', '#6EE7B7'],
  ['rgba(239,68,68,.2)', '#FCA5A5'],
  ['rgba(59,130,246,.2)','#93C5FD'],
];



const COMPANIES = [

  // ══ IT SERVICES / SOFTWARE ══════════════════════════════════
  "TCS","Infosys","Wipro","HCL Technologies","Tech Mahindra","LTIMindtree",
  "Mphasis","Hexaware","Coforge","Persistent Systems","Cyient","NIIT Technologies",
  "Zensar Technologies","Sonata Software","KPIT Technologies","Sasken Technologies",
  "Birlasoft","L&T Technology Services","Mastech Digital","3i Infotech",
  "Ramp Systems","Tata Elxsi","HARMAN India","Tata Technologies",
  "Mahindra Tech","Quess Corp","TeamLease","Randstad India","Adecco India",

  // ══ PRODUCT / INTERNET / UNICORNS ═══════════════════════════
  "Flipkart","Amazon India","Swiggy","Zomato","Ola","Uber India","Paytm",
  "PhonePe","Razorpay","CRED","Meesho","Nykaa","Groww","Zerodha","Angel One",
  "Freshworks","Zoho","BrowserStack","Postman","Chargebee","Hasura","Druva",
  "Icertis","Mindtickle","Whatfix","Highradius","MoEngage","CleverTap",
  "Locus","Darwinbox","Keka","greytHR","Zimyo","Springworks","HROne",
  "Urban Company","Licious","BigBasket","Dunzo","Rapido","Blinkit","Zepto",
  "OYO","MakeMyTrip","Yatra","Goibibo","ixigo","EaseMyTrip","Airbnb India",
  "PolicyBazaar","Acko","Digit Insurance","RenewBuy","Turtlemint","Coverfox",
  "Dream11","MPL","Games24x7","Gameskraft","WinZO","Nazara Technologies",
  "ShareChat","Moj","Josh","Dailyhunt","InShorts","Newslaundry",
  "Ninjacart","DeHaat","AgroStar","CropIn","FarMart","Waycool","Jai Kisan",
  "Practo","1mg","PharmEasy","Netmeds","Mfine","Portea","Pristyn Care",
  "Healthifyme","Cult.fit","Truemeds","Medikabazaar","Lybrate",
  "upGrad","Unacademy","Byju's","Simplilearn","Great Learning","Vedantu",
  "Leverage Edu","Sunstone","Classplus","Teachmint","ConveGenius",
  "Cars24","CarDekho","Spinny","Droom","OLX India","Quikr","magicbricks",
  "Housing.com","NoBroker","PropTiger","Square Yards","99acres","CommonFloor",
  "Ather Energy","Ola Electric","Hero Electric","Simple Energy","Bounce Infinity",
  "Porter","Shiprocket","Delhivery","Shadowfax","Rivigo","BlackBuck","Wahter",
  "Cashfree","PayU","CCAvenue","BillDesk","Juspay","Setu","Perfios","Finbox",
  "Jupiter","Fi Money","Slice","Uni Cards","OneCard","Smallcase","Kuvera",
  "INDmoney","Fisdom","Wealthdesk","Cube Wealth","Scripbox","Goalwise",
  "Open","RazorpayX","Zaggle","EnKash","Happay","Volopay","Expense Karo",
  "Lendingkart","Indifi","OfBusiness","Moglix","Udaan","Jumbotail","Zetwerk",
  "Stanza Living","Awfis","91springboard","WeWork India","Smartworks","IndiQube",
  "Mensa Brands","GlobalBees","Upscalio","10Club","Goat Brand Labs",
  "boAt","Noise","Boat Lifestyle","Fire-Boltt","Imagine Marketing","Zebronics",
  "Mamaearth","Plum","WOW Skin Science","Minimalist","Dot & Key","Sugar Cosmetics",
  "Lenskart","Fastrack","Titan Company","Manyavar","Fabindia","FabAlley",
  "Pepperfry","Urban Ladder","IKEA India","HomeLane","Livspace","Furlenco",
  "Dunzo Daily","Swiggy Instamart","BB Now","Zepto","Blinkit","Milkbasket",

  // ══ BANKING / NBFC / FINTECH ════════════════════════════════
  "HDFC Bank","ICICI Bank","SBI","Axis Bank","Kotak Mahindra Bank",
  "Yes Bank","IndusInd Bank","Punjab National Bank","Bank of Baroda",
  "Canara Bank","Union Bank","Federal Bank","RBL Bank","South Indian Bank",
  "IDFC First Bank","Bandhan Bank","AU Small Finance Bank","Ujjivan SFB",
  "Suryoday SFB","Jana SFB","Equitas SFB","ESAF SFB","FINCARE SFB",
  "HDFC Life","SBI Life","ICICI Prudential","Max Life","Bajaj Allianz",
  "LIC","Birla Sun Life","Tata AIA","Reliance Nippon Life","PNB MetLife",
  "HDFC AMC","SBI Mutual Fund","ICICI Prudential AMC","Nippon India AMC",
  "Mirae Asset","Axis Mutual Fund","UTI AMC","Aditya Birla Sun Life AMC",
  "Bajaj Finance","Bajaj Finserv","Muthoot Finance","Manappuram Finance",
  "Shriram Finance","Cholamandalam","HDB Financial","Aditya Birla Finance",
  "IIFL Finance","Mahindra Finance","L&T Finance","Tata Capital","Piramal Finance",
  "Home First Finance","Aavas Financiers","Aptus Housing","Can Fin Homes",
  "Paytm Payments Bank","Airtel Payments Bank","Jio Payments Bank",
  "NSDL","CDSL","NSE","BSE","MCX","SEBI",

  // ══ CONSULTING / BIG 4 / MNC ════════════════════════════════
  "Deloitte","PwC","EY","KPMG","McKinsey","BCG","Bain & Company",
  "Accenture","Capgemini","CGI","Cognizant","IBM India","Oracle India",
  "SAP India","Microsoft India","Google India","Amazon Web Services",
  "Salesforce India","Adobe India","Cisco India","Intel India","Qualcomm India",
  "Gartner India","Forrester","IDC India","Dun & Bradstreet","CRISIL",
  "Grant Thornton","RSM India","BDO India","MSKA & Associates",
  "Alvarez & Marsal","Kroll","Ankura","AlixPartners",

  // ══ GCC / GLOBAL CAPABILITY CENTRES ════════════════════════
  "Goldman Sachs","JPMorgan","Citibank","Deutsche Bank","Barclays","HSBC",
  "Morgan Stanley","Bank of America","Wells Fargo","Credit Suisse","UBS",
  "BNY Mellon","State Street","Northern Trust","Fidelity India","Vanguard India",
  "Shell India","BP India","ExxonMobil","Chevron","Honeywell India",
  "GE India","Siemens India","Bosch India","ABB India","Schneider Electric",
  "3M India","Caterpillar India","Cummins India","Rockwell Automation",
  "UnitedHealth","Optum","Aetna","Cigna","Anthem","Humana","Elevance",
  "AstraZeneca India","Novartis India","Pfizer India","Abbott India",
  "Johnson & Johnson","Sanofi India","GSK India","Merck India","Roche India",
  "Philips India","GE Healthcare","Siemens Healthineers","Medtronic",
  "Becton Dickinson","Baxter India","Stryker India","Zimmer Biomet",
  "Target India","Walmart India","Flipkart (Walmart)","Gap India","Macy's India",
  "American Express India","Mastercard India","Visa India","PayPal India",
  "Apple India","Meta India","Netflix India","Spotify India","Twitter India",
  "Uber India","Airbnb India","booking.com India","Agoda India",
  "Fiserv India","FIS India","SS&C India","Broadridge India","Finastra",
  "Refinitiv","Bloomberg India","S&P Global India","Moody's India","MSCI India",
  "Conduent","Concentrix","Teleperformance","WNS","EXL Service","Genpact",
  "iGate","Syntel","Mphasis","NIIT Technologies","Hexaware","Firstsource",
  "Sutherland","Hinduja Global","Aegis BPO","iEnergizer","Startek","SITEL",

  // ══ MANUFACTURING / AUTO / CORE INDUSTRIES ═════════════════
  "Tata Motors","Mahindra & Mahindra","Maruti Suzuki","Hero MotoCorp",
  "Bajaj Auto","TVS Motor","Ashok Leyland","Eicher Motors","Force Motors",
  "Honda India","Toyota India","Hyundai India","Kia India","Skoda India",
  "MG Motor","BMW India","Mercedes India","Audi India","Volkswagen India",
  "Tata Steel","JSW Steel","SAIL","NMDC","Vedanta","Hindalco","Nalco",
  "Larsen & Toubro","BHEL","HAL","DRDO","ISRO","ONGC","Indian Oil",
  "BPCL","HPCL","Reliance Industries","Essar Oil","Castrol India",
  "Gujarat Gas","Mahanagar Gas","IGL","GAIL","Petronet LNG","Torrent Gas",
  "Tata Power","Adani Power","JSW Energy","NTPC","Power Grid","CESC",
  "Thermax","Crompton Greaves","Havells","Finolex Cables","Polycab",
  "Kirloskar","Cummins India","Grindwell Norton","Carborundum Universal",
  "UltraTech Cement","ACC","Ambuja","Shree Cement","Dalmia Bharat",
  "Asian Paints","Berger Paints","Kansai Nerolac","Akzo Nobel India",
  "Pidilite Industries","Astral Pipes","Supreme Industries","Nilkamal",

  // ══ TELECOM / MEDIA / ENTERTAINMENT ════════════════════════
  "Jio","Airtel","Vodafone Idea","BSNL","MTNL","Tata Communications",
  "Tata Play","Dish TV","Hathway","Den Networks",
  "Zee Entertainment","Sony India","Star India","Times of India","HT Media",
  "NDTV","ABP News","TV18","Network18","India Today","News18",
  "Sony Music India","T-Series","Saregama","Tips Music",
  "PVR Inox","Cinepolis","INOX Leisure","Carnival Cinemas",
  "Hotstar","JioCinema","SonyLIV","Zee5","MX Player","Voot","ALTBalaji",
  "Spotify India","Gaana","JioSaavn","Wynk Music","Amazon Music India",

  // ══ RETAIL / E-COMMERCE / FMCG ══════════════════════════════
  "Reliance Retail","DMart","Tata Retail","Future Group","Shoppers Stop",
  "Hindustan Unilever","P&G India","Nestle India","ITC","Dabur","Godrej Consumer",
  "Marico","Emami","Colgate","Britannia","Parle","Haldirams","Amul",
  "Mother Dairy","Patanjali","Tata Consumer Products","MDH","Everest","Catch",
  "Arvind Fashions","Raymond","Madura Fashion","ABFRL","Vedant Fashions",
  "Titan","Tanishq","Kalyan Jewellers","Malabar Gold","PC Jeweller",
  "Walmart India","Reliance Fresh","More Supermarket","Spencer's Retail",
  "Decathlon India","Skechers India","Nike India","Adidas India","Puma India",
  "Myntra","Ajio","Snapdeal","Tata Cliq","JioMart","Paytm Mall",

  // ══ PHARMA / HEALTHCARE / LIFE SCIENCES ═════════════════════
  "Sun Pharma","Dr Reddy's","Cipla","Lupin","Aurobindo Pharma","Cadila Healthcare",
  "Torrent Pharma","Alkem Laboratories","Ipca Laboratories","Natco Pharma",
  "Biocon","Serum Institute","Bharat Biotech","Zydus Lifesciences",
  "Strides Pharma","Gland Pharma","Granules India","Jubilant Pharmova",
  "Metropolis Healthcare","Dr Lal PathLabs","SRL Diagnostics","Thyrocare",
  "Fortis Healthcare","Apollo Hospitals","Max Healthcare","Narayana Health",
  "Manipal Hospitals","Aster DM Healthcare","Columbia Asia","Cloudnine",
  "Medanta","Wockhardt","Shalby Hospitals","NH Health","Rainbow Hospitals",
  "Agilus Diagnostics","Neuberg Diagnostics","Healthspring","Medica Synergie",

  // ══ EDUCATION / EDTECH ══════════════════════════════════════
  "Byju's","Unacademy","upGrad","Simplilearn","Great Learning","Vedantu",
  "Leverage Edu","Sunstone","Classplus","Teachmint","ConveGenius","Doubtnut",
  "Toppr","WhiteHat Jr","Coding Ninjas","Newton School","Scaler","iNeuron",
  "Aptech","NIIT","Jaro Education","Manipal Global","Amity Online",
  "Times Pro","Emeritus","Coursera India","Udemy India","EduBridge",

  // ══ REAL ESTATE / PROPTECH ══════════════════════════════════
  "DLF","Godrej Properties","Lodha Group","Prestige Estates","Sobha Realty",
  "Brigade Group","Embassy Group","Phoenix Mills","Oberoi Realty","Kolte Patil",
  "Mahindra Lifespaces","Puravankara","Shriram Properties","NBCC","L&T Realty",
  "NoBroker","Housing.com","PropTiger","Square Yards","magicbricks","99acres",
  "Anarock","CBRE India","JLL India","Savills India","Knight Frank India",

  // ══ LOGISTICS / SUPPLY CHAIN ════════════════════════════════
  "Delhivery","Blue Dart","DTDC","Ecom Express","XpressBees","Shadowfax",
  "Rivigo","BlackBuck","Porter","Shiprocket","ShipBob India","Pickrr",
  "Maersk India","DHL India","FedEx India","UPS India","TNT India",
  "DB Schenker India","Kuehne + Nagel India","Agility India","Geodis India",
  "GATI","Safexpress","TCI Express","Redington India","Ingram Micro India",
  "Mahindra Logistics","TVS Supply Chain","Allcargo Logistics","Blue Dart",

  // ══ FOOD & BEVERAGE / QSR ═══════════════════════════════════
  "McDonald's India","KFC India","Pizza Hut India","Domino's India",
  "Burger King India","Subway India","Starbucks India","Cafe Coffee Day",
  "Barbeque Nation","Jubilant FoodWorks","Devyani International",
  "Westlife Foodworld","Sapphire Foods","Restaurant Brands Asia",
  "Zomato","Swiggy","Rebel Foods","Freshmenu","EatFit","Box8","Faasos",

  // ══ HOSPITALITY / TRAVEL ════════════════════════════════════
  "Taj Hotels (IHCL)","The Leela","Hyatt India","Marriott India","Hilton India",
  "ITC Hotels","Oberoi Hotels","Radisson India","Lemon Tree Hotels",
  "OYO","FabHotels","Treebo","Zostel","Vista Rooms","WelcomHeritage",
  "MakeMyTrip","Yatra","Goibibo","ixigo","EaseMyTrip","IRCTC","Cleartrip",
  "Thomas Cook India","Cox & Kings","SOTC Travel","Kesari Tours",

  // ══ AGRICULTURE / AGRITECH ══════════════════════════════════
  "Ninjacart","DeHaat","AgroStar","CropIn","FarMart","Waycool","Jai Kisan",
  "Bijak","WayCool","Agrizy","Samunnati","Arya Collateral","Otipy",
  "ITC Agribusiness","Mahindra Agri","Bayer India","Syngenta India",
  "PI Industries","UPL","Coromandel International","Chambal Fertilisers",
  "National Fertilizers","Rashtriya Chemicals","Gujarat Narmada Valley",

  // ══ ELECTRIC VEHICLES / CLEANTECH ══════════════════════════
  "Ather Energy","Ola Electric","Hero Electric","Simple Energy","Revolt Motors",
  "Bounce Infinity","Okinawa","Ampere Vehicles","Greaves Electric",
  "Tata Motors EV","MG Motor India","Hyundai India EV",
  "Exide Industries","Amara Raja Batteries","Luminous Power","Okaya Power",
  "Waaree Energies","Adani Green","Greenko","ReNew Power","Azure Power",
  "Fourth Partner Energy","Cleantech Solar","CleanMax Solar","Engie India",

  // ══ CYBERSECURITY / SAAS / DEEPTECH ════════════════════════
  "Quick Heal","Seqrite","Palo Alto India","Fortinet India","CrowdStrike India",
  "Trellix","Sophos India","Kaspersky India","McAfee India","Trend Micro India",
  "Darktrace India","SentinelOne India","Check Point India","Qualys India",
  "Sprinklr","Freshdesk","Zendesk India","ServiceNow India","Workday India",
  "Informatica India","MuleSoft India","Boomi India","Talend India",
  "UiPath India","Automation Anywhere India","Blue Prism","WorkFusion",
  "ThoughtSpot","DataStax","Cloudera India","Databricks India","Snowflake India",
  "Fractal Analytics","Mu Sigma","LatentView","Tiger Analytics","Innominds",
  "Sigmoid","TheMathCompany","Bridgei2i","Crayon Data","Subex",

  // ══ AEROSPACE / DEFENCE ═════════════════════════════════════
  "HAL","DRDO","ISRO","BEL","BDL","BEML","MIDHANI","Ordnance Factory",
  "Tata Advanced Systems","Mahindra Defence","L&T Defence","Boeing India",
  "Airbus India","Safran India","Thales India","BAE Systems India",
  "Collins Aerospace India","Honeywell Aerospace India","GE Aviation India",

  // ══ MEDIA / PUBLISHING / ADVERTISING ═══════════════════════
  "WPP India","Publicis India","Omnicom India","IPG India","Dentsu India",
  "Ogilvy India","JWT India","Leo Burnett","Grey India","McCann India",
  "Madison World","Interactive Avenues","Isobar","Schbang","Social Beat",
  "iProspect","Performics","Mirum India","Digital Vidya","WATConsult",
  "GroupM India","Mindshare","Wavemaker","MediaCom","Essence","Kinetic",
  "Rediffusion","Lowe Lintas","BBDO India","DDB Mudra","Contract India",

  // ══ HR TECH / RECRUITMENT / STAFFING ═══════════════════════
  "Naukri.com","LinkedIn India","Indeed India","Monster India","Apna",
  "Hirect","iimjobs","Hirist","Internshala","Firstnaukri","Foundit",
  "TeamLease","Quess Corp","Manpower India","Kelly Services India",
  "Randstad India","Adecco India","Capita India","Sapient Staffing",
  "PeopleStrong","Aon India","Mercer India","Willis Towers Watson India",
  "Korn Ferry India","Spencer Stuart India","Egon Zehnder India","Heidrick",
  "Michael Page India","Randstad India","Hudson India","ABC Consultants",

  // ══ LEGAL TECH / COMPLIANCE ═════════════════════════════════
  "LegalKart","Vakil Search","MyAdvo","NoBroker Legal","LawTrade",
  "Legistify","SeedLegals India","Munim","Razorpay Compliance","Signzy",
  "IDfy","Digilocker","Aadhaar Bridge","Bureau","AuthBridge",
];







// ═══════════════════════════════════════════════════════════════
//  SCREEN NAVIGATION
// ═══════════════════════════════════════════════════════════════
function showScreen(screenId, animation='slide-in') {
  document.querySelectorAll('.screen').forEach(s => {
    s.classList.remove('active','slide-in','slide-back','slide-up');
  });
  const target = document.getElementById(screenId);
  if (!target) return;
  target.classList.add('active', animation);
}

function initNavigation() {
  // Home → search screens
  document.querySelectorAll('.search-card[data-screen]').forEach(card => {
    card.addEventListener('click', () => {
      if(card.dataset.screen === 'screen-salary'){return;} // Coming Soon
      showScreen(card.dataset.screen, 'slide-in');
    });
  });

  // Back buttons
  document.querySelectorAll('.back-btn[data-back]').forEach(btn => {
    btn.addEventListener('click', () => {
      showScreen(btn.dataset.back, 'slide-back');
    });
  });

  // Settings button in header
  document.getElementById('btn-go-settings')?.addEventListener('click', () => {
    showScreen('screen-settings', 'slide-in');
  });

  // Upgrade button
  document.getElementById('plan-bar-upgrade')?.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://pingin.in/pricing.html', active: true });
  });

  // Status bar profile buttons → go to profiles screen
  ['sb-profiles-btn','sb-view-btn','smart-view-btn','clone-view-btn',
   'jd-view-btn','pred-view-btn'].forEach(id => {
    document.getElementById(id)?.addEventListener('click', () => {
      showScreen('screen-profiles', 'slide-up');
    });
  });

  // Status bar profile count clicks
  document.getElementById('sb-profiles-btn')?.addEventListener('click', () => {
    if (S.profiles.length > 0) showScreen('screen-profiles','slide-up');
  });
}

function updateAllCounts() {
  const count = S.profiles.length;
  const hot = S.profiles.filter(p => {
    const sc = scoreProfile(p, S.lastSearchParams);
    return sc >= 75;
  }).length;
  
  ['sb-count','smart-sb-count','clone-sb-count','jd-sb-count','pred-sb-count'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = count;
  });
  document.getElementById('stat-profiles') && (document.getElementById('stat-profiles').textContent = count);
  document.getElementById('stat-hot') && (document.getElementById('stat-hot').textContent = hot);
  updateTopProfiles();
}


// ── Top Profiles Summary — shown when ≥3 profiles ────────────
function updateTopProfiles() {
  const banner = document.getElementById('top-profiles-banner');
  const list   = document.getElementById('top-profiles-list');
  if (!banner || !list) return;

  const total = S.profiles.length;

  // Always update count in header
  const hdr = document.getElementById('profiles-count');
  if (hdr) hdr.textContent = total + ' profile' + (total!==1?'s':'') + (S.lastSearchParams?.keywords ? ' · "'+S.lastSearchParams.keywords+'"' : '');

  // Only show top banner if ≥3 profiles
  if (total < 3 || !S.lastSearchParams) {
    banner.style.display = 'none';
    return;
  }

  // Score and sort all profiles
  const scored = S.profiles
    .map(p => ({ ...p, _score: scoreProfile(p, S.lastSearchParams) }))
    .sort((a,b) => b._score - a._score)
    .slice(0, 3); // top 3

  const SCORE_COLORS = [
    { min:90, color:'#FF7055', label:'🔥 Hot' },
    { min:75, color:'#5BB5FF', label:'⭐ Strong' },
    { min:60, color:'#00C49A', label:'✅ Good' },
    { min:0,  color:'#D97706', label:'👍 Fair' },
  ];

  const getScoreStyle = (sc) => SCORE_COLORS.find(c => sc >= c.min) || SCORE_COLORS[3];

  list.innerHTML = scored.map((p, i) => {
    const sc    = p._score || 0;
    const style = getScoreStyle(sc);
    const name  = p.name || 'Unknown';
    const role  = p.role || p.company || '—';
    const initials = name.split(' ').map(n=>n[0]||'').join('').slice(0,2).toUpperCase();
    return `<div class="top-profile-card" data-url="${p.profileUrl||''}" style="display:flex;align-items:center;gap:9px;padding:6px 8px;background:rgba(255,255,255,.03);border-radius:7px;cursor:pointer;">
      <div style="width:28px;height:28px;border-radius:50%;background:rgba(0,119,181,.25);color:#5BB5FF;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;flex-shrink:0">${initials}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:11px;font-weight:600;color:var(--tp);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${name}${p.isOTW?'<span style="font-size:9px;background:rgba(0,196,154,.15);color:#00C49A;border-radius:3px;padding:1px 4px;margin-left:4px">OTW</span>':''}</div>
        <div style="font-size:10px;color:var(--ts);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${role}</div>
      </div>
      <div style="font-size:11px;font-weight:800;color:${style.color};flex-shrink:0">${sc}</div>
    </div>`;
  }).join('');

  banner.style.display = 'block';
}


function delay(ms){return new Promise(r=>setTimeout(r,ms));}


function waitTabLoad(tabId, cb) {
  let fired = false;
  const fn = (id, info) => {
    if (id === tabId && info.status === 'complete') {
      chrome.tabs.onUpdated.removeListener(fn);
      if (!fired) { fired=true; cb(); }
    }
  };
  chrome.tabs.onUpdated.addListener(fn);
  // Timeout fallback after 12 seconds
  setTimeout(() => {
    chrome.tabs.onUpdated.removeListener(fn);
    if (!fired) { fired=true; cb(); }
  }, 12000);
}


function addLog(msg){const t=new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'});S.log.unshift({t,msg});if(S.log.length>50)S.log.pop();chrome.storage.local.set({log:S.log});renderLog();}


async function showStatus(msg,type='success'){
  const icons={success:'✓',warning:'⚠',error:'✗',info:'ℹ'};
  const box=document.getElementById('status-box');
  box.className='info-box '+type;
  box.innerHTML=`<span style="font-weight:700">${icons[type]||''}</span> ${msg}`;
  box.style.display='flex';
}


async function saveToHistory(params){
  S.history=S.history.filter(h=>h.keywords!==params.keywords);
  S.history.unshift(params);
  if(S.history.length>15)S.history.pop();
  await chrome.storage.local.set({searchHistory:S.history});
}


function updateProfileTypeState(){
  const pt = document.getElementById('s-profile-type');
  if (pt) pt.disabled = false;
  const ptHint = document.getElementById('pt-hint');
  if (ptHint) ptHint.style.display = 'none';
}


function resetSearchBtn(){
  const btn=document.getElementById('btn-search');
  btn.disabled=false;
  btn.innerHTML='<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="M20 20l-3-3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg> Search';
}


function extractLinkedInUsername(url) {
  url = url.trim();
  // Handle various formats:
  // linkedin.com/in/username
  // https://www.linkedin.com/in/username/
  // /in/username
  const match = url.match(/(?:linkedin\.com\/in\/|^\/in\/)([a-zA-Z0-9\-_%]+)/i);
  return match ? match[1] : null;
}


function buildCloneTags(profile, location, isTopSchool, experience) {
  const tags = [];
  const headline = profile.headline || '';
  const titlePart = headline.split(/\s*[|@·]\s*|\s+at\s+/i)[0].trim();
  if (titlePart) tags.push({ label: '💼 ' + titlePart, type: 'blue' });
  if (location)  tags.push({ label: '📍 ' + location,  type: 'green' });
  const EXP_LABELS = { '1':'0–1 yr', '2':'1–3 yrs', '3':'3–5 yrs', '4':'5–10 yrs', '5':'10+ yrs' };
  if (experience) tags.push({ label: '⏱ ' + (EXP_LABELS[experience]||''), type: 'amber' });
  if (isTopSchool && profile.school) tags.push({ label: '🎓 ' + profile.school, type: 'blue' });
  const skills = (profile.skills||[]).slice(0,3);
  skills.forEach(s => tags.push({ label: s, type: 'green' }));
  return tags;
}


function buildCloneSearchFromProfile(profile) {
  const cloneSearch = {};

  // Keywords — use job title from headline (clean extraction)
  const headline = profile.headline || '';

  // Extract JUST the job title — remove company info
  // Headlines like: "Senior Data Scientist at Google | IIT Bombay"
  // We want: "Senior Data Scientist"
  let titlePart = headline
    .split(/\s*[|@·]\s*|\s+at\s+/i)[0]  // split on separators only, not 'in'
    .replace(/^(i am|currently|working as|looking for)/i, '')  // remove prefixes
    .trim();

  // Remove seniority fluff that's too broad
  if (titlePart.length > 50) titlePart = titlePart.substring(0, 50);

  let keywords = titlePart ? `"${titlePart}"` : '';

  // Company
  const company = profile.company || '';

  // Location mapping
  const LOC_MAP = {
    'bengaluru': 'Bengaluru', 'bangalore': 'Bengaluru',
    'mumbai': 'Mumbai', 'bombay': 'Mumbai',
    'hyderabad': 'Hyderabad', 'secunderabad': 'Hyderabad',
    'delhi': 'Delhi NCR', 'new delhi': 'Delhi NCR', 'gurgaon': 'Gurgaon',
    'noida': 'Noida', 'pune': 'Pune', 'chennai': 'Chennai',
    'kolkata': 'Kolkata', 'ahmedabad': 'Ahmedabad', 'jaipur': 'Jaipur',
  };
  let location = '';
  const locLower = (profile.location || '').toLowerCase();
  for (const [key, val] of Object.entries(LOC_MAP)) {
    if (locLower.includes(key)) { location = val; break; }
  }

  // School/college tier
  const school = (profile.school || '').toLowerCase();
  const TOP_SCHOOLS = ['iit', 'iim', 'iiit', 'bits', 'nit', 'xlri', 'isb', 'fms', 'sp jain', 'mdi'];
  const isTopSchool = TOP_SCHOOLS.some(s => school.includes(s));

  // Experience level guess
  let experience = '';
  const expCount = profile.experienceCount || 0;
  if (expCount >= 4) experience = '4'; // 5-10 yrs
  else if (expCount >= 3) experience = '3'; // 3-5 yrs
  else if (expCount >= 2) experience = '2'; // 1-3 yrs
  else if (expCount >= 1) experience = '1'; // 0-1 yr

  // Build skills keywords to add
  const skills = (profile.skills || []).slice(0,3);
  if (skills.length > 0 && keywords) {
    keywords += ' AND (' + skills.map(s => `"${s}"`).join(' OR ') + ')';
  }

  return {
    keywords,
    company: '',      // don't lock to same company — find similar people elsewhere
    location,
    experience,
    school: isTopSchool ? profile.school : '',
    isTopSchool,
    profileData: profile,
    tags: buildCloneTags(profile, location, isTopSchool, experience),
  };
}


function scoreProfile(p, searchParams) {
  let score = 0;

  // ── 1. Role Title Match (35 pts) — PRIMARY scoring factor ──
  // This is what we CAN check from LinkedIn search results
  const role    = (p.role    || '').toLowerCase();
  const company = (p.company || '').toLowerCase();
  const name    = (p.name    || '').toLowerCase();
  const kw      = ((searchParams?.keywords || '') + ' ' + (searchParams?.jobTitle || '')).toLowerCase();

  if (kw.trim()) {
    // Extract meaningful words (3+ chars, no boolean operators)
    const kwWords = kw
      .replace(/["()]/g, '')
      .replace(/(and|or|not)/gi, '')
      .split(/\s+/)
      .filter(w => w.length >= 3);

    // Check how many keywords appear in role title
    const roleMatches = kwWords.filter(w => role.includes(w));
    const coMatches   = kwWords.filter(w => company.includes(w));

    if (roleMatches.length >= 3)      score += 35;
    else if (roleMatches.length >= 2) score += 28;
    else if (roleMatches.length >= 1) score += 18;
    else if (coMatches.length >= 1)   score += 8;
    else                              score += 5; // profile shown but no match
  } else {
    score += 20; // no keyword = neutral bonus
  }

  // ── 2. Open to Work (25 pts) ─────────────────────────────
  if (p.isOTW) score += 25;

  // ── 3. Connection Degree (20 pts) ────────────────────────
  // LinkedIn shows: "1st", "2nd", "3rd+" in degree field
  const deg = (p.degree || '').trim();
  if      (deg === '1st' || deg.startsWith('1'))  score += 20;
  else if (deg === '2nd' || deg.startsWith('2'))  score += 13;
  else if (deg === '3rd' || deg.startsWith('3'))  score += 6;
  else if (deg)                                    score += 3;

  // ── 4. Company Tier (15 pts) ──────────────────────────────
  // Use partial matching — company field may contain extra text
  const TIER1 = ['google','microsoft','amazon','meta','apple','netflix','stripe','uber','goldman','jpmorgan','mckinsey','bcg','atlassian'];
  const TIER2 = ['flipkart','razorpay','zerodha','swiggy','zomato','cred','meesho','freshworks','zoho','phonepe','paytm','ola','byjus','unacademy','browserstack'];
  const TIER3 = ['tcs','infosys','wipro','hcl','capgemini','accenture','cognizant','ibm','tech mahindra','l&t','mindtree'];
  if      (TIER1.some(t => company.includes(t))) score += 15;
  else if (TIER2.some(t => company.includes(t))) score += 11;
  else if (TIER3.some(t => company.includes(t))) score += 6;
  else if (company.length > 2)                   score += 3;

  // ── 5. Location Match (5 pts bonus) ──────────────────────
  const loc    = (p.city || p.location || '').toLowerCase();
  const wantLoc = (searchParams?.location || '').toLowerCase();
  if (wantLoc && loc && (loc.includes(wantLoc) || wantLoc.includes(loc.split(',')[0]))) {
    score += 5;
  }

  return Math.min(100, Math.max(5, score));
}


function getScoreClass(score) {
  if (score >= 90) return 'score-hot';
  if (score >= 75) return 'score-strong';
  if (score >= 60) return 'score-good';
  if (score >= 40) return 'score-ok';
  return 'score-weak';
}


function getScoreLabel(score) {
  if (score >= 90) return '🔥 ' + score;
  if (score >= 75) return '⭐ ' + score;
  if (score >= 60) return '✅ ' + score;
  if (score >= 40) return '👍 ' + score;
  return score.toString();
}


function buildSearchUrl(keywords,location,degree,experience,profileType,college,company,page=1,salaryRange='',diversityFilters=[]){
  const GEO={
    'Hyderabad':'105556105','Mumbai':'106164952','Bengaluru':'105214831',
    'Delhi NCR':'100458144','Chennai':'106151043','Pune':'104869687',
    'Kolkata':'104536289','Noida':'106199869','Gurgaon':'102140765',
    'Ahmedabad':'106785562','Jaipur':'102671845',
  };
  const NET={'1':['F'],'2':['S'],'3':['O'],'12':['F','S'],'23':['S','O'],'123':['F','S','O']};
  const EXP_MAP={'1':'1','2':'2','3':'3','4':'4','5':'5','6':'5','7':'5','8':'5'};
  const EXP_KW={
    '6':'"10 years" OR "12 years" OR "15 years"',
    '7':'"15 years" OR "18 years" OR "20 years"',
    '8':'"20 years" OR "22 years" OR "25 years"',
    'intern':'"internship" OR "intern" OR "trainee"',
    'fresher':'"fresher" OR "entry level" OR "new graduate" OR "recent graduate"',
  };
  const TYPE_KW={
    'open':       '"open to work" OR "#opentowork" OR "actively looking"',
    'immediate':  '"immediate joiner" OR "available immediately" OR "notice period 0"',
    'looking':    '"looking for change" OR "open to opportunities" OR "exploring opportunities"',
    'layoff':     '"laid off" OR "impacted by layoffs" OR "#opentowork" OR "between jobs"',
    'intern':     '"seeking internship" OR "looking for internship" OR "final year"',
    'fresher':    '"fresher" OR "entry level" OR "new graduate" OR "recent graduate"',
    'leadership': '"CEO" OR "CTO" OR "VP of Engineering" OR "Head of" OR "Director of Engineering"',
    'gcc':        '"GCC" OR "Global Capability Centre" OR "Global Capability Center"',
    'startup':    '"startup" OR "Series A" OR "Series B" OR "Series C" OR "unicorn"',
    'opennetwork':'"#LION" OR "open networker" OR "#opentoconnect"',
  };

  // ── Diversity keywords — real communities & organisations ONLY ──
  // NOT gender keywords — uses verified women-only professional communities
  // Diversity keywords — SHORT to stay within LinkedIn URL limits
  const DIVERSITY_KW={
    'women':   '"Women Who Code" OR "GirlScript" OR "#womenintech"',
    'tier2':   '"Nashik" OR "Indore" OR "Coimbatore" OR "Bhubaneswar"',
    'nonelite':'"VIT" OR "SRM" OR "Manipal" OR "Jadavpur"',
    'returner':'"career break" OR "returnship" OR "return to work"',
    'veteran': '"Indian Army" OR "ex-serviceman" OR "armed forces"',
    'pwd':     '"differently abled" OR "PWD" OR "specially abled"',
  };

  // ── Salary range → company tier mapping ────────────────────────
  // Based on: Glassdoor India 2025, AmbitionBox, Levels.fyi, LinkedIn Salary,
  //           Naukri Salary Index 2025, TeamLease Digital Report 2025
  const SALARY_TIERS={
    'entry_service': { expFilter:'1', coKw:'"TCS" OR "Infosys" OR "Wipro" OR "HCL" OR "Capgemini" OR "Cognizant" OR "Tech Mahindra"' },
    'entry_mid':     { expFilter:'1', coKw:'"Razorpay" OR "Zerodha" OR "Groww" OR "CRED" OR "BrowserStack" OR "Freshworks" OR "Postman"' },
    'entry_product': { expFilter:'1', coKw:'"Google" OR "Microsoft" OR "Amazon" OR "Adobe" OR "Cisco" OR "Oracle" OR "Salesforce"' },
    'entry_premium': { expFilter:'1', coKw:'"Google" OR "Goldman Sachs" OR "Morgan Stanley" OR "DE Shaw" OR "Tower Research" OR "Quadeye"' },
    'mid_service':   { expFilter:'3', coKw:'"TCS" OR "Infosys" OR "Wipro" OR "Accenture" OR "Capgemini" OR "IBM" OR "DXC"' },
    'mid_startup':   { expFilter:'3', coKw:'"Swiggy" OR "Zomato" OR "Ola" OR "PhonePe" OR "Paytm" OR "CRED" OR "Meesho" OR "Razorpay"' },
    'mid_gcc':       { expFilter:'4', coKw:'"Google" OR "Amazon" OR "Microsoft" OR "Cisco" OR "Intel" OR "Qualcomm" OR "Goldman Sachs"' },
    'mid_product':   { expFilter:'4', coKw:'"Google" OR "Microsoft" OR "Flipkart" OR "Amazon" OR "Adobe" OR "Atlassian" OR "Uber"' },
    'senior_service':{ expFilter:'4', coKw:'"TCS" OR "Infosys" OR "Wipro" OR "L&T" OR "HCL" OR "Accenture"' },
    'senior_startup':{ expFilter:'5', coKw:'"Razorpay" OR "CRED" OR "Zerodha" OR "PhonePe" OR "Meesho" OR "BrowserStack" OR "Postman"' },
    'senior_gcc':    { expFilter:'5', coKw:'"Google" OR "Amazon" OR "Microsoft" OR "Cisco" OR "Intel" OR "Qualcomm" OR "Shell" OR "Honeywell"' },
    'senior_product':{ expFilter:'5', coKw:'"Google" OR "Meta" OR "Apple" OR "Netflix" OR "Uber" OR "Stripe" OR "Airbnb"' },
    'lead_director': { expFilter:'5', coKw:'"Google" OR "Microsoft" OR "Amazon" OR "Goldman Sachs" OR "McKinsey" OR "BCG"' },
    'lead_vp':       { expFilter:'5', coKw:'"Google" OR "Microsoft" OR "Amazon" OR "Flipkart" OR "Razorpay" OR "PhonePe"' },
    'lead_cxo':      { expFilter:'5', coKw:'"CTO" OR "CPO" OR "Chief Technology" OR "Chief Product" OR "VP Engineering"' },
  };

  let kw = keywords;

  // Apply profile type keywords
  if(profileType && TYPE_KW[profileType])
    kw = kw ? `(${kw}) AND (${TYPE_KW[profileType]})` : TYPE_KW[profileType];

  // Apply experience keywords
  if(experience && EXP_KW[experience])
    kw = kw ? `(${kw}) AND (${EXP_KW[experience]})` : EXP_KW[experience];

  // Apply college
  if(college) kw = kw ? `(${kw}) AND "${college}"` : `"${college}"`;

  // Apply company (user-entered)
  if(company) kw = kw ? `(${kw}) AND "${company}"` : `"${company}"`;

  // ── Apply salary tier ────────────────────────────────────────
  if(salaryRange && SALARY_TIERS[salaryRange]) {
    const st = SALARY_TIERS[salaryRange];
    // Only add company filter if user hasn't already set one
    if(!company) kw = kw ? `(${kw}) AND (${st.coKw})` : st.coKw;
  }

  // ── Apply diversity filters ──────────────────────────────────
  if(diversityFilters && diversityFilters.length > 0) {
    const divKws = diversityFilters
      .filter(f => DIVERSITY_KW[f])
      .map(f => `(${DIVERSITY_KW[f]})`);
    if(divKws.length > 0) {
      const combined = divKws.join(' OR ');
      kw = kw ? `(${kw}) AND (${combined})` : combined;
    }
  }

  // ── Build LinkedIn URL ───────────────────────────────────────
  const network = JSON.stringify(NET[degree] || ['F','S','O']);
  let url = `https://www.linkedin.com/search/results/people/?keywords=${encodeURIComponent(kw)}&network=${encodeURIComponent(network)}&origin=FACETED_SEARCH`;

  // Add geo filter
  if(location && GEO[location])
    url += `&geoUrn=${encodeURIComponent('urn:li:geo:' + GEO[location])}`;

  // Add experience filter from salary tier if no manual experience set
  if(!experience && salaryRange && SALARY_TIERS[salaryRange]?.expFilter) {
    const ef = SALARY_TIERS[salaryRange].expFilter;
    url += `&yearsOfExperience=${encodeURIComponent(JSON.stringify([ef]))}`;
  } else if(experience && EXP_MAP[experience] && !isNaN(parseInt(experience)) && parseInt(experience) <= 5) {
    url += `&yearsOfExperience=${encodeURIComponent(JSON.stringify([EXP_MAP[experience]]))}`;
  }

  if(page > 1) url += `&page=${page}`;
  return url;
}


async function extractFromJD(text) {
  // Use Claude AI API for accurate JD parsing
  // This eliminates ALL regex guessing — AI understands context perfectly
  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 500,
        messages: [{
          role: "user",
          content: `You are an expert recruiter. Analyze this job description and return ONLY the JSON below.

CRITICAL: Extract the ACTUAL JOB BEING HIRED FOR.
- If hiring a Recruiter/TA → return recruiter keywords
- If hiring a Data Scientist → return data scientist keywords  
- NEVER return generic words like "communication", "agile", "collaboration"
- Skills must be SPECIFIC technical/professional skills for THIS role

JD:
${text.substring(0, 3000)}

Return ONLY this JSON:
{
  "jobTitle": "exact role title",
  "searchKeywords": "2-4 word LinkedIn search query",
  "topSkills": ["skill1", "skill2", "skill3"],
  "experienceYears": "e.g. 4+ years",
  "expFilter": "1-5",
  "locations": ["Indian city names"],
  "seniority": "junior/mid/senior/lead"
}` 
        }]
      })
    });

    if (!response.ok) throw new Error('API error');
    const data = await response.json();
    const raw = data.content?.[0]?.text || '';

    // Parse JSON response
    const parsed = JSON.parse(raw.replace(/```json|```/g, '').trim());

    // Map Indian cities properly
    const cityMap = {
      'bangalore':'Bengaluru','bengaluru':'Bengaluru','hyderabad':'Hyderabad',
      'mumbai':'Mumbai','delhi':'Delhi NCR','pune':'Pune','chennai':'Chennai',
      'kolkata':'Kolkata','noida':'Noida','gurgaon':'Gurgaon','gurugram':'Gurgaon',
      'ahmedabad':'Ahmedabad','jaipur':'Jaipur','kochi':'Kochi',
    };

    const locations = (parsed.locations || []).map(l => {
      const lc = l.toLowerCase();
      return cityMap[lc] || l;
    }).filter(Boolean);

    // AI returns 'topSkills' in JSON prompt but we read 'skills' — fix both
    const skills = (parsed.topSkills || parsed.skills || []).slice(0, 6);
    return {
      title:      parsed.jobTitle || parsed.searchKeywords || '',
      keywords:   parsed.searchKeywords || parsed.jobTitle || '',
      skills,
      topSkills:  skills,
      experience: parsed.experienceYears || '',
      expFilter:  parsed.expFilter || '3',
      location:   locations[0] || '',
      locations:  locations,
      education:  parsed.education || '',
      roleCategory: parsed.roleCategory || 'engineer',
    };

  } catch(e) {
    // Fallback to simple keyword extraction if API fails
    console.error('[PingIN] JD parse error:', e);
    return extractFromJDFallback(text);
  }
}


async function extractFromJDFallback(text) {
  const lower = text.toLowerCase();
  const result = { title:'', keywords:'', skills:[], experience:'', expFilter:'3', location:'', locations:[], education:'', roleCategory:'recruiter' };

  // Detect role from strong signals
  if (lower.includes('talent acquisition') || lower.includes('ta partner') || lower.includes(' recruiter') || lower.includes('recruiting'))
    result.keywords = 'Talent Acquisition Recruiter';
  else if (lower.includes('data scientist') || lower.includes('machine learning'))
    result.keywords = 'Data Scientist';
  else if (lower.includes('software engineer') || lower.includes('sde') || lower.includes('developer'))
    result.keywords = 'Software Engineer';
  else if (lower.includes('product manager') || lower.includes('product owner'))
    result.keywords = 'Product Manager';
  else if (lower.includes('devops') || lower.includes('sre') || lower.includes('cloud'))
    result.keywords = 'DevOps Engineer';
  else {
    // Extract from first non-section-header line
    const lines = text.split('\n').filter(l => l.trim() && !l.includes('*') && !l.toLowerCase().includes('responsible') && l.trim().length > 5);
    result.keywords = lines[0]?.trim().substring(0, 50) || 'Recruiter';
  }

  // Location
  const cityMap = { 'hyderabad':'Hyderabad','bangalore':'Bengaluru','bengaluru':'Bengaluru','mumbai':'Mumbai','delhi':'Delhi NCR','pune':'Pune','chennai':'Chennai' };
  for (const [k,v] of Object.entries(cityMap)) {
    if (lower.includes(k)) { result.location = v; result.locations = [v]; break; }
  }

  // Experience
  const expM = lower.match(/(\d+)\+?\s*years?/);
  if (expM) {
    const yr = parseInt(expM[1]);
    result.experience = yr + '+ years';
    result.expFilter = yr >= 10 ? '5' : yr >= 5 ? '4' : yr >= 3 ? '3' : '2';
  }

  return result;
}


async function buildCloneSearchWithAI(profile) {
  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 300,
        messages: [{
          role: "user",
          content: `Given this LinkedIn profile, suggest the best LinkedIn search query to find SIMILAR profiles.

Profile:
Name: ${profile.name}
Headline: ${profile.headline}
Company: ${profile.company}
Location: ${profile.location}
School: ${profile.school}
Skills: ${(profile.skills||[]).join(', ')}

Return ONLY valid JSON:
{
  "searchQuery": "exact LinkedIn search string (2-4 words, no quotes needed)",
  "location": "Indian city name or empty",
  "experience": "1-5 (1=0-1yr, 2=1-3yr, 3=3-5yr, 4=5-10yr, 5=10+yr)",
  "reason": "one line why this search finds similar people"
}`
        }]
      })
    });
    if (!response.ok) throw new Error('API');
    const data = await response.json();
    const raw = data.content?.[0]?.text || '';
    const parsed = JSON.parse(raw.replace(/```json|```/g,'').trim());

    const cityMap = {'bangalore':'Bengaluru','bengaluru':'Bengaluru','hyderabad':'Hyderabad','mumbai':'Mumbai','delhi':'Delhi NCR','pune':'Pune','chennai':'Chennai','noida':'Noida','gurgaon':'Gurgaon'};
    const loc = cityMap[(parsed.location||'').toLowerCase()] || parsed.location || '';

    // Build tags for display
    const tags = [];
    if (parsed.searchQuery) tags.push({ label: '🔍 ' + parsed.searchQuery, type: 'blue' });
    if (loc)                tags.push({ label: '📍 ' + loc, type: 'green' });
    if (parsed.reason)      tags.push({ label: '💡 ' + parsed.reason, type: 'amber' });

    return {
      keywords:    parsed.searchQuery || '',
      location:    loc,
      experience:  parsed.experience || '3',
      tags,
      profileData: profile,
    };
  } catch(e) {
    return null; // fallback to regex
  }
}


async function applyCloneSearch(params) {
  // Clear existing profiles for fresh search
  S.profiles = []; S.sent = 0; S.failed = 0;
  await chrome.storage.local.set({ profiles:[], sent:0, failed:0 });

  // Build search URL directly and navigate — no need to fill form
  const url = buildSearchUrl(
    params.keywords,
    params.location,
    '123',
    params.experience || '',
    '', '', '', 1, '', []
  );

  // Save params for scraping
  S.lastSearchParams = {
    keywords: params.keywords,
    location: params.location,
    degree: '123',
    experience: params.experience || '',
    profileType: '', college: '', degreeType: '', company: '',
    salaryRange: '', diversityFilters: []
  };
  await chrome.storage.local.set({ lastSearchParams: S.lastSearchParams });

  addLog('🧬 Clone Search: ' + (params.profileData?.name || 'profile'));

  // Open in new tab so popup stays alive and profiles appear automatically
  await chrome.tabs.create({ url, active: true });
  setTimeout(() => showScreen('screen-profiles', 'slide-up'), 1000);
}


async function applyJDToSearch(ext) {
  // Clear existing profiles for fresh search
  S.profiles = []; S.sent = 0; S.failed = 0;
  await chrome.storage.local.set({ profiles:[], sent:0, failed:0 });

  // Build search: Job title + top 2 skills for precision
  let kw = ext.keywords || ext.title || '';
  if (kw && kw.includes(' ') && !/\b(AND|OR|NOT)\b/.test(kw)) {
    kw = '"' + kw + '"';
  }
  // Add top 2 skills to narrow results to actual matching candidates
  const topSkills = (ext.topSkills || ext.skills || []).slice(0, 2);
  if (topSkills.length > 0 && kw) {
    const skillStr = topSkills.map(s => '"'+s+'"').join(' OR ');
    kw = '(' + kw + ') AND (' + skillStr + ')';
  }

  // Handle MULTIPLE locations — open one tab per location
  const locations = ext.locations || (ext.location ? [ext.location] : []);
  
  if (locations.length === 0) {
    // No location — single search in new tab (keeps popup alive)
    const url = buildSearchUrl(kw, '', '123', ext.expFilter || '', '', '', '', 1, '', []);
    await chrome.tabs.create({ url, active: true });
  } else if (locations.length === 1) {
    // Single location — new tab
    const url = buildSearchUrl(kw, locations[0], '123', ext.expFilter || '', '', '', '', 1, '', []);
    await chrome.tabs.create({ url, active: true });
  } else {
    // Multiple locations — open a tab for each
    for (let i = 0; i < locations.length; i++) {
      const url = buildSearchUrl(kw, locations[i], '123', ext.expFilter || '', '', '', '', 1, '', []);
      await chrome.tabs.create({ url, active: i === 0 });
      await new Promise(r => setTimeout(r, 300));
    }
    addLog('JD Search: opened ' + locations.length + ' tabs for ' + locations.join(', '));
  }

  S.lastSearchParams = { keywords:kw, location:locations[0]||'', degree:'123', experience:ext.expFilter||'', profileType:'', college:'', degreeType:'', company:'', salaryRange:'', diversityFilters:[] };
  await chrome.storage.local.set({ lastSearchParams: S.lastSearchParams });
  
  setTimeout(() => showScreen('screen-profiles', 'slide-up'), 1500);
}


function filterDropdown(query, selectId, dropdownId) {
  const dropdown = document.getElementById(dropdownId);
  const select   = document.getElementById(selectId);
  if (!dropdown || !select) return;
  const q = (query||'').toLowerCase().trim();
  if (!q) { dropdown.style.display='none'; return; }
  const allOptions = Array.from(select.querySelectorAll('option'))
    .filter(o => o.value && o.value !== 'other_college' && o.value !== '')
    .filter(o => o.text.toLowerCase().includes(q) || o.value.toLowerCase().includes(q))
    .slice(0, 12);
  // Show first 8 options even on empty query
  const displayOptions = q ? allOptions : Array.from(select.querySelectorAll('option')).filter(o=>o.value&&o.value!=='other_college'&&o.value!=='').slice(0,8);
  const finalOptions = q ? allOptions : displayOptions;
  if (!finalOptions.length) { dropdown.style.display='none'; return; }
  dropdown.innerHTML = allOptions.map(o =>
    `<div class="cd-item" data-value="${o.value.replace(/"/g,'&quot;')}" data-select="${selectId}" data-inp="${dropdownId.replace('-dropdown','-search')}">${o.text.replace(new RegExp('('+q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','gi'),'<mark>$1</mark>')}</div>`
  ).join('');
  dropdown.style.display = 'block';
  dropdown.querySelectorAll('.cd-item').forEach(item => {
    item.addEventListener('mousedown', e => {
      e.preventDefault();
      const val = item.dataset.value;
      const sel = document.getElementById(item.dataset.select);
      const inp = document.getElementById(item.dataset.inp);
      if (inp) inp.value = item.textContent;
      if (sel) sel.value = val;
      dropdown.style.display = 'none';
      const kw = document.getElementById('s-keywords');
      if (kw && val && !kw.value.includes(val)) {
        kw.value = kw.value ? kw.value + ' "' + val + '"' : '"' + val + '"';
      }
      updateProfileTypeState();
    });
  });
}


async function filterCompanyDropdown(query) {
  const dd = document.getElementById('company-dropdown');
  if (!dd) return;
  const q = (query||'').toLowerCase().trim();

  const popular = ['TCS','Infosys','Wipro','HCL Technologies','Accenture',
    'Google India','Microsoft India','Amazon India','Swiggy','Zomato',
    'Flipkart','Deloitte','HDFC Bank','ICICI Bank','Cognizant'];

  const filtered = q
    ? COMPANIES.filter(c => c.toLowerCase().includes(q)).slice(0,12)
    : popular;

  if (!filtered.length) { dd.style.display='none'; return; }

  dd.innerHTML = filtered.map(c => {
    let display = c;
    if (q) {
      try {
        const re = new RegExp('('+q.replace(/[$()*+.?[\\]^{|}]/g,'\\$&')+')','gi');
        display = c.replace(re,'<mark>$1</mark>');
      } catch(e) {}
    }
    return '<div class="cd-item" data-val="'+c.replace(/"/g,'&quot;')+'">'+display+'</div>';
  }).join('');
  dd.style.display = 'block';

  dd.querySelectorAll('.cd-item').forEach(item => {
    item.addEventListener('mousedown', function(e) {
      e.preventDefault();
      var inp = document.getElementById('s-company');
      if (inp) inp.value = item.dataset.val;
      dd.style.display = 'none';
    });
  });
}


async function checkPlanStatus() {
  try {
    const data = await chrome.storage.local.get([
      'planStatus','planExpiry','licenseKey','trialStart','dailyLimit'
    ]);

    const plan        = data.planStatus  || 'free';
    const planExpiry  = data.planExpiry  || null;
    const licenseKey  = data.licenseKey  || null;
    const trialStart  = data.trialStart  || null;
    const now         = Date.now();

    // ── If no plan set at all — treat as free trial, allow viewing ──
    if (!licenseKey && !planExpiry) {
      S.plan = 'free';
      S.trialDaysLeft = TRIAL_DAYS;
      S.trialMsgsLeft = TRIAL_MSGS;
      updatePlanBar();
      updatePremiumGating();
      return;
    }

    // ── Check expiry ──
    if (planExpiry && now > new Date(planExpiry)) {
      S.plan = 'expired';
      updatePlanBar();
      updatePremiumGating();
      return;
    }

    // ── Active plan ──
    S.plan = plan;
    if (planExpiry) {
      S.trialDaysLeft = Math.max(0, Math.ceil((new Date(planExpiry) - now) / 86400000));
    } else {
      S.trialDaysLeft = TRIAL_DAYS;
    }
    S.trialMsgsLeft = data.dailyLimit || PLANS[plan]?.dailyLimit || (S.plan==='free' ? 5 : 50);
    updatePlanBar();
    updatePremiumGating();

  } catch(e) {
    // On any error — allow free trial access so user is not locked out
    S.plan = 'free';
    S.trialDaysLeft = TRIAL_DAYS;
    S.trialMsgsLeft = TRIAL_MSGS;
    updatePlanBar();
    updatePremiumGating();
  }
}


function updatePlanBar() {
  const bar  = document.getElementById('plan-bar');
  const icon = document.getElementById('plan-bar-icon');
  const text = document.getElementById('plan-bar-text');
  const upBtn= document.getElementById('plan-bar-upgrade');
  if (!bar) return;
  bar.style.display = 'flex';

  if (S.plan === 'expired') {
    bar.className = 'plan-bar';
    bar.style.background = 'rgba(226,75,74,.12)';
    if (icon) icon.textContent = '⚠';
    if (text) text.textContent = 'Plan expired — renew at pingin.in';
    if (upBtn) { upBtn.style.display='inline-block'; upBtn.textContent='Renew'; }
    return;
  }

  const planNames = { free:'Free Trial', starter:'Starter', pro:'Pro', annual:'Annual' };
  const planName  = planNames[S.plan] || 'Free Trial';
  const msgsLeft  = S.trialMsgsLeft || 10;
  const daysLeft  = S.trialDaysLeft || 5;

  if (S.plan === 'free' || !S.plan) {
    bar.className = 'plan-bar';
    bar.style.background = 'rgba(0,119,181,.1)';
    if (icon) icon.textContent = '🆓';
    if (text) text.textContent = 'Free Trial · ' + msgsLeft + ' msgs/day · ' + daysLeft + ' days left';
    if (upBtn) { upBtn.style.display='inline-block'; upBtn.textContent='Upgrade'; }
  } else {
    bar.className = 'plan-bar premium';
    bar.style.background = '';
    if (icon) icon.textContent = '✓';
    if (text) text.textContent = planName + ' · ' + msgsLeft + ' msgs/day · ' + daysLeft + ' days left';
    if (upBtn) upBtn.style.display = 'none';
  }
}


async function updatePremiumGating() {
  const isPaid    = ['starter','pro','annual'].includes(S.plan);
  const isFree    = S.plan === 'free' || !S.plan;
  const isExpired = S.plan === 'expired';

  const saveSrch = document.getElementById('btn-save-search');
  const saveProf = document.getElementById('btn-save-profiles');

  // Save search — paid only
  if (saveSrch) {
    saveSrch.disabled = !isPaid;
    saveSrch.title = isPaid ? 'Save this search' : 'Upgrade to save searches';
    saveSrch.classList.toggle('locked', !isPaid);
  }
  // Save profiles — pro/annual only
  if (saveProf) {
    const canSave = ['pro','annual'].includes(S.plan);
    saveProf.disabled = !canSave;
    saveProf.title = canSave ? 'Save profiles' : 'Upgrade to Pro to save profiles';
    saveProf.classList.toggle('locked', !canSave);
  }

  // ── FREE TRIAL: can search and VIEW profiles, just limited messages ──
  // No blocking of profile viewing for free trial

}



// ── DOM helpers ──────────────────────────────────────────────────────────────
function setVal(id, val) {
  const el = document.getElementById(id);
  if (el) el.value = val;
}
function setChk(id, checked) {
  const el = document.getElementById(id);
  if (el) el.checked = !!checked;
}

async function syncFromStorage() {
  try {
    const data = await chrome.storage.local.get([
      'profiles','log','settings','sent','failed',
      'messageTemplate','searchHistory','planStatus','lastSearchParams',
      'totalMsgsSent','dailySent','pendingScrape','lastScrapeResult',
    ]);

    S.profiles         = data.profiles         || [];
    S.log              = data.log              || [];
    S.sent             = data.sent             || 0;
    S.failed           = data.failed           || 0;
    S.history    = data.searchHistory    || [];
    S.plan             = data.planStatus       || 'free'; // default to free trial
    S.lastSearchParams = data.lastSearchParams || null;

    // Settings
    const cfg = data.settings || {};
    setVal('c-daily',            cfg.dailyLimit    || 50);
    setVal('c-delay',            cfg.delaySeconds  || 45);
    setVal('set-weekly',         cfg.weeklyLimit   || 80);
    setChk('set-random-delay',   cfg.randomDelay   !== false);
    setChk('set-biz-hours',      cfg.bizHours      !== false);
    setChk('set-skip-connected', cfg.skipConnected !== false);
    setChk('set-skip-messaged',  cfg.skipMessaged  !== false);
    setChk('set-auto-pause',     cfg.autoPause     !== false);

    // Restore message template
    if (data.messageTemplate) {
      const ta = document.getElementById('s-message');
      if (ta) { ta.value = data.messageTemplate; updateCharCount(); }
    }

    // ── Check if service worker just finished a scrape ──
    const lastScrape = data.lastScrapeResult;
    if (lastScrape && (Date.now() - lastScrape.at) < 30000) {
      // Fresh scrape result — notify user
      setTimeout(() => {
        showStatus('✓ ' + lastScrape.count + ' profiles collected! Total: ' + lastScrape.total, 'success');
        renderProfiles(); updateStats();
      }, 500);
      await chrome.storage.local.remove('lastScrapeResult');
    }

    // ── Check for pending scrape (popup was closed during search) ──
    const pendingScrape = data.pendingScrape;
    if (pendingScrape && (Date.now() - pendingScrape.requestedAt) < 120000) {
      // Within 2 minutes — check if we're on the right page and scrape
      const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      const tab  = tabs?.[0];
      if (tab?.url?.includes('linkedin.com/search/results/people')) {
        showStatus('Search results detected! Collecting profiles...','info');
        setTimeout(async () => {
          await doScrape(tab.id, pendingScrape.params, pendingScrape.page || 1);
          await chrome.storage.local.remove('pendingScrape');
        }, 1500);
      }
    }

    // ── Restore last search fields ──
    if (S.lastSearchParams) {
      const p = S.lastSearchParams;
      const setField = (id, val) => { const el=document.getElementById(id); if(el&&val) el.value=val; };
      setField('s-keywords',    p.keywords);
      setField('s-location',    p.location);
      setField('s-degree',      p.degree);
      setField('s-experience',  p.experience);
      setField('s-college',     p.college);
      setField('s-company',     p.company);
      setField('s-degree-type', p.degreeType);
      setField('s-salary-range', p.salaryRange);
      // Restore diversity filters
      if (p.diversityFilters && p.diversityFilters.length > 0) {
        const toggle = document.getElementById('diversity-toggle');
        const sub    = document.getElementById('diversity-sub');
        if (toggle) { toggle.checked = true; }
        if (sub)    { sub.style.display = 'block'; }
        p.diversityFilters.forEach(val => {
          const chk = document.querySelector(`.div-chk[value="${val}"]`);
          if (chk) chk.checked = true;
        });
      }
      if (p.keywords && p.profileType) {
        const pt = document.getElementById('s-profile-type');
        if (pt) { pt.disabled=false; pt.value=p.profileType; }
      }
    }

  } catch(e) {
    console.error('[PingIN] syncFromStorage error:', e);
  }
}


async function checkLoginState() {
  try {
    const data = await chrome.storage.local.get(['userSession','planStatus']);
    const session = data.userSession;
    const loginScreen = document.getElementById('login-screen');
    const mainApp     = document.getElementById('main-app');

    if (session?.loginAt) {
      const hours = (Date.now() - new Date(session.loginAt)) / 3600000;
      if (hours < 168) {
        loginScreen && (loginScreen.style.display='none');
        mainApp     && (mainApp.style.display='block');
        const footerUser = document.getElementById('footer-user');
        if (footerUser && session.name) footerUser.textContent = session.name;
        return true;
      }
    }
    // ── Fallback: try reading from pingin_session via injected script ──
    // Website stores session in localStorage — try to read it
    try {
      const liTabs = await chrome.tabs.query({ url: 'https://pingin.in/*' });
      if (liTabs.length > 0) {
        const res = await chrome.scripting.executeScript({
          target: { tabId: liTabs[0].id },
          func: () => {
            try { return JSON.parse(localStorage.getItem('pingin_session') || 'null'); } catch(e) { return null; }
          }
        });
        const webSession = res?.[0]?.result;
        if (webSession?.loginAt && webSession?.email) {
          // Sync to chrome.storage for future use
          await chrome.storage.local.set({ userSession: webSession });
          loginScreen && (loginScreen.style.display='none');
          mainApp     && (mainApp.style.display='block');
          const footerUser = document.getElementById('footer-user');
          if (footerUser && webSession.name) footerUser.textContent = webSession.name;
          return true;
        }
      }
    } catch(e) {}
    // ── Extension works without login — show app anyway ──
    loginScreen && (loginScreen.style.display='none');
    mainApp     && (mainApp.style.display='block');
    const footerUser = document.getElementById('footer-user');
    if (footerUser) footerUser.textContent = 'Free Trial';
    return true;
  } catch(e) {
    console.error('[PingIN] checkLoginState:', e);
    return false;
  }
}


function renderProfiles(filter){
  if (filter !== undefined) S.currentFilter = filter;
  if (!S.currentFilter) S.currentFilter = 'all';
  updateTopProfiles();
  const list=document.getElementById('profiles-list');
  const empty=document.getElementById('profiles-empty');

  // Score all profiles
  const scored = S.profiles.map(p => ({
    ...p,
    _score: scoreProfile(p, S.lastSearchParams)
  }));

  let filtered = scored;

  // Filter by tab
  if (S.currentFilter === 'toppicks') {
    filtered = scored
      .filter(p => p._score >= 75)
      .sort((a,b) => b._score - a._score);
  } else if (S.currentFilter !== 'all') {
    filtered = scored.filter(p =>
      S.currentFilter === 'pending'
        ? (p.status==='pending'||p.status==='queued')
        : p.status === S.currentFilter
    );
  } else {
    // All — sort by score descending
    filtered = scored.sort((a,b) => b._score - a._score);
  }

  const countEl = document.getElementById('profiles-count');
  if (countEl) {
    if (S.currentFilter === 'toppicks') {
      countEl.textContent = filtered.length + ' top picks (score ≥75)';
    } else {
      countEl.textContent = filtered.length + (S.currentFilter!=='all' ? ' '+S.currentFilter : '') + ' profiles';
    }
  }

  if (!filtered.length) {
    empty.style.display = 'block';
    list.innerHTML = S.currentFilter === 'toppicks'
      ? '<div class="toppicks-empty">🔍 No top picks yet.<br>Collect more profiles to see top matches!</div>'
      : '';
    return;
  }
  empty.style.display = 'none';

  // Score legend (show in Top Picks and All tabs)
  const legend = (S.currentFilter === 'toppicks' || S.currentFilter === 'all')
    ? `<div class="score-legend">
        <span style="font-weight:600;color:var(--ts)">Score:</span>
        <span class="sl-item"><span class="score-badge score-hot">🔥 90+</span> Hot</span>
        <span class="sl-item"><span class="score-badge score-strong">⭐ 75+</span> Strong</span>
        <span class="sl-item"><span class="score-badge score-good">✅ 60+</span> Good</span>
      </div>`
    : '';

  list.innerHTML = legend + filtered.slice(0,60).map((p,i) => {
    const ini=(p.name||'?').split(' ').map(n=>n[0]).join('').slice(0,2).toUpperCase();
    const[bg,tc]=AV[i%AV.length];
    const sub=[p.role,p.company,p.city].filter(Boolean).join(' · ');
    const av=p.photo
      ? `<img src="${p.photo}" style="width:30px;height:30px;border-radius:50%;object-fit:cover" onerror="this.style.display='none'">`
      : ini;
    const degBadge=p.degree?`<span class="p-degree">${p.degree}</span>`:'';
    const otwBadge=p.isOTW?`<span class="p-degree" style="background:rgba(0,212,170,.15);color:var(--accent)">OTW</span>`:'';
    const sc=p.status==='queued'?'pending':(p.status||'pending');
    const scoreClass = getScoreClass(p._score);
    const scoreLabel = getScoreLabel(p._score);
    const borderClass = p._score>=90?'hot':p._score>=75?'strong':p._score>=60?'good':'';
    const sourceLabel = p.keyword ? `<span style="font-size:9px;color:var(--tm);display:block;margin-top:2px;">🔍 ${(p.keyword||'').substring(0,30)}</span>` : '';
    return `<div class="profile-item ${borderClass}" data-url="${p.profileUrl||''}" style="cursor:pointer;" title="Click to open LinkedIn profile">
      <div class="p-av-wrap">
        <div class="p-av" style="background:${bg};color:${tc}">${av}</div>
        ${p.isOTW ? '<div class="p-otw-dot" title="Open to Work"></div>' : ''}
      </div>
      <div class="p-info">
        <div class="p-name">${p.name}${degBadge}</div>
        <div class="p-sub">${sub||'—'}</div>
        ${sourceLabel}
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:3px;flex-shrink:0;">
        <span class="score-badge ${scoreClass}">${scoreLabel}</span>
        <span class="p-badge ${sc}">${sc}</span>
      </div>
    </div>`;
  }).join('') + (filtered.length>60
    ? `<div style="text-align:center;padding:8px;font-size:11px;color:var(--ts)">+${filtered.length-60} more</div>`
    : '');
}


function updateStats(){
  (function(){const _el=document.getElementById('c-found');if(_el)_el.textContent=S.profiles.length;})();
  (function(){const _el=document.getElementById('c-sent');if(_el)_el.textContent=S.profiles.filter(p=>p.status==='sent').length;})();
  (function(){const _el=document.getElementById('c-pending');if(_el)_el.textContent=S.profiles.filter(p=>p.status==='pending'||p.status==='queued').length;})();
  (function(){const _el=document.getElementById('c-failed');if(_el)_el.textContent=S.profiles.filter(p=>p.status==='failed').length;})();
}


function exportCSV(){
  if(!S.profiles.length){alert('No profiles to export.');return;}
  const hdr=['Name','Role','Company','City','Degree','Open To Work','LinkedIn URL','Status','Keyword','Company Filter','Location','Scraped At'];
  const rows=S.profiles.map(p=>[p.name,p.role||'',p.company||'',p.city||'',p.degree||'',p.isOTW?'Yes':'No',p.profileUrl||'',p.status||'pending',p.keyword||'',p.company||'',p.location||'',p.scrapedAt||'']);
  const csv=[hdr,...rows].map(r=>r.map(c=>'"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n');
  const a=Object.assign(document.createElement('a'),{href:URL.createObjectURL(new Blob([csv],{type:'text/csv'})),download:'pingin_'+new Date().toISOString().slice(0,10)+'.csv'});
  a.click();addLog('CSV exported · '+S.profiles.length+' profiles');
}


async function exportXLSX() {
  if (!S.profiles.length) { alert('No profiles to export.'); return; }
  // Build CSV and trigger download as xlsx-compatible
  const headers = ['Name','Role','Company','City','Degree','OTW','Score','Profile URL','Status','Scraped At'];
  const rows = S.profiles.map(p => {
    const score = scoreProfile(p, S.lastSearchParams);
    return [
      p.name||'', p.role||'', p.company||'', p.city||'',
      p.degree||'', p.isOTW?'Yes':'No', score,
      p.profileUrl||'', p.status||'', p.scrapedAt||''
    ].map(v => '"'+String(v).replace(/"/g,'""')+'"').join(',');
  });
  const csv = [headers.join(','), ...rows].join('\n');
  const blob = new Blob(['\uFEFF'+csv], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'pingin_profiles_'+new Date().toISOString().slice(0,10)+'.csv';
  a.click(); URL.revokeObjectURL(url);
  addLog('Exported '+S.profiles.length+' profiles as CSV/Excel');
}


async function clearProfiles(){
  if(!confirm('Clear all '+S.profiles.length+' profiles?'))return;
  S.profiles=[];S.sent=0;S.failed=0;
  await chrome.storage.local.set({profiles:[],sent:0,failed:0});
  renderProfiles();updateStats();addLog('Profiles cleared');
}


async function saveCurrentSearch(){
  const params={
    keywords:   document.getElementById('s-keywords').value.trim(),
    location:   document.getElementById('s-location').value,
    degree:     document.getElementById('s-degree').value,
    experience: document.getElementById('s-experience').value,
    profileType:document.getElementById('s-profile-type').value,
    college:    document.getElementById('s-college').value,
    company:    document.getElementById('s-company').value.trim(),
    savedAt:    new Date().toISOString(),
  };
  if(!params.keywords){showStatus('Nothing to save — enter keywords first.','warning');return;}
  const data=await chrome.storage.local.get('savedSearches');
  const saved=data.savedSearches||[];
  saved.unshift(params);
  if(saved.length>20)saved.pop();
  await chrome.storage.local.set({savedSearches:saved});
  showStatus('✓ Search saved!','success');
  addLog('Search saved: "'+params.keywords+'"');
}


async function startSearch(){
  // Check plan
  if (S.plan === 'expired') {
    showStatus('Your plan has expired. Please renew at pingin.in/pricing.html', 'warning');
    window.open('https://pingin.in/pricing.html');
    return;
  }
  let keywords=document.getElementById('s-keywords').value.trim();
  if(!keywords){showStatus('Enter a keyword or job title first.','warning');document.getElementById('s-keywords').focus();return;}

  // ── Smart exact-phrase wrapping ──────────────────────────────────
  // If user typed a multi-word title WITHOUT quotes and WITHOUT AND/OR/NOT
  // → auto-wrap in quotes for exact match
  // e.g. "Staff Engineer" → ensures exact title match, not Staff AND Engineer
  const hasBoolOp = /(AND|OR|NOT)|["()]/.test(keywords);
  if (!hasBoolOp && keywords.includes(' ')) {
    keywords = `"${keywords}"`;
    // Update the input to show user what's being searched
    document.getElementById('s-keywords').value = keywords;
  }

  const location   =document.getElementById('s-location').value;
  const degree     =document.getElementById('s-degree').value;
  const experience =document.getElementById('s-experience').value;
  const profileType=document.getElementById('s-profile-type').value;
  const college    =document.getElementById('s-college').value;
  const degreeType =document.getElementById('s-degree-type')?.value||'';
  const company    =document.getElementById('s-company').value.trim();
  const salaryRange  = document.getElementById('s-salary-range')?.value||'';
  const diversityOn = document.getElementById('diversity-toggle')?.checked||false;
  const diversityFilters = diversityOn ? ['women'] : [];

  // Save params for multi-page
  S.lastSearchParams={keywords,location,degree,experience,profileType,college,degreeType,company,salaryRange,diversityFilters};
  await chrome.storage.local.set({lastSearchParams:S.lastSearchParams});
  S.currentPage=1;

  const searchUrl=buildSearchUrl(keywords,location,degree,experience,profileType,college,company,1,salaryRange,diversityFilters);
  const btn=document.getElementById('btn-search');
  btn.disabled=true;
  btn.innerHTML='<span style="display:inline-block;animation:spin 1s linear infinite">⟳</span> Searching...';

  await saveToHistory({keywords,location,degree,experience,profileType,college,degreeType,company,salaryRange,diversityFilters,searchedAt:new Date().toISOString()});
  const salaryLabel    = salaryRange ? ' · '+salaryRange.replace(/_/g,' ') : '';
  const diversityLabel = diversityFilters.length ? ' · 🌈 '+diversityFilters.join('+') : '';
  addLog('Search: "'+keywords+'"'+(location?' · '+location:'')+(company?' · @'+company:'')+salaryLabel+diversityLabel);
  showStatus('Navigating to LinkedIn...','info');

  try{
    // Save pending scrape — service worker picks this up when LinkedIn loads
    await chrome.storage.local.set({
      pendingScrape: {
        url:         searchUrl,
        params:      S.lastSearchParams,
        page:        1,
        isNewSearch: true,
        requestedAt: Date.now(),
      }
    });

    // Open LinkedIn — popup closes here automatically (Chrome MV3 behaviour)
    // Service worker's tabs.onUpdated listener handles scraping from this point
    await chrome.tabs.create({ url: searchUrl, active: true });
    showStatus('✓ LinkedIn opening... Profiles will appear when you reopen PingIN.','success');
    resetSearchBtn();

  }catch(e){
    showStatus('Error: '+e.message,'error');
    addLog('Search error: '+e.message);
    resetSearchBtn();
  }
}


async function doScrape(tabId, params, page) {
  try {
    showStatus('Collecting profiles from page...', 'info');

    // Pass tabId directly so service worker scrapes the right tab
    const resp = await chrome.runtime.sendMessage({ action: 'MANUAL_SCRAPE', tabId });

    if (resp?.ok) {
      await syncFromStorage();

      const scrapeInfo = document.getElementById('scrape-info');
      if (scrapeInfo) {
        scrapeInfo.style.display = 'block';
        const siCount = document.getElementById('si-count');
        const siPages = document.getElementById('si-pages');
        if (siCount) siCount.textContent = S.profiles.length + ' profiles collected';
        if (siPages) siPages.textContent = 'Page ' + page;
      }

      const nextBtn = document.getElementById('btn-next-page');
      if (nextBtn) nextBtn.style.display = 'block';

      addLog('Page ' + page + ': +' + resp.added + ' profiles · "' + (params?.keywords||'') + '"');
      showStatus('✓ ' + resp.added + ' new profiles added! Total: ' + resp.total, 'success');

      renderProfiles();
      updateStats();

      setTimeout(() => document.querySelector('[data-tab="profiles"]')?.click(), 1200);
    } else {
      showStatus('Trying direct scrape...', 'info');
      await directScrape(tabId, params, page);
    }
  } catch(e) {
    console.error('[PingIN] doScrape error:', e);
    await directScrape(tabId, params, page);
  }
}


// ═══════════════════════════════════════════════════════════════
//  CLONE SEARCH — Rewritten for new screen structure
// ═══════════════════════════════════════════════════════════════
async function initCloneSearch() {
  const analyseBtn = document.getElementById('clone-analyse-btn');
  const urlInput   = document.getElementById('clone-url-input');
  const resultDiv  = document.getElementById('clone-result');
  const loadingBox = document.getElementById('clone-loading-box');
  const errorBox   = document.getElementById('clone-error');
  const searchBtn  = document.getElementById('clone-search-btn');

  if (!analyseBtn) return;
  analyseBtn.addEventListener('click', () => runCloneAnalyse());
  urlInput?.addEventListener('keydown', e => { if(e.key==='Enter') runCloneAnalyse(); });

  searchBtn?.addEventListener('click', async () => {
    if (!window._cloneSearchParams) return;
    searchBtn.disabled = true;
    searchBtn.textContent = '⟳ Opening LinkedIn...';
    await applyCloneSearch(window._cloneSearchParams);
    searchBtn.disabled = false;
    searchBtn.innerHTML = '🧬 Search Similar Profiles on LinkedIn →';
  });

  async function runCloneAnalyse() {
    const url = (urlInput?.value || '').trim();
    if (!url) { showCloneError('Please paste a LinkedIn profile URL.'); return; }
    const username = extractLinkedInUsername(url);
    if (!username) { showCloneError('Invalid URL. Use: linkedin.com/in/username'); return; }

    if (resultDiv)  resultDiv.style.display = 'none';
    if (errorBox)   { errorBox.style.display = 'none'; errorBox.classList.remove('show'); }
    if (loadingBox) { loadingBox.className = 'info-box info show'; }
    analyseBtn.disabled = true;
    analyseBtn.textContent = '⟳';

    try {
      const profileUrl = url.startsWith('http') ? url : 'https://www.linkedin.com/in/'+username;
      const bgTab = await chrome.tabs.create({ url: profileUrl, active: false });
      await new Promise(resolve => {
        const maxWait = setTimeout(resolve, 8000);
        const listener = (tabId, info) => {
          if (tabId === bgTab.id && info.status === 'complete') {
            chrome.tabs.onUpdated.removeListener(listener);
            clearTimeout(maxWait);
            setTimeout(resolve, 2500);
          }
        };
        chrome.tabs.onUpdated.addListener(listener);
      });

      const results = await chrome.scripting.executeScript({
        target: { tabId: bgTab.id },
        func: () => {
          try {
            const d = {};
            d.name = document.querySelector('h1.text-heading-xlarge, h1[class*="inline"]')?.textContent?.trim() || '';
            d.headline = document.querySelector('.text-body-medium.break-words')?.textContent?.trim() || '';
            d.location = document.querySelector('.pb2.pv-top-card--list span.text-body-small')?.textContent?.trim() || '';
            d.experienceCount = document.querySelectorAll('#experience ~ .pvs-list__outer-container .pvs-entity').length;
            d.school = document.querySelector('#education ~ .pvs-list__outer-container .pvs-entity .mr1 span[aria-hidden="true"]')?.textContent?.trim() || '';
            d.skills = Array.from(document.querySelectorAll('#skills ~ .pvs-list__outer-container .pvs-entity .mr1 span[aria-hidden="true"]')).slice(0,5).map(s=>s.textContent.trim()).filter(Boolean);
            d.isOTW = !!document.querySelector('.pv-member-badge--opentowork, [class*="open-to-work"]');
            return d;
          } catch(e) { return null; }
        }
      });
      try { await chrome.tabs.remove(bgTab.id); } catch(e) {}

      const profile = results?.[0]?.result;
      if (profile?.name) {
        await showCloneResult(profile, username);
      } else {
        showCloneFallback(username);
      }
    } catch(e) {
      showCloneFallback(username);
    } finally {
      if (loadingBox) { loadingBox.className = 'info-box'; loadingBox.style.display = 'none'; }
      analyseBtn.disabled = false;
      analyseBtn.textContent = '🔍 Analyse';
    }
  }

  async function showCloneResult(profile, username) {
    let params;
    try {
      params = await buildCloneSearchWithAI(profile) || buildCloneSearchFromProfile(profile);
    } catch(e) {
      params = buildCloneSearchFromProfile(profile);
    }
    window._cloneSearchParams = params;
    const initials = (profile.name||'?').split(' ').map(n=>n[0]).join('').slice(0,2).toUpperCase();
    const card = document.getElementById('clone-profile-card');
    if (card) card.innerHTML = '<div class="clone-av">'+initials+'</div><div><div class="clone-name-text">'+profile.name+'</div><div class="clone-role-text">'+(profile.headline||'—')+'</div></div>';
    const tagsEl = document.getElementById('clone-tags');
    if (tagsEl) tagsEl.innerHTML = params.tags.map(t=>'<span class="clone-tag '+t.type+'">'+t.label+'</span>').join('');
    if (resultDiv) resultDiv.style.display = 'block';
  }

  function showCloneFallback(username) {
    window._cloneSearchParams = { keywords:'"'+username.replace(/-/g,' ')+'"', location:'', experience:'3', tags:[{label:'🔍 '+username,type:'blue'}], profileData:{name:username,headline:''} };
    const card = document.getElementById('clone-profile-card');
    if (card) card.innerHTML = '<div class="clone-av">?</div><div><div class="clone-name-text">'+username+'</div><div class="clone-role-text">Basic search mode</div></div>';
    const tagsEl = document.getElementById('clone-tags');
    if (tagsEl) tagsEl.innerHTML = '<span class="clone-tag blue">🔍 '+username+'</span>';
    if (resultDiv) resultDiv.style.display = 'block';
  }

  function showCloneError(msg) {
    if (errorBox) { errorBox.className='info-box warning show'; errorBox.textContent='⚠️ '+msg; }
  }
}


// ═══════════════════════════════════════════════════════════════
//  JD SEARCH — Rewritten for new screen structure
// ═══════════════════════════════════════════════════════════════
async function initJDSearch() {
  const analyseBtn = document.getElementById('btn-jd-analyse');
  const searchBtn  = document.getElementById('btn-jd-search');
  const statusBox  = document.getElementById('jd-status');
  const tagsEl     = document.getElementById('jd-tags');
  const parsedRes  = document.getElementById('jd-parsed-result');
  const fileInput  = document.getElementById('jd-file');
  const fileBtn    = document.getElementById('jd-file-btn');
  const fileName   = document.getElementById('jd-file-name');

  // File upload
  fileBtn?.addEventListener('click', () => fileInput?.click());
  fileInput?.addEventListener('change', () => {
    const file = fileInput?.files?.[0];
    if (!file) return;
    if (fileName) fileName.textContent = file.name;
    if (file.name.endsWith('.txt')) {
      const reader = new FileReader();
      reader.onload = e => {
        const ta = document.getElementById('jd-text');
        if (ta) ta.value = e.target.result;
        showJDStatus('✓ File loaded! Click Analyse JD.', 'success');
      };
      reader.readAsText(file);
    } else {
      showJDStatus('⚠️ Only .txt files supported. Please copy-paste PDF/Word JD text below.', 'warning');
    }
  });

  // Fetch JD from URL
  const urlFetchBtn = document.getElementById('btn-jd-fetch');
  urlFetchBtn?.addEventListener('click', async () => {
    const url = (document.getElementById('jd-url-input')?.value||'').trim();
    if (!url || !url.startsWith('http')) {
      showJDStatus('Please enter a valid job URL.', 'warning'); return;
    }
    urlFetchBtn.disabled = true; urlFetchBtn.textContent = '⟳ Fetching...';
    showJDStatus('Opening job page... this takes ~6 seconds.', 'info');
    try {
      const bgTab = await chrome.tabs.create({ url, active: false });
      // Wait longer for LinkedIn React to fully render the job description
      await new Promise(r => setTimeout(r, 6000));
      const results = await chrome.scripting.executeScript({
        target: { tabId: bgTab.id },
        func: () => {
          // LinkedIn job page selectors (in priority order)
          const selectors = [
            '.jobs-description__content .jobs-box__html-content',
            '.jobs-description-content__text',
            '.jobs-description__container',
            '[class*="description__text"]',
            '[class*="job-description"]',
            '.description__text',
            '#job-details',
            '.jobs-box__html-content',
          ];
          for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el && el.innerText && el.innerText.trim().length > 100) {
              return el.innerText.trim().substring(0, 5000);
            }
          }
          // Fallback: find the largest text block that looks like a JD
          const allDivs = Array.from(document.querySelectorAll('div, section, article'));
          const jdLike = allDivs
            .map(d => ({ el: d, text: d.innerText || '' }))
            .filter(d => d.text.length > 200 && 
                         (d.text.toLowerCase().includes('responsibilit') || 
                          d.text.toLowerCase().includes('qualif') ||
                          d.text.toLowerCase().includes('experience') ||
                          d.text.toLowerCase().includes('requirement')))
            .sort((a, b) => b.text.length - a.text.length);
          if (jdLike.length > 0) return jdLike[0].text.substring(0, 5000);
          return '';
        }
      });
      try { await chrome.tabs.remove(bgTab.id); } catch(e){}
      const text = (results?.[0]?.result || '').trim();
      // Clean up LinkedIn navigation text that gets included
      const cleaned = text
        .split('\n')
        .filter(line => {
          const l = line.trim().toLowerCase();
          return l.length > 0 &&
                 !l.includes('reactivate premium') &&
                 !l.includes('linkedin corporation') &&
                 !l.includes('privacy & terms') &&
                 !l.includes('talent solutions') &&
                 !l.includes('select language') &&
                 !l.includes('العربية') &&
                 !l.startsWith('©');
        })
        .join('\n')
        .trim();

      if (cleaned.length > 100) {
        const ta = document.getElementById('jd-text');
        if (ta) ta.value = cleaned;
        showJDStatus('✓ JD fetched! Click Analyse JD with AI.', 'success');
      } else {
        showJDStatus('⚠️ Could not auto-extract JD from this page. Please copy-paste the job description text in the box below.', 'warning');
      }
    } catch(e) {
      showJDStatus('Error fetching: ' + e.message + '. Please paste JD text manually.', 'warning');
    } finally {
      urlFetchBtn.disabled = false; urlFetchBtn.textContent = '📥 Fetch';
    }
  });

  // Analyse JD
  analyseBtn?.addEventListener('click', async () => {
    const text = document.getElementById('jd-text')?.value?.trim();
    if (!text || text.length < 30) {
      showJDStatus('Please paste a job description first.', 'warning'); return;
    }
    analyseBtn.disabled = true;
    analyseBtn.innerHTML = '<span class="spinning">⟳</span> Analysing with AI...';
    showJDStatus('🤖 AI is reading the JD...', 'info');
    try {
      const extracted = await extractFromJD(text);
      window._jdExtracted = extracted;
      showJDResult(extracted);
    } catch(e) {
      showJDStatus('Error: '+e.message, 'warning');
    } finally {
      analyseBtn.disabled = false;
      analyseBtn.textContent = '🤖 Analyse JD with AI';
    }
  });

  // Find candidates
  searchBtn?.addEventListener('click', async () => {
    if (!window._jdExtracted) return;
    searchBtn.disabled = true;
    searchBtn.innerHTML = '<span class="spinning">⟳</span> Opening LinkedIn...';
    await applyJDToSearch(window._jdExtracted);
    searchBtn.disabled = false;
    searchBtn.textContent = '📄→👥 Find Candidates';
  });

  function showJDStatus(msg, type) {
    if (!statusBox) return;
    statusBox.className = 'info-box '+type+' show';
    statusBox.textContent = msg;
  }

  function showJDResult(ext) {
    if (!tagsEl || !parsedRes) return;
    const tags = [];
    if (ext.title || ext.keywords) tags.push({ label:'💼 '+(ext.title||ext.keywords), cls:'' });
    if (ext.experience) tags.push({ label:'⏱ '+ext.experience, cls:'amber' });
    if (ext.locations && ext.locations.length > 1) {
      tags.push({ label:'📍 '+ext.locations.join(' / '), cls:'green' });
    } else if (ext.location) {
      tags.push({ label:'📍 '+ext.location, cls:'green' });
    }
    if (ext.education) tags.push({ label:'🎓 '+ext.education, cls:'' });
    (ext.topSkills||ext.skills||[]).slice(0,5).forEach(s => tags.push({ label:s, cls:'green' }));
    tagsEl.innerHTML = tags.map(t=>'<span class="jd-tag '+t.cls+'">'+t.label+'</span>').join('');
    parsedRes.style.display = 'block';
    if (statusBox) { statusBox.className = 'info-box'; statusBox.style.display = 'none'; }
    if (searchBtn) searchBtn.style.display = 'block';
    if (analyseBtn) analyseBtn.textContent = '🔄 Re-analyse';
  }
}


// ═══════════════════════════════════════════════════════════════
//  PLATFORM SEARCH
// ═══════════════════════════════════════════════════════════════
async function initPlatformSearch() {
  const searchBtn = document.getElementById('btn-platform-search');
  const status    = document.getElementById('platform-status');

  searchBtn?.addEventListener('click', async () => {
    const kw = document.getElementById('platform-keywords')?.value?.trim();
    if (!kw) {
      if(status){status.className='info-box warning show';status.textContent='Please enter keywords.';}
      return;
    }
    const selected = Array.from(document.querySelectorAll('.platform-chk:checked')).map(c=>c.value);
    if (!selected.length) {
      if(status){status.className='info-box warning show';status.textContent='Select at least one platform.';}
      return;
    }

    const URLS = {
      linkedin: 'https://www.linkedin.com/search/results/people/?keywords='+encodeURIComponent(kw)+'&origin=GLOBAL_SEARCH_HEADER',
      naukri:   'https://www.naukri.com/mnjuser/homepage',  // Recruiter login → RMS search
      indeed:   'https://resumes.indeed.com/search?q='+encodeURIComponent(kw)+'&l=India',
      hirist:   'https://www.hirist.tech/candidates?skill='+encodeURIComponent(kw),
      iimjobs:  'https://www.iimjobs.com/candidate/search-resume.php?keywords='+encodeURIComponent(kw),
      cutshort: 'https://cutshort.io/candidates?search='+encodeURIComponent(kw),
    };

    if(status){status.className='info-box info show';status.textContent='Opening '+selected.length+' platform(s)...';}
    addLog('Platform search: "'+kw+'" on '+selected.join(', '));

    for (let i=0; i<selected.length; i++) {
      const url = URLS[selected[i]];
      if (!url) continue;
      await chrome.tabs.create({ url, active: i === 0 });
      await new Promise(r=>setTimeout(r,400));
    }

    if(status){status.className='info-box success show';status.textContent='✓ Opened '+selected.length+' platform(s). Profiles will appear in Profiles tab.';}
  });

  // Export buttons for platform results
  document.getElementById('platform-export-csv')?.addEventListener('click', () => exportCSV());
  document.getElementById('platform-export-xlsx')?.addEventListener('click', () => exportXLSX());
}


// ═══════════════════════════════════════════════════════════════
//  PREDICTIVE SOURCING — Find candidates before they're active
// ═══════════════════════════════════════════════════════════════
async function initPredictiveSearch() {
  const searchBtn = document.getElementById('btn-predictive-search');
  const status    = document.getElementById('pred-status');

  searchBtn?.addEventListener('click', async () => {
    const role = document.getElementById('pred-role')?.value?.trim();
    if (!role) {
      if(status){status.className='info-box warning show';status.textContent='Please enter a role to search for.';}
      return;
    }

    const signals = Array.from(document.querySelectorAll('.signal-chk:checked')).map(c=>c.value);
    if (!signals.length) {
      if(status){status.className='info-box warning show';status.textContent='Select at least one signal.';}
      return;
    }

    searchBtn.disabled = true;
    searchBtn.innerHTML = '<span class="spinning">⟳</span> Building predictive search...';
    if(status){status.className='info-box info show';status.textContent='🎯 AI building predictive search query...';}

    try {
      // Build signal-based LinkedIn search query
      const query = await buildPredictiveQuery(role, signals);

      // Clear old profiles
      S.profiles = []; S.sent = 0; S.failed = 0;
      await chrome.storage.local.set({ profiles:[], sent:0, failed:0 });

      // Set up scraping
      const searchUrl = 'https://www.linkedin.com/search/results/people/?keywords='+encodeURIComponent(query)+'&origin=GLOBAL_SEARCH_HEADER';
      await chrome.storage.local.set({
        pendingScrape: {
          url: searchUrl,
          params: { keywords:query, location:'', degree:'123', experience:'', profileType:'', college:'', degreeType:'', company:'', salaryRange:'', diversityFilters:[] },
          page:1, isNewSearch:true, requestedAt: Date.now()
        }
      });
      S.lastSearchParams = { keywords:query };

      const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tabs[0]) await chrome.tabs.update(tabs[0].id, {url:searchUrl});

      addLog('Predictive search: "'+role+'" with signals: '+signals.join(', '));
      if(status){status.className='info-box success show';status.textContent='✓ Searching for predictive candidates! Results will appear in Profiles tab.';}

      setTimeout(() => showScreen('screen-profiles','slide-up'), 800);

    } catch(e) {
      if(status){status.className='info-box warning show';status.textContent='Error: '+e.message;}
    } finally {
      searchBtn.disabled = false;
      searchBtn.textContent = '🎯 Find Predictive Candidates';
    }
  });
}

async function buildPredictiveQuery(role, signals) {
  // Map signals to LinkedIn search keywords
  const SIGNAL_KEYWORDS = {
    recently_promoted:  '"promoted" OR "new role" OR "excited to share"',
    new_certification:  '"AWS certified" OR "completed certification" OR "passed exam" OR "certified in"',
    company_at_risk:    '"Byjus" OR "Paytm" OR "PhonePe" OR "Ola" OR "Unacademy"',
    tenure_2yr:         '',  // handled via experience filter
    profile_updated:    '',  // use OTW as proxy
    startup_employee:   '"Series A" OR "Series B" OR "seed stage" OR "early stage startup"',
  };

  // Build signal part
  const signalParts = signals
    .map(s => SIGNAL_KEYWORDS[s])
    .filter(Boolean);

  // Use Claude AI to build the best predictive query
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        model:'claude-sonnet-4-20250514',
        max_tokens:200,
        messages:[{
          role:'user',
          content:`Build a LinkedIn search query to find passive candidates for this role: "${role}"

Selected predictive signals: ${signals.join(', ')}

The query should find people who are LIKELY to switch jobs soon based on these signals.
Return ONLY the search query string (max 100 chars), nothing else.
Example: "Senior Data Scientist" "AWS certified" Bangalore`
        }]
      })
    });
    if (response.ok) {
      const data = await response.json();
      const q = data.content?.[0]?.text?.trim() || '';
      if (q && q.length > 5) return q;
    }
  } catch(e) {}

  // Fallback: combine role + top signals
  const rolePart = role.includes('"') ? role : '"'+role+'"';
  const sigPart = signalParts[0] || '';
  return sigPart ? rolePart + ' ' + sigPart : rolePart;
}



// ═══════════════════════════════════════════════════════════════
//  SALARY INTELLIGENCE MODULE
//  Merged from SalaryIntel v3 — bugs fixed
// ═══════════════════════════════════════════════════════════════
const SI_TIERS = {
  faang:   ['google','microsoft','amazon','meta','apple','nvidia','adobe','salesforce','oracle','intel','qualcomm','cisco','goldman sachs','jpmorgan','morgan stanley','american express','mckinsey','bcg','bain','walmart global tech','samsung research'],
  unicorn: ['razorpay','cred','zerodha','groww','phonepe','meesho','nykaa','swiggy','zomato','ola','byju','freshworks','zoho','browserstack','postman','chargebee','darwinbox','lenskart','cars24','policybazaar','paytm','delhivery','shiprocket','dream11','miro','juspay','setu','slice','jupiter'],
  mnc:     ['ibm','sap','vmware','servicenow','workday','zendesk','atlassian','mongodb','datadog','snowflake','stripe','paypal','visa','mastercard','hsbc','barclays','ubs','ey','pwc','kpmg','deloitte','accenture','capgemini','thoughtworks','publicis'],
  startup: ['flipkart','myntra','bigbasket','blinkit','zepto','practo','cure.fit','1mg','healthifyme','cashfree','instamojo','payu','pine labs','khatabook','okcredit','finbox','smallcase','indmoney'],
  service: ['tcs','infosys','wipro','hcl','tech mahindra','ltimindtree','mphasis','hexaware','persistent','cyient','coforge','birlasoft','kpit','cognizant','genpact','wns','exlservice','niit','mastech'],
};

const SI_SALARY = {
  faang:   {intern:[8,15],  fresher:[15,25], junior:[22,38], mid:[38,68],  senior:[62,100], lead:[88,150],  principal:[135,220], director:[195,350]},
  unicorn: {intern:[5,10],  fresher:[10,18], junior:[16,28], mid:[26,48],  senior:[42,72],  lead:[66,108],  principal:[96,158],  director:[145,248]},
  mnc:     {intern:[4,8],   fresher:[7,13],  junior:[12,22], mid:[20,38],  senior:[34,58],  lead:[52,88],   principal:[76,128],  director:[116,198]},
  startup: {intern:[3,7],   fresher:[6,12],  junior:[9,18],  mid:[16,30],  senior:[26,48],  lead:[42,72],   principal:[62,102],  director:[92,158]},
  service: {intern:[2,4],   fresher:[3,6],   junior:[5,10],  mid:[8,17],   senior:[14,27],  lead:[22,40],   principal:[34,58],   director:[52,88]},
  other:   {intern:[1,3],   fresher:[2,5],   junior:[3,7],   mid:[6,13],   senior:[10,20],  lead:[16,32],   principal:[26,48],   director:[40,72]},
};

const SI_CITY = {
  'bengaluru':1.00,'bangalore':1.00,'mumbai':0.95,'hyderabad':0.88,
  'pune':0.87,'delhi':0.92,'ncr':0.92,'gurgaon':0.90,'gurugram':0.90,
  'noida':0.88,'chennai':0.85,'kolkata':0.78,'ahmedabad':0.76,
};

const SI_TIER_L = {
  faang:'FAANG / Top GCC', unicorn:'Unicorn / Product', mnc:'MNC India Office',
  startup:'Indian Startup', service:'IT Services', other:'SME / Other',
};
const SI_SEN_L = {
  intern:'Intern / Trainee', fresher:'Fresher (0–1 yr)', junior:'Junior (1–3 yr)',
  mid:'Mid Level (3–6 yr)', senior:'Senior (6–9 yr)', lead:'Lead / Manager',
  principal:'Principal / Architect', director:'Director / VP',
};

function siGetTier(company) {
  const c = (company || '').toLowerCase();
  for (const [tier, list] of Object.entries(SI_TIERS)) {
    if (list.some(name => c.includes(name))) return tier;
  }
  return 'other';
}

// FIX: expanded getSen to handle SDE-2, L4, Staff, etc.
function siGetSen(title, expOverride) {
  if (expOverride) return expOverride;
  const t = (title || '').toLowerCase();
  if (/intern|trainee/.test(t))                                           return 'intern';
  if (/fresher|entry.?level|graduate|0.?year/.test(t))                   return 'fresher';
  if (/sde.?1|l3|level.?3|junior|\bjr\.?\b|associate(?!.*(senior|lead))/.test(t)) return 'junior';
  if (/principal|architect|distinguished|fellow|sde.?5|l7|l8/.test(t))   return 'principal';
  if (/director|\bvp\b|vice.?pres|head of|\bchief\b|cto|cpo|cfo|ceo/.test(t)) return 'director';
  if (/lead|manager|\bmgr\b|tech lead|team lead/.test(t))              return 'lead';
  if (/senior|\bsr\.?\b|staff|sde.?3|sde.?4|l5|l6|level.?5|level.?6/.test(t)) return 'senior';
  if (/sde.?2|l4|level.?4|mid/.test(t))                                  return 'mid';
  return 'mid';
}

function siGetCityMult(city) {
  const c = (city || '').toLowerCase();
  for (const [key, mult] of Object.entries(SI_CITY)) {
    if (c.includes(key)) return mult;
  }
  return 0.85;
}

function siFmt(n) { return n >= 100 ? (n/100).toFixed(1)+' Cr' : n+'L'; }

function siCalc(title, company, city, expOverride) {
  const tier = siGetTier(company);
  const sen  = siGetSen(title, expOverride);
  const mult = siGetCityMult(city);
  const row  = (SI_SALARY[tier] || SI_SALARY.other)[sen] || SI_SALARY.other.mid;
  return {
    min: Math.round(row[0] * mult),
    max: Math.round(row[1] * mult),
    tier, sen,
    tierLabel: SI_TIER_L[tier],
    senLabel:  SI_SEN_L[sen],
  };
}

// ── Salary Intel screen init ──────────────────────────────────
function initSalaryIntel() {
  // Check if on LinkedIn and update status badge
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
    const url  = tabs?.[0]?.url || '';
    const stat = document.getElementById('si-li-status');
    if (!stat) return;
    if (url.includes('linkedin.com')) {
      stat.className = 'screen-subtitle active';
      stat.textContent = '● Active on LinkedIn';
    } else {
      stat.className = 'screen-subtitle inactive';
      stat.textContent = '○ Open LinkedIn first';
    }
  });

  document.getElementById('btn-si-calc')?.addEventListener('click', () => {
    const title   = document.getElementById('si-title')?.value?.trim() || '';
    const company = document.getElementById('si-company')?.value?.trim() || '';
    const city    = document.getElementById('si-city')?.value || 'bengaluru';
    const exp     = document.getElementById('si-exp')?.value || '';

    if (!title && !company) {
      const card = document.getElementById('si-result-card');
      if (card) {
        card.style.display = 'block';
        card.style.borderColor = 'rgba(217,119,6,.3)';
        card.style.background = 'rgba(217,119,6,.06)';
        document.getElementById('si-res-range').textContent = '⚠️ Enter a title or company';
        document.getElementById('si-res-rows').innerHTML = '';
      }
      return;
    }

    const r = siCalc(title, company, city, exp || null);

    const cityEl  = document.getElementById('si-city');
    const cityLbl = cityEl?.options[cityEl?.selectedIndex]?.text || city;

    const card = document.getElementById('si-result-card');
    if (card) {
      card.style.display = 'block';
      card.style.borderColor = 'rgba(91,181,255,.25)';
      card.style.background = '#0D1117';
    }

    const rangeEl = document.getElementById('si-res-range');
    if (rangeEl) rangeEl.textContent = '₹' + siFmt(r.min) + ' – ₹' + siFmt(r.max) + ' PA';

    const rowsEl = document.getElementById('si-res-rows');
    if (rowsEl) {
      const rows = [
        ['Company Tier',  r.tierLabel],
        ['Seniority',     r.senLabel],
        ['City',          cityLbl + ' (' + Math.round(siGetCityMult(city)*100) + '% of BLR)'],
        ['Data Sources',  'Glassdoor · AmbitionBox · Levels.fyi'],
      ];
      rowsEl.innerHTML = rows.map(([l,v]) =>
        `<div class="si-res-row"><span>${l}</span><span>${v}</span></div>`
      ).join('');
    }
  });

  // Enter key triggers calc
  ['si-title','si-company'].forEach(id => {
    document.getElementById(id)?.addEventListener('keydown', e => {
      if (e.key === 'Enter') document.getElementById('btn-si-calc')?.click();
    });
  });
}

// ═══════════════════════════════════════════════════════════════
//  BOOT
// ═══════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {

  // Navigation
  initNavigation();

  // Init search screens
  initCloneSearch();
  initJDSearch();
  initPlatformSearch();
  initPredictiveSearch();

  // Smart search form wiring
  initSmartSearch();
  initSalaryIntel();

  // ── API Key management ────────────────────────────────────────
  (async () => {
    const stored = await chrome.storage.local.get('anthropicApiKey');
    const keyInput = document.getElementById('anthropic-key-input');
    if (stored.anthropicApiKey && keyInput) {
      keyInput.value = '••••••••' + stored.anthropicApiKey.slice(-8);
      keyInput.dataset.saved = '1';
    }
    document.getElementById('btn-save-api-key')?.addEventListener('click', async () => {
      const val = (keyInput?.value||'').trim();
      const st  = document.getElementById('api-key-status');
      const show = (msg, color) => { if(st){st.style.display='block';st.style.color=color;st.textContent=msg;} };

      // If field shows masked value, it's already saved
      if(val.startsWith('••')) {
        show('✓ Key already saved. Clear field and re-enter to change.','var(--ts)');
        return;
      }
      if(!val){
        show('⚠️ Paste your Anthropic API key first.','var(--amber)');
        return;
      }
      if(!val.startsWith('sk-ant-')){
        show('⚠️ Key must start with sk-ant-...','var(--red)');
        return;
      }
      await chrome.storage.local.set({ anthropicApiKey: val });
      if(keyInput){ keyInput.value='••••••••'+val.slice(-8); keyInput.dataset.saved='1'; }
      show('✓ Saved! Open any LinkedIn profile to test.','var(--accent)');
      setTimeout(()=>{ if(st) st.style.display='none'; }, 4000);
    });
    document.getElementById('btn-clear-api-key')?.addEventListener('click', async () => {
      await chrome.storage.local.remove('anthropicApiKey');
      if(keyInput) { keyInput.value=''; keyInput.dataset.saved='0'; }
      const st = document.getElementById('api-key-status');
      if(st){st.style.display='block';st.style.color='var(--ts)';st.textContent='API key cleared.';}
      setTimeout(()=>{ if(st) st.style.display='none'; }, 2000);
    });
    // Allow editing saved key
    keyInput?.addEventListener('focus', () => {
      if(keyInput.dataset.saved==='1') { keyInput.value=''; keyInput.dataset.saved='0'; }
    });
  })();

  // Load state
  await syncFromStorage();
  await checkPlanStatus();
  updatePlanBar();
  updateAllCounts();
  renderProfiles();
  renderLog();
  checkLoginState();

  // On popup open: if profiles exist from previous search, show them immediately
  if (S.profiles.length > 0) {
    // Update scrape-info count
    const si = document.getElementById('scrape-info');
    const siC = document.getElementById('si-count');
    if (si) si.classList.add('show');
    if (siC) siC.textContent = S.profiles.length + ' profiles found';
    // Navigate to profiles screen after short delay
    setTimeout(() => {
      showScreen('screen-profiles', 'slide-up');
      renderProfiles();
      updateAllCounts();
    }, 200);
  }

  // On popup open — show searching indicator if scrape is in progress
  const _pendingCheck = await chrome.storage.local.get('pendingScrape');
  if (_pendingCheck.pendingScrape && (Date.now() - _pendingCheck.pendingScrape.requestedAt) < 120000) {
    const kw = _pendingCheck.pendingScrape.params?.keywords || '';
    showStatus('⏳ Collecting profiles for "' + kw + '"... Reopen PingIN in a few seconds.', 'info');
  }

  // Poll every 2s — picks up profiles after service worker scrapes
  let _lastProfileCount = S.profiles.length;
  setInterval(async () => {
    try {
      const d = await chrome.storage.local.get(['profiles','lastSearchParams','pendingScrape']);
      const newCount = (d.profiles || []).length;

      if (newCount !== _lastProfileCount) {
        _lastProfileCount = newCount;
        S.profiles = d.profiles || [];
        if (d.lastSearchParams) S.lastSearchParams = d.lastSearchParams;
        renderProfiles();
        updateAllCounts();
        updateStats();
        if (newCount > 0) {
          const si  = document.getElementById('scrape-info');
          const siC = document.getElementById('si-count');
          if (si)  si.classList.add('show');
          if (siC) siC.textContent = newCount + ' profiles found';
          showScreen('screen-profiles', 'slide-up');
          showStatus('✓ ' + newCount + ' profiles collected! Click any profile to open on LinkedIn.', 'success');
        }
      }
    } catch(e) {}
  }, 2000);

  // SCRAPE_DONE — fires if popup is open when scrape completes
  chrome.runtime.onMessage.addListener(async (msg) => {
    if (msg.action === 'SCRAPE_DONE') {
      await syncFromStorage();
      if (!S.lastSearchParams?.keywords) {
        const stored = await chrome.storage.local.get('lastSearchParams');
        if (stored.lastSearchParams) S.lastSearchParams = stored.lastSearchParams;
      }
      renderProfiles();
      updateAllCounts();
      updateStats();
      const si = document.getElementById('scrape-info');
      const siCount = document.getElementById('si-count');
      if (si) si.classList.add('show');
      if (siCount) siCount.textContent = msg.total + ' profiles found';
      addLog('✓ Scraped: ' + msg.added + ' new · ' + msg.total + ' total (page ' + msg.page + ')');
      if (msg.total > 0) setTimeout(() => showScreen('screen-profiles','slide-up'), 800);
    }
  });

  // Today's search count stat
  const hist = (await chrome.storage.local.get('history'))?.history || [];
  const today = new Date().toDateString();
  const todayCount = hist.filter(h => new Date(h.searchedAt).toDateString() === today).length;
  const statSearches = document.getElementById('stat-searches');
  if (statSearches) statSearches.textContent = todayCount;
});

// ═══════════════════════════════════════════════════════════════
//  SMART SEARCH INIT
// ═══════════════════════════════════════════════════════════════
function initSmartSearch() {
  // Keyword dropdown
  const kwInput = document.getElementById('s-keywords');
  const kwDd = document.getElementById('kw-dropdown');
  if (kwInput && kwDd) {
    kwInput.addEventListener('input', () => {
      const q = kwInput.value.trim();
      if (!q || q.length < 2) { kwDd.style.display='none'; return; }
      if (typeof KW_SUGGESTIONS !== 'undefined') {
        const matches = KW_SUGGESTIONS.filter(s => s.toLowerCase().includes(q.toLowerCase())).slice(0,6);
        if (matches.length) {
          kwDd.innerHTML = matches.map(s => '<div class="kw-dd-item"><div class="kw-dd-kw">'+s+'</div></div>').join('');
          kwDd.style.display = 'block';
          kwDd.querySelectorAll('.kw-dd-item').forEach(item => {
            item.addEventListener('click', () => { kwInput.value = item.querySelector('.kw-dd-kw').textContent; kwDd.style.display='none'; });
          });
        } else kwDd.style.display='none';
      }
    });
    document.addEventListener('click', e => { if(!kwInput.contains(e.target)) kwDd.style.display='none'; });
  }

  // Bool chips
  document.getElementById('bool-and')?.addEventListener('click', () => insertKeyword(' AND '));
  document.getElementById('bool-or')?.addEventListener('click',  () => insertKeyword(' OR '));
  document.getElementById('bool-not')?.addEventListener('click', () => insertKeyword(' NOT '));
  document.getElementById('bool-quote')?.addEventListener('click', () => wrapInQuotes());
  document.getElementById('bool-paren')?.addEventListener('click', () => insertKeyword('('));

  // Company search
  const coInput = document.getElementById('s-company');
  const coDd = document.getElementById('company-dropdown');
  if (coInput && coDd) {
    coInput.addEventListener('input', () => filterCompanyDropdown(coInput.value));
    coInput.addEventListener('focus', () => filterCompanyDropdown(coInput.value));
    coInput.addEventListener('blur', () => setTimeout(()=>{ coDd.style.display='none'; },200));
  }

  // College search
  const collInput = document.getElementById('college-search');
  if (collInput) {
    collInput.addEventListener('input', () => filterDropdown(collInput.value,'s-college','college-dropdown'));
    collInput.addEventListener('focus', () => filterDropdown(collInput.value,'s-college','college-dropdown'));
    collInput.addEventListener('blur', () => setTimeout(()=>{ document.getElementById('college-dropdown').style.display='none'; },200));
  }

  // Degree search
  const degInput = document.getElementById('deg-search');
  if (degInput) {
    degInput.addEventListener('input', () => filterDropdown(degInput.value,'s-degree-type','deg-dropdown'));
    degInput.addEventListener('focus', () => filterDropdown(degInput.value,'s-degree-type','deg-dropdown'));
    degInput.addEventListener('blur', () => setTimeout(()=>{ document.getElementById('deg-dropdown').style.display='none'; },200));
  }

  // Profile type — enable immediately
  const ptEl = document.getElementById('s-profile-type');
  if (ptEl) ptEl.disabled = false;
  document.getElementById('s-profile-type')?.addEventListener('change', updateProfileTypeState);

  // Diversity toggle
  const divToggle = document.getElementById('diversity-toggle');
  const divSub = document.getElementById('diversity-sub');
  divToggle?.addEventListener('change', () => {
    if (divSub) divSub.style.display = divToggle.checked ? 'block' : 'none';
  });

  // Salary info
  document.getElementById('s-salary-range')?.addEventListener('change', function() {
    const box = document.getElementById('salary-info-box');
    if (!box) return;
    if (!this.value) { box.style.display='none'; return; }
    const info = getSalaryInfo(this.value);
    if (info) {
      box.innerHTML = '<span class="s-range">'+info.range+'</span>'+info.tip;
      box.style.display = 'block';
    }
  });

  // Search button
  document.getElementById('btn-search')?.addEventListener('click', startSearch);

  // Save search
  document.getElementById('btn-save-search')?.addEventListener('click', saveCurrentSearch);

  // Next page
  document.getElementById('btn-next-page')?.addEventListener('click', async () => {
    S.currentPage = (S.currentPage||1) + 1;
    const p = S.lastSearchParams;
    const url = buildSearchUrl(p.keywords,p.location,p.degree,p.experience,p.profileType,p.college,p.company,S.currentPage,p.salaryRange||'',p.diversityFilters||[]);
    await chrome.storage.local.set({ pendingScrape:{ url, params:p, page:S.currentPage, isNewSearch:false, requestedAt:Date.now() } });
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tabs[0]) chrome.tabs.update(tabs[0].id,{url});
    addLog('Scraping page '+S.currentPage+'...');
  });

  // Status bar exports
  document.getElementById('sb-export-btn')?.addEventListener('click', exportCSV);

  // Smart screen exports
  document.getElementById('smart-export-btn')?.addEventListener('click', exportCSV);
}

// Insert keyword helper
function insertKeyword(kw) {
  const el = document.getElementById('s-keywords');
  if (!el) return;
  const pos = el.selectionStart || el.value.length;
  el.value = el.value.slice(0,pos) + kw + el.value.slice(pos);
  el.focus();
  el.setSelectionRange(pos+kw.length, pos+kw.length);
}

function wrapInQuotes() {
  const el = document.getElementById('s-keywords');
  if (!el) return;
  const start = el.selectionStart, end = el.selectionEnd;
  if (start !== end) {
    el.value = el.value.slice(0,start)+'"'+el.value.slice(start,end)+'"'+el.value.slice(end);
  } else {
    insertKeyword('"');
  }
}

// Salary info helper
function getSalaryInfo(val) {
  const MAP = {
    'fresher':      { range:'₹3–8 LPA',  tip:'Entry level · 0–2 yrs · Service/Startup companies' },
    'junior_startup':{ range:'₹8–18 LPA', tip:'Junior · 2–5 yrs · Funded startups (Razorpay, Swiggy)' },
    'junior_product':{ range:'₹12–25 LPA',tip:'Product companies · SDE-1/2 level · 2–5 yrs' },
    'mid_service':  { range:'₹10–20 LPA', tip:'Mid level · 5–8 yrs · TCS/Infosys/Wipro' },
    'mid_product':  { range:'₹20–40 LPA', tip:'Mid level · 5–8 yrs · Flipkart/Freshworks/Zerodha' },
    'mid_gcc':      { range:'₹15–30 LPA', tip:'GCC roles · Google/Amazon/Cisco · 5–8 yrs' },
    'senior_product':{ range:'₹35–65 LPA',tip:'Senior · 8–12 yrs · Product/unicorn companies' },
    'senior_gcc':   { range:'₹40–80 LPA', tip:'GCC senior · 8–12 yrs · FAANG India' },
    'lead_manager': { range:'₹50–100 LPA',tip:'Lead/Manager · 10–15 yrs · Top companies' },
    'director_vp':  { range:'₹80–200 LPA',tip:'Director/VP · 15+ yrs · Large enterprises/startups' },
  };
  return MAP[val] || null;
}

// ═══════════════════════════════════════════════════════════════
//  PROFILES SCREEN INIT
// ═══════════════════════════════════════════════════════════════
async function renderLog() {
  const el = document.getElementById('activity-log');
  if (!el) return;
  if (!S.log || !S.log.length) {
    el.innerHTML = '<div class="log-empty">No activity yet.</div>';
    return;
  }
  el.innerHTML = [...S.log].reverse().slice(0,20).map(entry =>
    '<div class="log-entry"><span class="log-time">' + (entry.time||'') + '</span>' + (entry.msg||entry) + '</div>'
  ).join('');
}

// Wire profiles screen buttons on load
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('btn-export-csv')?.addEventListener('click', exportCSV);
  document.getElementById('btn-export-xlsx')?.addEventListener('click', exportXLSX);
  document.getElementById('btn-clear-profiles')?.addEventListener('click', async () => {
    if (confirm('Clear all '+S.profiles.length+' profiles?')) {
      await clearProfiles();
      renderProfiles();
      updateAllCounts();
    }
  });

  // Smart Outreach button
  document.getElementById('btn-open-campaign')?.addEventListener('click', openCampaign);
  document.getElementById('btn-open-campaign')?.addEventListener('mouseover', function(){ this.style.opacity='.88'; });
  document.getElementById('btn-open-campaign')?.addEventListener('mouseout',  function(){ this.style.opacity='1'; });

  // ── Profile card clicks — event delegation (MV3 safe) ──────
  // Main profiles list
  document.getElementById('profiles-list')?.addEventListener('click', e => {
    const card = e.target.closest('.profile-item');
    if (!card) return;
    const url = card.dataset.url;
    if (url && url.startsWith('http')) {
      chrome.tabs.create({ url, active: true });
    } else if (url) {
      chrome.tabs.create({ url: 'https://www.linkedin.com' + url, active: true });
    }
  });

  // Top profiles banner
  document.getElementById('top-profiles-list')?.addEventListener('click', e => {
    const card = e.target.closest('.top-profile-card');
    if (!card) return;
    const url = card.dataset.url;
    if (url && url.startsWith('http')) {
      chrome.tabs.create({ url, active: true });
    } else if (url) {
      chrome.tabs.create({ url: 'https://www.linkedin.com' + url, active: true });
    }
  });

  // Filter buttons
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderProfiles(btn.dataset.filter);
    });
  });

  // Settings screen
  document.getElementById('btn-activate-key')?.addEventListener('click', activateLicenseKey);
  document.getElementById('set-random-delay')?.addEventListener('change', saveSettings);
  document.getElementById('set-biz-hours')?.addEventListener('change', saveSettings);
  document.getElementById('set-skip-connected')?.addEventListener('change', saveSettings);
  document.getElementById('btn-clear-log')?.addEventListener('click', async () => {
    S.log = [];
    await chrome.storage.local.set({ log:[] });
    renderLog();
  });
});

// License key activation
async function activateLicenseKey() {
  const input = document.getElementById('license-key-input');
  const status = document.getElementById('key-status');
  const key = (input?.value||'').trim().toUpperCase();

  if (!key.match(/^PING-[A-Z]{2}-[A-Z0-9]{4}-[A-Z0-9]{4}$/)) {
    if(status){status.style.display='block';status.style.background='rgba(220,38,38,.1)';status.style.color='var(--red)';status.textContent='Invalid key format. Expected: PING-XX-XXXX-XXXX';}
    return;
  }

  const planMap = { FR:'free', ST:'starter', PR:'pro', AN:'annual' };
  const daysMap = { FR:5, ST:15, PR:30, AN:365 };
  const msgMap  = { FR:5, ST:50, PR:50, AN:50 };
  const planCode = key.split('-')[1];
  const plan  = planMap[planCode] || 'pro';
  const days  = daysMap[planCode] || 30;
  const msgs  = msgMap[planCode]  || 50;
  const expiry = new Date(Date.now() + days*86400000).toISOString();

  await chrome.storage.local.set({ licenseKey:key, planStatus:plan, planExpiry:expiry, dailyLimit:msgs });
  S.plan = plan;
  S.planExpiry = expiry;
  S.dailyLimit = msgs;

  const box = document.getElementById('current-key-box');
  const keyVal = document.getElementById('current-key-val');
  const planVal = document.getElementById('current-plan-val');
  if(box) box.style.display='block';
  if(keyVal) keyVal.textContent = key;
  if(planVal) planVal.textContent = plan.charAt(0).toUpperCase()+plan.slice(1)+' · '+days+' days · '+msgs+' msgs/day';

  if(status){status.style.display='block';status.style.background='rgba(0,196,154,.1)';status.style.color='var(--accent)';status.textContent='✓ License activated! Plan: '+plan.charAt(0).toUpperCase()+plan.slice(1);}
  updatePlanBar();
}

async function saveSettings() {
  S.settings.randomDelay   = document.getElementById('set-random-delay')?.checked || false;
  S.settings.bizHours      = document.getElementById('set-biz-hours')?.checked || false;
  S.settings.skipConnected = document.getElementById('set-skip-connected')?.checked || false;
  await chrome.storage.local.set({ settings: S.settings });
}

// ── Smart Outreach — open campaign page ──────────
async function openCampaign() {
  if (!S.profiles || !S.profiles.length) {
    alert('No profiles yet. Run a search first to collect profiles.');
    return;
  }
  // Update button label with count
  const label = document.getElementById('campaign-btn-label');
  if (label) label.textContent = `Smart Outreach · ${S.profiles.length} profiles`;
  // Navigate to in-popup campaign screen
  initCampaignScreen();
  showScreen('screen-campaign', 'slide-in');
}

// ══════════════════════════════════════════════════════════════
//  SMART OUTREACH — IN-POPUP CAMPAIGN (Screen 5)
//  No new tabs. Service worker navigates LinkedIn tab directly.
// ══════════════════════════════════════════════════════════════

const CMP = {
  type:      'connect',
  limit:     20,
  running:   false,
  paused:    false,
  pollTimer: null,
};

const CMP_TEMPLATES = {
  connect: 'Hi {{first_name}}, I came across your profile at {{company}} and have an exciting opportunity that matches your background. Would love to connect!\n\nBest,\nRecruiter',
  message: 'Hi {{first_name}}, hope you\'re doing well. I noticed your experience at {{company}} and wanted to share an exciting opportunity with you. Would love to chat!\n\nBest,\nRecruiter',
};

let _cmpInited = false; // prevent duplicate listeners

function initCampaignScreen() {
  const count = S.profiles.length;

  // Header count
  const hdr = document.getElementById('cmp-hdr-count');
  if (hdr) hdr.textContent = count + ' candidate' + (count !== 1 ? 's' : '');

  // Default message
  const ta = document.getElementById('cmp-message');
  if (ta && !ta.value.trim()) {
    ta.value = CMP_TEMPLATES.connect;
    cmpUpdateCharCount();
  }

  // Reset to setup view if not running
  const setup   = document.getElementById('cmp-setup');
  const running = document.getElementById('cmp-running');
  if (setup)   setup.style.display   = CMP.running ? 'none' : 'block';
  if (running) running.classList.toggle('show', CMP.running);

  // ── Wire all buttons ONCE only ──────────────────────────────
  if (_cmpInited) {
    // Already wired — just resume polling if running
    if (CMP.running) startCmpPolling();
    return;
  }
  _cmpInited = true;

  // Back button
  document.getElementById('cmp-back-btn')?.addEventListener('click', () => {
    if (CMP.running) {
      if (!confirm('Campaign is running. Go back? Campaign continues in background.')) return;
    }
    showScreen('screen-profiles', 'slide-back');
  });

  // Type buttons
  document.querySelectorAll('.cmp-type-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const t = btn.dataset.cmpType;
      if (t === 'sequence') { alert('Sequence campaigns are available on the Annual plan.\nUpgrade at pingin.in/pricing'); return; }
      CMP.type = t;
      document.querySelectorAll('.cmp-type-btn').forEach(b => b.classList.remove('on'));
      btn.classList.add('on');
      const msgTa = document.getElementById('cmp-message');
      if (msgTa && CMP_TEMPLATES[t]) { msgTa.value = CMP_TEMPLATES[t]; cmpUpdateCharCount(); }
    });
  });

  // Limit buttons
  document.querySelectorAll('.cmp-limit-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      CMP.limit = parseInt(btn.dataset.cmpLimit) || 20;
      document.querySelectorAll('.cmp-limit-btn').forEach(b => b.classList.remove('on'));
      btn.classList.add('on');
    });
  });

  // Variable chips
  document.querySelectorAll('.cmp-var').forEach(btn => {
    btn.addEventListener('click', () => cmpInsertVar(btn.dataset.var || ''));
  });

  // Char count
  document.getElementById('cmp-message')?.addEventListener('input', cmpUpdateCharCount);

  // Launch / pause / resume / stop
  document.getElementById('cmp-launch-btn')?.addEventListener('click', cmpLaunch);
  document.getElementById('cmp-btn-pause')?.addEventListener('click',  cmpPause);
  document.getElementById('cmp-btn-resume')?.addEventListener('click', cmpResume);
  document.getElementById('cmp-btn-stop')?.addEventListener('click',   cmpStop);

  // If already running — show running view and start polling
  if (CMP.running) startCmpPolling();
}

function cmpUpdateCharCount() {
  const ta = document.getElementById('cmp-message');
  const el = document.getElementById('cmp-char-count');
  if (!ta || !el) return;
  const n = ta.value.length;
  el.textContent = n + ' / 300';
  el.style.color = n > 280 ? 'var(--amber)' : 'var(--tm)';
}

function cmpInsertVar(v) {
  const ta = document.getElementById('cmp-message');
  if (!ta) return;
  const s = ta.selectionStart, e = ta.selectionEnd;
  ta.value = ta.value.slice(0, s) + v + ta.value.slice(e);
  ta.selectionStart = ta.selectionEnd = s + v.length;
  ta.focus();
  cmpUpdateCharCount();
}

async function cmpLaunch() {
  const template = document.getElementById('cmp-message')?.value.trim() || '';
  if (CMP.type !== 'visit' && !template) {
    alert('Please write a message before launching.');
    return;
  }
  if (!S.profiles.length) {
    alert('No profiles to send to. Collect profiles first.');
    return;
  }

  // Save profiles to storage for service worker
  await chrome.storage.local.set({
    profiles: S.profiles.map(p => ({ ...p, status: 'pending' })),
  });

  // Start campaign via service worker
  let resp;
  try {
    resp = await chrome.runtime.sendMessage({
      action:      'START_CAMPAIGN',
      count:       Math.min(S.profiles.length, CMP.limit),
      message:     template,
      delay:       60,
      randomDelay: true,
    });
  } catch(e) {
    alert('Error: ' + e.message); return;
  }

  if (!resp?.ok) {
    alert('Could not start: ' + (resp?.error || 'Unknown error'));
    return;
  }

  CMP.running = true;
  CMP.paused  = false;

  // Switch to running view
  const setup   = document.getElementById('cmp-setup');
  const running = document.getElementById('cmp-running');
  if (setup)   setup.style.display = 'none';
  if (running) running.classList.add('show');

  cmpLog('Campaign started · ' + resp.total + ' candidates · ' + CMP.type, 'ok');
  cmpLog('LinkedIn is connecting in background — check Invitations > Sent to verify', 'ok');
  startCmpPolling();
}

async function cmpPause() {
  try {
    await chrome.runtime.sendMessage({ action: 'PAUSE_CAMPAIGN' });
    CMP.paused = true;
    document.getElementById('cmp-btn-pause').style.display  = 'none';
    document.getElementById('cmp-btn-resume').style.display = 'flex';
    const dot = document.getElementById('cmp-action-dot');
    if (dot) dot.style.display = 'none';
    cmpLog('Paused — LinkedIn actions stopped', 'warn');
  } catch(e) {}
}

async function cmpResume() {
  try {
    await chrome.runtime.sendMessage({ action: 'PAUSE_CAMPAIGN' });
    CMP.paused = false;
    document.getElementById('cmp-btn-pause').style.display  = 'flex';
    document.getElementById('cmp-btn-resume').style.display = 'none';
    const dot = document.getElementById('cmp-action-dot');
    if (dot) dot.style.display = 'block';
    cmpLog('Resumed', 'ok');
  } catch(e) {}
}

async function cmpStop() {
  if (!confirm('Stop campaign? Remaining candidates will not be contacted.')) return;
  try { await chrome.runtime.sendMessage({ action: 'STOP_CAMPAIGN' }); } catch(e) {}
  CMP.running = false; CMP.paused = false;
  if (CMP.pollTimer) { clearInterval(CMP.pollTimer); CMP.pollTimer = null; }
  cmpLog('Campaign stopped by user', 'warn');

  // Show restart button
  const setup   = document.getElementById('cmp-setup');
  const running = document.getElementById('cmp-running');
  if (setup)   setup.style.display = 'block';
  if (running) running.classList.remove('show');

  const lb = document.getElementById('cmp-launch-btn');
  if (lb) { lb.disabled = false; lb.innerHTML = '▶&nbsp; Start Outreach'; }
}

// ── Poll service worker for live status ───────────────────────
function startCmpPolling() {
  if (CMP.pollTimer) clearInterval(CMP.pollTimer);
  CMP.pollTimer = setInterval(async () => {
    try {
      const resp = await chrome.runtime.sendMessage({ action: 'GET_STATUS' });
      if (!resp?.ok) return;

      const profiles = resp.profiles || [];
      const camp     = resp.campaign || {};
      const sent     = profiles.filter(p => p.status === 'sent').length;
      const failed   = profiles.filter(p => p.status === 'failed').length;
      const pending  = profiles.filter(p => ['pending','queued'].includes(p.status)).length;
      const total    = profiles.length;
      const done     = sent + failed;
      const pct      = total > 0 ? Math.round((done / total) * 100) : 0;
      const daily    = resp.dailySent || 0;

      // Status banner
      const sBanner = document.getElementById('cmp-status-banner');
      const sDot    = document.getElementById('cmp-status-dot');
      const sTxt    = document.getElementById('cmp-status-txt');
      const sSub    = document.getElementById('cmp-status-sub');
      if (camp.paused) {
        if (sBanner) sBanner.style.background = 'rgba(217,119,6,.06)';
        if (sBanner) sBanner.style.borderBottomColor = 'rgba(217,119,6,.15)';
        if (sDot) { sDot.className = 'cmp-status-dot paused'; }
        if (sTxt) { sTxt.className = 'cmp-status-txt paused'; sTxt.textContent = 'Paused'; }
        if (sSub) sSub.textContent = 'Campaign is paused';
      } else if (done === total && total > 0 && !camp.running) {
        if (sBanner) sBanner.style.background = 'rgba(0,119,181,.06)';
        if (sBanner) sBanner.style.borderBottomColor = 'rgba(0,119,181,.15)';
        if (sDot) { sDot.className = 'cmp-status-dot done'; }
        if (sTxt) { sTxt.className = 'cmp-status-txt done'; sTxt.textContent = 'Complete'; }
        if (sSub) sSub.textContent = sent + ' connections sent successfully';
      } else {
        if (sBanner) sBanner.style.background = 'rgba(0,212,170,.06)';
        if (sBanner) sBanner.style.borderBottomColor = 'rgba(0,212,170,.15)';
        if (sDot) { sDot.className = 'cmp-status-dot'; }
        if (sTxt) { sTxt.className = 'cmp-status-txt'; sTxt.textContent = 'Running'; }
        if (sSub) sSub.textContent = 'Connecting in background tabs';
      }

      // Progress
      const pf = document.getElementById('cmp-prog-fill');
      const pp = document.getElementById('cmp-prog-pct');
      const pl = document.getElementById('cmp-prog-label');
      const pe = document.getElementById('cmp-prog-eta');
      if (pf) pf.style.width = pct + '%';
      if (pp) pp.textContent = pct + '%';
      if (pl) pl.textContent = done + ' of ' + total + ' actioned';
      if (pe) {
        const rem = pending;
        const minsLeft = rem > 0 ? Math.ceil((rem * 60) / 60) : 0;
        pe.textContent = minsLeft > 0 ? '~' + minsLeft + ' min remaining' : done === total ? 'Complete' : 'Starting...';
      }

      // Stats
      const ss = document.getElementById('cmp-stat-sent');
      const sf = document.getElementById('cmp-stat-failed');
      const sp = document.getElementById('cmp-stat-pending');
      if (ss) ss.textContent = sent;
      if (sf) sf.textContent = failed;
      if (sp) sp.textContent = pending;

      // Safety meter
      const sfill = document.getElementById('cmp-safety-fill');
      const sval  = document.getElementById('cmp-safety-val');
      const safePct = Math.min((daily / 25) * 100, 100);
      if (sfill) {
        sfill.style.width = safePct + '%';
        sfill.style.background = safePct >= 90 ? 'var(--red)' : safePct >= 75 ? 'var(--amber)' : 'var(--accent)';
      }
      if (sval) {
        sval.textContent = daily + '/25';
        sval.style.color = safePct >= 75 ? 'var(--amber)' : 'var(--accent)';
      }

      // Current candidate being actioned
      const queued = profiles.find(p => p.status === 'queued');
      const dot    = document.getElementById('cmp-action-dot');
      if (queued) {
        const ini  = (queued.name||'?').split(' ').map(w=>w[0]||'').join('').slice(0,2).toUpperCase();
        const sub  = [queued.role, queued.company].filter(Boolean).join(' · ');
        const nav  = document.getElementById('cmp-now-name');
        const nav2 = document.getElementById('cmp-now-sub-text');
        const nav3 = document.getElementById('cmp-now-av');
        if (nav)  nav.textContent  = queued.name || 'Unknown';
        if (nav2) nav2.textContent = sub || '—';
        if (nav3) nav3.textContent = ini;
        if (dot)  dot.style.display = 'block';
      } else if (done === total && total > 0) {
        const nav  = document.getElementById('cmp-now-name');
        const nav2 = document.getElementById('cmp-now-sub-text');
        const nav3 = document.getElementById('cmp-now-av');
        if (nav)  nav.textContent  = '✓ All done!';
        if (nav2) nav2.textContent = sent + ' connections sent · ' + failed + ' failed';
        if (nav3) nav3.textContent = '✓';
        if (dot)  dot.style.display = 'none';
      }

      // Campaign finished
      if (!camp.running && CMP.running && total > 0 && done === total) {
        CMP.running = false;
        clearInterval(CMP.pollTimer);
        cmpLog('✓ Campaign complete · ' + sent + ' sent · ' + failed + ' failed', 'ok');
        cmpLog('Verify: LinkedIn › My Network › Invitations › Sent', 'ok');
        const lb = document.getElementById('cmp-launch-btn');
        if (lb) { lb.disabled = true; lb.innerHTML = '✓ Campaign Complete'; }
        // Show setup panel again after 2s so user can restart
        setTimeout(() => {
          const setup = document.getElementById('cmp-setup');
          if (setup) setup.style.display = 'block';
        }, 2000);
      }

    } catch(e) {}
  }, 2500);
}

function cmpLog(msg, type) {
  const list = document.getElementById('cmp-log-list');
  if (!list) return;
  // Clear placeholder
  if (list.children.length === 1 && list.children[0].textContent === 'Waiting to start...') {
    list.innerHTML = '';
  }
  const el = document.createElement('div');
  el.className = 'cmp-log-item' + (type === 'ok' ? ' ok' : type === 'warn' ? ' warn' : type === 'err' ? ' err' : '');
  const t = new Date().toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
  el.innerHTML = '<span class="cmp-log-time">' + t + '</span><span>' + msg + '</span>';
  list.insertBefore(el, list.firstChild);
  while (list.children.length > 20) list.removeChild(list.lastChild);
}
