'use strict';

// ═══════════════════════════════════════════════════════════════
//  PingIN Unified Content Script v4
//  Profile Scraper + Salary Intelligence
// ═══════════════════════════════════════════════════════════════

// ── PingIN: Profile scraping ─────────────────────────────────
let lastUrl = location.href;

function checkForResults() {
  const url = location.href;
  if (url === lastUrl) return;
  lastUrl = url;
  if (url.includes('linkedin.com/search/results/people')) {
    setTimeout(() => {
      chrome.runtime.sendMessage({ action: 'PAGE_CHANGED', url }).catch(() => {});
    }, 3000);
  }
}

const _observer = new MutationObserver(() => {
  checkForResults();
  // Re-run salary intel on SPA navigation
  if (location.href !== lastUrl) siRun();
});
_observer.observe(document.body, { childList: true, subtree: true });

function scrapeProfilesFromPage() {
  const results = [];
  try {
    const cards = document.querySelectorAll(
      '.reusable-search__result-container, .search-results-container li, [data-view-name="search-entity-result-universal-template"]'
    );
    cards.forEach(card => {
      try {
        const nameEl = card.querySelector(
          '.entity-result__title-text a span[aria-hidden="true"], .entity-result__title span[aria-hidden="true"], a.app-aware-link span[aria-hidden="true"]'
        );
        const name = nameEl?.textContent?.trim();
        if (!name || name.toLowerCase().includes('linkedin member')) return;

        const linkEl = card.querySelector('a[href*="/in/"]');
        const profileUrl = linkEl ? 'https://www.linkedin.com' + new URL(linkEl.href).pathname : null;
        if (!profileUrl) return;

        const subEl = card.querySelector('.entity-result__primary-subtitle');
        const role = subEl?.textContent?.trim() || '';
        const secEl = card.querySelector('.entity-result__secondary-subtitle');
        const company = secEl?.textContent?.trim() || '';
        const locEl = card.querySelector('.entity-result__tertiary-subtitle, .entity-result__simple-insight-text');
        const city = locEl?.textContent?.trim() || '';
        const photoEl = card.querySelector('img.presence-entity__image, .entity-result__universal-image img');
        const photo = photoEl?.src || '';
        const isOTW = card.querySelector('[aria-label*="Open to work"], .open-to-work-badge, .pv-member-badge--opentowork') !== null;
        const degEl = card.querySelector('.entity-result__badge-text, .dist-value, [class*="distance"]');
        const degree = degEl?.textContent?.trim() || '';
        results.push({ name, profileUrl, role, company, city, photo, isOTW, degree, status: 'pending', scrapedAt: new Date().toISOString() });
      } catch(e) {}
    });
  } catch(e) {}
  return results;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'SCRAPE_PAGE') {
    sendResponse({ ok: true, profiles: scrapeProfilesFromPage() });
  }
  return true;
});

if (location.href.includes('linkedin.com/search/results/people')) {
  setTimeout(() => {
    const count = scrapeProfilesFromPage().length;
    if (count > 0) chrome.runtime.sendMessage({ action: 'RESULTS_READY', count }).catch(() => {});
  }, 3000);
}

// Salary Intelligence — Coming Soon
