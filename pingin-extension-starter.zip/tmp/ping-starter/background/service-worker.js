/**
 * PingIN Service Worker v3
 * Handles: campaign loop + auto-scraping after search
 */
'use strict';

// ── Install ──────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  if (reason === 'install') {
    await chrome.storage.local.set({
      profiles: [], log: [], sent: 0, failed: 0,
      dailySent: 0, dailyReset: new Date().toDateString(),
      campaign: { running:false, paused:false, index:0, total:0, message:'' },
      settings: { dailyLimit:50, delaySeconds:45, randomDelay:true, bizHours:false, skipConnected:true, weeklyLimit:300 }
    });
  }
  chrome.alarms.create('dailyReset', { when: nextMidnightIST(), periodInMinutes: 1440 });
});

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name === 'dailyReset') {
    await chrome.storage.local.set({ dailySent: 0, dailyReset: new Date().toDateString() });
  }
  if (alarm.name === 'campaignTick') await campaignTick();
});

// ── Tab listener: auto-scrape when LinkedIn search page loads ────────────────
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status !== 'complete') return;
  if (!tab.url?.includes('linkedin.com/search/results/people')) return;

  const data = await chrome.storage.local.get('pendingScrape');
  const ps = data.pendingScrape;
  if (!ps) return;
  if ((Date.now() - ps.requestedAt) > 180000) {
    await chrome.storage.local.remove('pendingScrape');
    return;
  }

  swLog('Auto-scrape triggered for: ' + (ps.params?.keywords || ''));

  // Try scraping — attempt 1 after 3.5s, attempt 2 after 7s if needed
  for (let attempt = 1; attempt <= 2; attempt++) {
    await sleep(attempt === 1 ? 3500 : 3500);
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        func: scrapeLinkedInPage,
        args: [],
      });
      const scraped = results?.[0]?.result || [];
      swLog('Attempt ' + attempt + ': scraped ' + scraped.length + ' profiles');

      if (scraped.length === 0 && attempt === 1) {
        swLog('No profiles yet — retrying in 3.5s...');
        continue; // retry
      }

      if (scraped.length > 0) {
        const stored = await chrome.storage.local.get(['profiles']);
        const isNewSearch = ps.isNewSearch !== false;
        const isNextPage  = ps.page > 1;
        const baseProfiles = (isNewSearch && !isNextPage) ? [] : (stored.profiles || []);
        const existing = new Set(baseProfiles.map(p => p.profileUrl));
        const fresh = scraped
          .filter(p => p.profileUrl && !existing.has(p.profileUrl))
          .map(p => ({
            ...p,
            status: 'pending',
            keyword:  ps.params?.keywords || '',
            location: ps.params?.location || 'All India',
            page:     ps.page || 1,
            scrapedAt: new Date().toISOString(),
          }));
        const allProfiles = [...baseProfiles, ...fresh];
        await chrome.storage.local.set({
          profiles: allProfiles,
          currentSearchKeyword: ps.params?.keywords || '',
          lastScrapeResult: {
            count: fresh.length,
            total: allProfiles.length,
            page: ps.page || 1,
            isNewSearch,
            at: Date.now()
          }
        });
        await chrome.storage.local.remove('pendingScrape');
        swLog((isNewSearch && !isNextPage ? '🔄 New search: ' : '➕ Page ' + (ps.page||1) + ': ') + fresh.length + ' profiles. Total: ' + allProfiles.length);
        try {
          chrome.runtime.sendMessage({
            action: 'SCRAPE_DONE',
            added:  fresh.length,
            total:  allProfiles.length,
            page:   ps.page || 1,
            isNewSearch,
          }).catch(() => {});
        } catch(e) {}
      } else {
        swLog('No profiles found after 2 attempts — LinkedIn page may not have loaded correctly');
        await chrome.storage.local.remove('pendingScrape');
      }
      break; // done
    } catch(e) {
      swLog('Scrape error (attempt ' + attempt + '): ' + e.message);
      if (attempt === 2) await chrome.storage.local.remove('pendingScrape');
    }
  }
});

// ── The scrape function injected into LinkedIn page ──────────────────────────
function scrapeLinkedInPage() {
  const profiles = [];
  let cards = [];

  // Try multiple selectors — LinkedIn changes their class names
  const SELECTORS = [
    '.reusable-search__result-container',
    '[data-view-name="search-entity-result-universal-template"]',
    '.entity-result',
    'ul.reusable-search__entity-result-list > li',
    '.search-results-container li',
  ];

  for (const sel of SELECTORS) {
    const found = document.querySelectorAll(sel);
    if (found.length >= 2) { cards = Array.from(found); break; }
  }

  if (!cards.length) {
    // Last resort — find all profile links
    const links = document.querySelectorAll('a[href*="/in/"]');
    const seen = new Set();
    links.forEach(link => {
      const url = link.href.split('?')[0];
      if (seen.has(url) || !url.match(/linkedin\.com\/in\/[^/]+\/?$/)) return;
      seen.add(url);
      const nameEl = link.querySelector('span[aria-hidden="true"]') ||
                     link.closest('li')?.querySelector('span[aria-hidden="true"]');
      const name = nameEl?.textContent?.trim();
      if (!name || name === 'LinkedIn Member' || /^\d+$/.test(name)) return;
      const card = link.closest('li') || link.closest('[class*="result"]');
      profiles.push({
        name,
        role: card?.querySelector('[class*="subtitle"], [class*="primary-subtitle"]')?.textContent?.trim() || '',
        company: card?.querySelector('[class*="secondary-subtitle"]')?.textContent?.trim() || '',
        city: card?.querySelector('[class*="tertiary"], [class*="location"]')?.textContent?.trim() || '',
        profileUrl: url,
        photo: card?.querySelector('img[src*="media"]')?.src || '',
        degree: card?.querySelector('[class*="dist-value"], [class*="degree"]')?.textContent?.trim() || '',
        isOTW: !!card?.querySelector('[aria-label*="Open to work"]'),
      });
    });
    return profiles;
  }

  cards.forEach(card => {
    try {
      // Get name
      let name = null;
      const nameSelectors = [
        '.entity-result__title-text a span[aria-hidden="true"]',
        'a[href*="/in/"] span[aria-hidden="true"]',
        '.app-aware-link span[aria-hidden="true"]',
      ];
      for (const s of nameSelectors) {
        const el = card.querySelector(s);
        const t = el?.textContent?.trim();
        if (t && t !== 'LinkedIn Member' && t.length > 1 && !/^\d+$/.test(t)) {
          name = t; break;
        }
      }
      if (!name) return;

      const linkEl = card.querySelector('a[href*="/in/"]');
      if (!linkEl) return;
      const profileUrl = linkEl.href.split('?')[0];
      if (!profileUrl.match(/linkedin\.com\/in\/[^/]+/)) return;

      const btns = Array.from(card.querySelectorAll('button'))
        .map(b => b.textContent.trim().toLowerCase());

      profiles.push({
        name,
        role:    card.querySelector('.entity-result__primary-subtitle')?.textContent?.trim()   || '',
        company: card.querySelector('.entity-result__secondary-subtitle')?.textContent?.trim() || '',
        city:    card.querySelector('.entity-result__tertiary-subtitle')?.textContent?.trim()  || '',
        profileUrl,
        photo: (() => {
          const img = card.querySelector('img.presence-entity__image, img.evi-image, img[src*="media.licdn"]');
          return img?.src && !img.src.includes('ghost') ? img.src : '';
        })(),
        degree: card.querySelector('.dist-value')?.textContent?.trim() || '',
        isOTW:  !!card.querySelector('[aria-label*="Open to work"], .open-to-opportunities-badge'),
        isConnected: btns.includes('message'),
      });
    } catch(e) {}
  });

  return profiles;
}

// ── Message hub ──────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.action) {

        case 'START_CAMPAIGN': {
          const { count, message, delay, randomDelay } = msg;
          const data = await chrome.storage.local.get(['profiles','campaign']);
          const pending = (data.profiles || []).filter(p => p.status === 'pending');
          if (!pending.length) { sendResponse({ ok:false, error:'No pending profiles' }); return; }
          const toSend = pending.slice(0, Math.min(count || pending.length, pending.length));
          toSend.forEach(p => p.status = 'queued');
          await chrome.storage.local.set({
            profiles: data.profiles,
            campaign: { running:true, paused:false, index:0, total:toSend.length, message, delay:delay||45, randomDelay:!!randomDelay, startedAt:Date.now() }
          });
          swLog('Campaign started · ' + toSend.length + ' targets');
          setTimeout(campaignTick, 500);
          sendResponse({ ok:true, total:toSend.length });
          break;
        }

        case 'PAUSE_CAMPAIGN': {
          const d = await chrome.storage.local.get('campaign');
          d.campaign.paused = !d.campaign.paused;
          await chrome.storage.local.set({ campaign: d.campaign });
          sendResponse({ ok:true, paused:d.campaign.paused });
          break;
        }

        case 'STOP_CAMPAIGN': {
          await chrome.storage.local.set({ campaign:{ running:false,paused:false,index:0,total:0,message:'' }});
          chrome.alarms.clear('campaignTick');
          sendResponse({ ok:true });
          break;
        }

        case 'GET_STATUS': {
          const d = await chrome.storage.local.get(['profiles','campaign','log','sent','failed','dailySent','lastScrapeResult']);
          sendResponse({ ok:true, ...d });
          break;
        }

        case 'MANUAL_SCRAPE': {
          // Use passed tabId if available, else fall back to active LinkedIn tab
          let targetTabId = msg.tabId || null;
          if (!targetTabId) {
            const allTabs = await chrome.tabs.query({});
            const liTab = allTabs.find(t => t.url && t.url.includes('linkedin.com/search/results/people'));
            if (liTab) targetTabId = liTab.id;
          }
          if (!targetTabId) {
            sendResponse({ ok:false, error:'Could not find LinkedIn search tab' });
            return;
          }
          try {
            const results = await chrome.scripting.executeScript({
              target: { tabId: targetTabId },
              func: scrapeLinkedInPage,
            });
            const scraped = results?.[0]?.result || [];
            if (scraped.length > 0) {
              const psData = await chrome.storage.local.get('pendingScrape');
              const ps2 = psData.pendingScrape;
              const stored = await chrome.storage.local.get(['profiles','currentSearchKeyword']);
              const newKeyword = ps2?.params?.keywords || '';
              const isNew = ps2?.isNewSearch !== false && (ps2?.page || 1) <= 1;
              const base = isNew ? [] : (stored.profiles||[]);
              const existing = new Set(base.map(p=>p.profileUrl));
              const fresh = scraped
                .filter(p => p.profileUrl && !existing.has(p.profileUrl))
                .map(p => ({
                  ...p, status:'pending',
                  keyword: newKeyword,
                  page: ps2?.page || 1,
                  scrapedAt: new Date().toISOString()
                }));
              const all = [...base, ...fresh];
              await chrome.storage.local.set({
                profiles: all,
                currentSearchKeyword: newKeyword,
                lastScrapeResult: { count: fresh.length, total: all.length, page: ps2?.page||1, isNew, at: Date.now() }
              });
              if (ps2) await chrome.storage.local.remove('pendingScrape');
              try { chrome.runtime.sendMessage({ action:'SCRAPE_DONE', added:fresh.length, total:all.length }).catch(()=>{}); } catch(e){}
              sendResponse({ ok:true, found: scraped.length, added: fresh.length, total: all.length });
            } else {
              sendResponse({ ok:false, error:'No profiles found — LinkedIn may not have finished loading' });
            }
          } catch(e) {
            sendResponse({ ok:false, error: e.message });
          }
          break;
        }

        case 'LOG': {
          await swLog(msg.message);
          sendResponse({ ok:true });
          break;
        }

        case 'SI_GET_SALARY': {
          siAICall(msg.profileText)
            .then(r  => sendResponse({ ok:true,  ...r }))
            .catch(e => sendResponse({ ok:false, error:e.message }));
          return true; // keep channel open for async
        }

        default:
          sendResponse({ ok:false, error:'Unknown action: ' + msg.action });
      }
    } catch(e) {
      swLog('SW error: ' + e.message);
      sendResponse({ ok:false, error:e.message });
    }
  })();
  return true; // keep channel open for async
});

// ── Campaign tick ────────────────────────────────────────────────────────────
async function campaignTick() {
  const data = await chrome.storage.local.get(['profiles','campaign','settings','dailySent','dailyReset']);
  const camp = data.campaign || {};
  const cfg  = data.settings || {};
  const profiles = data.profiles || [];

  if (!camp.running || camp.paused) return;

  // Daily limit check
  let dailySent = data.dailySent || 0;
  if (new Date().toDateString() !== data.dailyReset) {
    dailySent = 0;
    await chrome.storage.local.set({ dailySent:0, dailyReset: new Date().toDateString() });
  }
  if (dailySent >= (cfg.dailyLimit || 50)) {
    swLog('Daily limit reached: ' + dailySent);
    camp.running = false;
    await chrome.storage.local.set({ campaign: camp });
    return;
  }

  // Find next queued profile
  const idx = profiles.findIndex(p => p.status === 'queued');
  if (idx === -1) {
    camp.running = false;
    await chrome.storage.local.set({ campaign: camp });
    swLog('Campaign complete');
    return;
  }

  const profile = profiles[idx];

  try {
    // ── Get LinkedIn tab — open silently in background if not open ──
    let tabs = await chrome.tabs.query({ url:'https://www.linkedin.com/*' });
    if (!tabs.length) {
      swLog('Opening LinkedIn silently in background...');
      try {
        await chrome.tabs.create({ url:'https://www.linkedin.com/feed/', active:false });
        await sleep(3500);
        tabs = await chrome.tabs.query({ url:'https://www.linkedin.com/*' });
      } catch(e) {}
    }
    if (!tabs.length) {
      swLog('Could not open LinkedIn — will retry in 2 min');
      chrome.alarms.create('campaignTick', { delayInMinutes:2 });
      return;
    }
    const mainTabId = tabs[0].id;

    // ── Open profile in NEW BACKGROUND TAB (invisible to user) ──────
    const bgTab = await chrome.tabs.create({
      url: profile.profileUrl,
      active: false,  // ← background tab — user never sees it!
    });
    await sleep(4500); // wait for profile page to fully load

    // ── Inject connect script into background tab ────────────────────
    const msg = personalizeMessage(camp.message || '', profile);
    let result;
    try {
      result = await chrome.scripting.executeScript({
        target: { tabId: bgTab.id },
        func: clickConnectOnProfile,
        args: [msg],
      });
    } catch(injErr) {
      // Close bg tab on error
      try { await chrome.tabs.remove(bgTab.id); } catch(e) {}
      throw injErr;
    }

    // ── Close background tab after sending ──────────────────────────
    try { await chrome.tabs.remove(bgTab.id); } catch(e) {}

    const ok = result?.[0]?.result === true;
    profiles[idx].status = ok ? 'sent' : 'failed';
    profiles[idx].sentAt = new Date().toISOString();

    const newSent   = (await chrome.storage.local.get('sent')).sent || 0;
    const newFailed = (await chrome.storage.local.get('failed')).failed || 0;

    await chrome.storage.local.set({
      profiles,
      sent:      ok ? newSent + 1   : newSent,
      failed:    ok ? newFailed     : newFailed + 1,
      dailySent: ok ? dailySent + 1 : dailySent,
    });

    swLog((ok ? '✓ Sent' : '✗ Failed') + ' → ' + profile.name);
    // Notify popup
    try {
      chrome.runtime.sendMessage({
        action: 'CAMPAIGN_UPDATE',
        profileUrl: profile.profileUrl,
        name: profile.name,
        role: profile.role || '',
        status: ok ? 'sent' : 'failed',
      }).catch(() => {}); // popup may be closed
    } catch(e) {}

    // Schedule next
    const delay = camp.randomDelay
      ? Math.max(15, (camp.delay || 45) + Math.floor(Math.random()*20 - 10))
      : (camp.delay || 45);
    chrome.alarms.create('campaignTick', { delayInMinutes: delay / 60 });

  } catch(e) {
    profiles[idx].status = 'failed';
    await chrome.storage.local.set({ profiles });
    swLog('Campaign error: ' + e.message);
    chrome.alarms.create('campaignTick', { delayInMinutes: 0.5 });
  }
}

// ── Connect on profile page ──────────────────────────────────────────────────
function clickConnectOnProfile(message) {
  return new Promise(async resolve => {
    function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

    function findBtn(labels, root) {
      root = root || document;
      for (const label of labels) {
        // aria-label exact match
        let el = root.querySelector(`button[aria-label="${label}"]`);
        if (el && el.offsetParent !== null) return el;
        // aria-label contains
        el = root.querySelector(`button[aria-label*="${label}"]`);
        if (el && el.offsetParent !== null) return el;
        // text content exact
        const all = Array.from(root.querySelectorAll('button'));
        el = all.find(b => b.offsetParent !== null && b.textContent.trim() === label);
        if (el) return el;
        // text content lowercase
        el = all.find(b => b.offsetParent !== null && b.textContent.trim().toLowerCase() === label.toLowerCase());
        if (el) return el;
      }
      return null;
    }

    function getModal() {
      return document.querySelector('.artdeco-modal, [data-test-modal], .send-invite, [role="dialog"]') || document;
    }

    await sleep(1500);

    // Step 1: Click Connect
    let connectBtn = findBtn(['Connect']);
    if (!connectBtn) {
      const more = findBtn(['More actions', 'More']);
      if (more) { more.click(); await sleep(800); connectBtn = findBtn(['Connect']); }
    }
    if (!connectBtn) { resolve(false); return; }

    connectBtn.click();
    await sleep(1500);

    const modal = getModal();

    // Step 2: Handle "How do you know X?" if it appears
    const otherBtn = findBtn(['Other'], modal);
    if (otherBtn) {
      otherBtn.click(); await sleep(600);
      const nextBtn = findBtn(['Next'], modal);
      if (nextBtn) { nextBtn.click(); await sleep(800); }
    }

    // Step 3: Add note
    if (message && message.trim()) {
      const noteBtn = findBtn(['Add a note', 'Add note'], getModal());
      if (noteBtn) {
        noteBtn.click();
        await sleep(900);
        const ta = document.querySelector('#custom-message, textarea[name="message"], .artdeco-modal textarea, .send-invite textarea');
        if (ta) {
          try {
            const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
            setter.call(ta, message);
            ta.dispatchEvent(new Event('input', { bubbles: true }));
            ta.dispatchEvent(new Event('change', { bubbles: true }));
          } catch(e) {
            ta.value = message;
            ta.dispatchEvent(new Event('input', { bubbles: true }));
          }
          await sleep(500);
        }
      }
    }

    await sleep(400);

    // Step 4: Send
    const sendBtn = findBtn(
      ['Send now', 'Send invitation', 'Send', 'Done'],
      getModal()
    );

    if (sendBtn && !sendBtn.disabled) {
      sendBtn.click();
      await sleep(600);
      resolve(true);
    } else {
      // Dismiss and report failure
      const dismiss = document.querySelector('[aria-label="Dismiss"], .artdeco-modal__dismiss');
      if (dismiss) dismiss.click();
      resolve(false);
    }
  });
}

// ── Utilities ────────────────────────────────────────────────────────────────
function personalizeMessage(tmpl, p) {
  const first = (p.name||'').split(' ')[0] || 'there';
  const role  = (p.role||'').split(' at ')[0].split(' - ')[0].trim() || 'your field';
  const co    = p.company || 'your company';
  const city  = p.city || p.location || 'your city';
  return tmpl
    // Campaign tab format: {{first_name}} etc
    .replace(/{{first_name}}/g, first)
    .replace(/{{company}}/g,    co)
    .replace(/{{role}}/g,       role)
    .replace(/{{location}}/g,   city)
    .replace(/{{your_name}}/g,  'Recruiter')
    // Legacy format: {FirstName} etc
    .replace(/{FirstName}/g,    first)
    .replace(/{Role}/g,         role)
    .replace(/{Company}/g,      co);
}

// ── Silence "Receiving end does not exist" errors ──────────────────────────
// These are normal — they happen when popup is closed during message send
self.addEventListener('unhandledrejection', event => {
  const msg = event?.reason?.message || '';
  if (
    msg.includes('Receiving end does not exist') ||
    msg.includes('Could not establish connection') ||
    msg.includes('message channel closed') ||
    msg.includes('Extension context invalidated')
  ) {
    event.preventDefault(); // suppress the error in console
  }
});

async function swLog(msg) {
  const data = await chrome.storage.local.get('log');
  const log  = data.log || [];
  log.unshift('[' + new Date().toLocaleTimeString('en-IN') + '] ' + msg);
  if (log.length > 50) log.pop();
  await chrome.storage.local.set({ log });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function nextMidnightIST() {
  const now = new Date();
  const ist = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
  const midnight = new Date(ist);
  midnight.setDate(midnight.getDate() + 1);
  midnight.setHours(0, 0, 0, 0);
  return Date.now() + (midnight - ist);
}


// ── Salary Intelligence AI ──────────────────────────────────────────────────

async function siAICall(profileText) {
  const stored = await chrome.storage.local.get('anthropicApiKey');
  const apiKey = (stored.anthropicApiKey || '').trim();
  if (!apiKey) throw new Error('NO_KEY');

  const text2k = profileText.slice(0, 2000);
  const prompt = [
    'You are a senior compensation analyst for the Indian job market (2025-26).',
    '',
    'Read this LinkedIn profile and return a salary estimate as JSON.',
    'RULES: Extract ONLY current role and company (top of experience). Count total years. Check education.',
    '',
    'PROFILE TEXT:',
    '"""',
    text2k,
    '"""',
    '',
    'Return ONLY this JSON (no markdown):',
    '{',
    '  "title": "current job title",',
    '  "company": "current company",',
    '  "city": "Indian city or empty",',
    '  "expYears": total years as number or null,',
    '  "education": "IIT or IIM or BITS or NIT or Other",',
    '  "tier": "faang or unicorn or mnc or startup or service or other",',
    '  "minLPA": number,',
    '  "maxLPA": number,',
    '  "reasoning": "one sentence"',
    '}',
    '',
    'Salary bands India 2025-26:',
    'faang(Google/MS/Amazon/Meta/Goldman/JPMorgan/McKinsey): 0-1yr 15-25L, 1-3yr 22-38L, 3-6yr 38-68L, 6-10yr 62-100L, 10yr+ 88-200L, VP/Dir 150-350L',
    'unicorn(Razorpay/Swiggy/Zerodha/PhonePe/Freshworks): 0-1yr 10-18L, 1-3yr 16-28L, 3-6yr 26-48L, 6-10yr 42-72L, 10yr+ 66-130L, VP 110-220L',
    'mnc(Accenture/Deloitte/IBM/SAP/EY/KPMG/Capgemini/Bosch): 0-1yr 7-13L, 1-3yr 12-22L, 3-6yr 20-38L, 6-10yr 34-58L, 10yr+ 52-100L, VP 90-180L',
    'startup(Flipkart/Blinkit/Zepto/Practo): 0-1yr 6-12L, 1-3yr 9-18L, 3-6yr 16-30L, 6-10yr 26-48L, 10yr+ 42-85L',
    'service(TCS/Infosys/Wipro/HCL/Cognizant/Genpact): 0-1yr 3-6L, 1-3yr 5-10L, 3-6yr 8-17L, 6-10yr 14-27L, 10yr+ 22-45L',
    'other: mid 6-14L, senior 12-22L, lead 18-35L',
    'Bonus: IIT/IIM +25-35%, BITS/NIT +10-20%, Bengaluru 100%, Mumbai 95%, Hyderabad 88%, Pune 87%',
  ].join('\n');

  let resp;
  try {
    resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
    body: JSON.stringify({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 400,
      messages: [{ role: 'user', content: prompt }]
    })
  });

  } catch(fetchErr) {
    throw new Error('Network error: ' + fetchErr.message + '. Check your internet connection.');
  }

  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err?.error?.message || ('API error ' + resp.status));
  }

  const data = await resp.json();
  const raw  = (data.content?.[0]?.text || '').replace(/```json|```/g, '').trim();
  const json = JSON.parse(raw);
  json.ok = true;
  return json;
}
