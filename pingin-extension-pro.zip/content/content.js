'use strict';

// ═══════════════════════════════════════════════════════════════
//  PingIN Content Script v7
//  LinkedIn: Profile Scraper + Salary Overlay
//  NOTE: Location filtering is handled by geoUrn URL + post-scrape filter
//        (removed UI filter — it was clicking wrong autocomplete items)
// ═══════════════════════════════════════════════════════════════

let lastUrl = location.href;
const _observer = new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    if (location.href.includes('linkedin.com/search/results/people')) {
      setTimeout(() => chrome.runtime.sendMessage({ action: 'PAGE_CHANGED', url: location.href }).catch(() => {}), 3000);
    }
    setTimeout(siRun, 1500);
  }
});
_observer.observe(document.body, { childList: true, subtree: true });

function scrapeProfilesFromPage() {
  const results = [];
  const seen = new Set();

  // Find all search result cards — multiple selector variants for 2024-25 LinkedIn
  const CARD_SELECTORS = [
    'li.reusable-search__result-container',
    'li[data-view-name="search-entity-result-universal-template"]',
    '.entity-result__item',
  ];

  let cards = [];
  for (const sel of CARD_SELECTORS) {
    cards = Array.from(document.querySelectorAll(sel));
    if (cards.length >= 2) break;
  }

  // Fallback: find all LI elements containing a profile link
  if (cards.length === 0) {
    cards = Array.from(document.querySelectorAll('li')).filter(li =>
      li.querySelector('a[href*="/in/"]') && li.textContent.trim().length > 20
    );
  }

  cards.forEach(card => {
    try {
      // ── Profile URL ───────────────────────────────────────────────────────
      const linkEl = card.querySelector('a[href*="/in/"]');
      if (!linkEl) return;
      const url = (linkEl.href || '').split('?')[0];
      if (url.indexOf('linkedin.com/in/') < 0 || (url.split('/in/')[1] || '').length < 2 || seen.has(url)) return;
      seen.add(url);

      // ── Name — use entity title span ONLY to avoid duplication ───────────
      // LinkedIn renders name twice (once for screen readers, once visual)
      // .entity-result__title-text span[aria-hidden] avoids the duplicate
      const nameEl =
        card.querySelector('.entity-result__title-text span[aria-hidden="true"]') ||
        card.querySelector('.artdeco-entity-lockup__title span[aria-hidden="true"]') ||
        card.querySelector('[class*="title"] span[aria-hidden="true"]') ||
        card.querySelector('span[aria-hidden="true"]');

      const name = nameEl?.textContent?.trim();
      if (!name || name.length < 2 || name === 'LinkedIn Member') return;

      // ── Role / Headline ───────────────────────────────────────────────────
      const role =
        card.querySelector('.entity-result__primary-subtitle')?.textContent?.trim() ||
        card.querySelector('[class*="primary-subtitle"]')?.textContent?.trim() ||
        card.querySelector('.artdeco-entity-lockup__subtitle')?.textContent?.trim() ||
        // t-14 t-black t-normal is LinkedIn's headline class in newer layouts
        card.querySelector('.t-14.t-black.t-normal')?.textContent?.trim() ||
        card.querySelector('span.t-14')?.textContent?.trim() ||
        '';

      // ── Company (secondary subtitle) ───────────────────────────────────────
      const company =
        card.querySelector('.entity-result__secondary-subtitle')?.textContent?.trim() ||
        card.querySelector('[class*="secondary-subtitle"]')?.textContent?.trim() ||
        '';

      // ── Location ──────────────────────────────────────────────────────────
      const city =
        card.querySelector('.entity-result__tertiary-subtitle')?.textContent?.trim() ||
        card.querySelector('[class*="tertiary-subtitle"]')?.textContent?.trim() ||
        card.querySelector('.entity-result__location')?.textContent?.trim() ||
        card.querySelector('span.t-12')?.textContent?.trim() ||
        // fallback: find text matching city pattern (contains "India" or state name)
        (() => {
          const texts = Array.from(card.querySelectorAll('span, div'))
            .map(el => el.childNodes.length === 1 && el.firstChild.nodeType === 3 ? el.textContent.trim() : '')
            .filter(t => t.length > 3 && (t.includes('India') || t.includes('Area') || /(Delhi|Mumbai|Bengaluru|Bangalore|Hyderabad|Chennai|Pune|Kolkata|Noida|Gurgaon)/.test(t)));
          return texts[0] || '';
        })();

      // ── Connection degree ──────────────────────────────────────────────────
      const degree =
        card.querySelector('.dist-value')?.textContent?.trim() ||
        card.querySelector('[class*="dist"]')?.textContent?.trim() ||
        // fallback: find "1st", "2nd", "3rd" in card text
        (() => {
          const match = (card.textContent || '').match(/([123](st|nd|rd))/);
          return match ? match[1] : '';
        })();

      // ── Open to Work ──────────────────────────────────────────────────────
      const isOTW =
        !!card.querySelector('[aria-label*="Open to work"]') ||
        !!card.querySelector('[class*="open-to-work"]') ||
        card.textContent.includes('Open to work') ||
        card.textContent.includes('#OpenToWork');

      // ── Photo ──────────────────────────────────────────────────────────────
      const photo =
        card.querySelector('img[src*="media.licdn"]')?.src ||
        card.querySelector('img[src*="profile-displayphoto"]')?.src ||
        card.querySelector('img[src*="licdn"]')?.src ||
        '';

      results.push({
        name, profileUrl: url, role, company, city, degree,
        isOTW, photo, status: 'pending',
        scrapedAt: new Date().toISOString()
      });
    } catch(e) {}
  });

  return results.filter(p => p.name && p.profileUrl);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'SCRAPE_PAGE') {
    sendResponse({ ok: true, profiles: scrapeProfilesFromPage() });
  }
  // Extract JD text from LinkedIn jobs page
  if (msg.action === 'EXTRACT_JD') {
    try {
      const selectors = [
        '.jobs-description__content',
        '.jobs-box__html-content',
        '[class*="job-details-jobs-unified-top-card"]',
        '.description__text',
        '.show-more-less-html__markup',
        '#job-details',
        '[class*="jobs-description"]',
      ];
      let text = '';
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el && el.textContent.trim().length > 100) {
          text = el.textContent.trim();
          break;
        }
      }
      // Fallback: grab all text from main content area
      if (!text) {
        const main = document.querySelector('main') || document.body;
        text = main.innerText.substring(0, 5000);
      }
      sendResponse({ ok: true, text });
    } catch(e) {
      sendResponse({ ok: false, text: '' });
    }
  }
  return true;
});

if (location.href.includes('linkedin.com/search/results/people')) {
  setTimeout(() => {
    const count = scrapeProfilesFromPage().length;
    if (count > 0) chrome.runtime.sendMessage({ action: 'RESULTS_READY', count }).catch(() => {});
  }, 3000);
}

// ═══════════════════════════════════════════════════════════════
//  SALARY ESTIMATE OVERLAY — unchanged
// ═══════════════════════════════════════════════════════════════

const SI_TIERS = {
  faang:   ['google','microsoft','amazon','meta','apple','nvidia','adobe','salesforce','oracle','intel','qualcomm','cisco','goldman sachs','jpmorgan','morgan stanley','american express','mckinsey','bcg','bain','walmart global tech','samsung research','bloomberg'],
  unicorn: ['razorpay','cred','zerodha','groww','phonepe','meesho','nykaa','swiggy','zomato','ola','byju','freshworks','zoho','browserstack','postman','chargebee','darwinbox','lenskart','cars24','policybazaar','paytm','delhivery','shiprocket','dream11'],
  mnc:     ['ibm','sap','vmware','servicenow','workday','zendesk','atlassian','mongodb','datadog','snowflake','stripe','paypal','visa','mastercard','hsbc','barclays','ubs','standard chartered','deutsche bank','ey','pwc','kpmg','deloitte','accenture','capgemini','thoughtworks'],
  startup: ['flipkart','myntra','bigbasket','blinkit','zepto','practo','cure.fit','1mg','healthifyme','cashfree','instamojo','payu','pine labs','ather','ola electric','rapido','porter'],
  service: ['tcs','infosys','wipro','hcl','tech mahindra','ltimindtree','mphasis','hexaware','persistent','cyient','coforge','birlasoft','cognizant','genpact','wns','exlservice'],
};
const SI_SALARY = {
  faang:   { intern:[8,15], fresher:[15,25], junior:[22,38], mid:[38,68], senior:[62,100], lead:[88,150], principal:[135,220], director:[195,350] },
  unicorn: { intern:[5,10], fresher:[10,18], junior:[16,28], mid:[26,48], senior:[42,72],  lead:[66,108], principal:[96,158],  director:[145,248] },
  mnc:     { intern:[4,8],  fresher:[7,13],  junior:[12,22], mid:[20,38], senior:[34,58],  lead:[52,88],  principal:[76,128],  director:[116,198] },
  startup: { intern:[3,7],  fresher:[6,12],  junior:[9,18],  mid:[16,30], senior:[26,48],  lead:[42,72],  principal:[62,102],  director:[92,158]  },
  service: { intern:[2,4],  fresher:[3,6],   junior:[5,10],  mid:[8,17],  senior:[14,27],  lead:[22,40],  principal:[34,58],   director:[52,88]   },
  other:   { intern:[1,3],  fresher:[2,5],   junior:[3,7],   mid:[6,13],  senior:[10,20],  lead:[16,32],  principal:[26,48],   director:[40,72]   },
};
const SI_CITY_MULT = {
  'bengaluru':1.00,'bangalore':1.00,'mumbai':0.95,'hyderabad':0.88,
  'pune':0.87,'delhi':0.92,'gurgaon':0.90,'gurugram':0.90,
  'noida':0.88,'chennai':0.85,'kolkata':0.78,'ahmedabad':0.76,
};
const SI_TIER_LABEL = { faang:'FAANG / Top GCC', unicorn:'Unicorn / Product', mnc:'MNC India', startup:'Indian Startup', service:'IT Services', other:'SME / Other' };
function siGetTier(c){const co=(c||'').toLowerCase();for(const[t,l]of Object.entries(SI_TIERS)){if(l.some(n=>co.includes(n)))return t;}return 'other';}
function siGetExp(t){const ti=(t||'').toLowerCase();if(/intern|trainee/.test(ti))return 'intern';if(/fresher|graduate|entry.?level/.test(ti))return 'fresher';if(/junior|associate|sde.?1/.test(ti))return 'junior';if(/senior|sde.?3|sr/.test(ti))return 'senior';if(/lead|manager|tech.?lead/.test(ti))return 'lead';if(/principal|staff|architect/.test(ti))return 'principal';if(/director|vp|vice.?pres|head.?of/.test(ti))return 'director';return 'mid';}
function siGetCityMult(c){const ci=(c||'').toLowerCase();for(const[k,m]of Object.entries(SI_CITY_MULT)){if(ci.includes(k))return m;}return 0.85;}
function siFmt(n){return n>=100?(n/100).toFixed(1)+' Cr':n+'L';}
function siCalc(role,company,city){const tier=siGetTier(company);const sen=siGetExp(role);const mult=siGetCityMult(city);const band=SI_SALARY[tier][sen];return{min:Math.round(band[0]*mult),max:Math.round(band[1]*mult),tier,sen,tierLabel:SI_TIER_LABEL[tier]};}
function readProfileData(){const role=document.querySelector('.text-heading-xlarge,.top-card-layout__headline')?.textContent?.trim()||'';let company='';const expItems=document.querySelectorAll('#experience ~ .pvs-list__outer-container li,[data-view-name="profile-component-entity"]');for(const item of expItems){const co=item.querySelector('.hoverable-link-text span[aria-hidden="true"],.t-14.t-normal span[aria-hidden="true"]')?.textContent?.trim();if(co&&co.length>1){company=co;break;}}if(!company&&role.includes(' at '))company=role.split(' at ').slice(-1)[0].trim();const city=document.querySelector('.pv-text-details__left-panel span.text-body-small:not(.visually-hidden)')?.textContent?.trim()||'';const name=document.querySelector('h1.text-heading-xlarge,.pv-text-details__left-panel h1')?.textContent?.trim()||'This person';return{name,role,company,city};}
const OVERLAY_ID='pingin-salary-overlay';
function siInjectOverlay(data){document.getElementById(OVERLAY_ID)?.remove();const{name,role,company,city}=data;if(!role&&!company)return;const r=siCalc(role,company,city);const rangeText='₹'+siFmt(r.min)+' – ₹'+siFmt(r.max)+' PA';const overlay=document.createElement('div');overlay.id=OVERLAY_ID;overlay.style.cssText='position:fixed;bottom:20px;right:20px;z-index:99999;width:252px;background:#0D0F14;border:1.5px solid rgba(91,181,255,.28);border-radius:14px;overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;box-shadow:0 8px 32px rgba(0,0,0,.6);transition:opacity .3s,transform .3s;opacity:0;transform:translateY(8px);';overlay.innerHTML=`<div style="padding:9px 12px 7px;background:linear-gradient(135deg,#0A0C10,#111827);border-bottom:1px solid rgba(255,255,255,.07);position:relative;"><div style="position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,#0077B5,#00C49A);"></div><div style="display:flex;align-items:center;justify-content:space-between;"><div style="font-size:11px;font-weight:800;color:#fff;">💰 PingIN <span style="background:linear-gradient(90deg,#5BB5FF,#00C49A);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">Salary Intel</span></div><button id="pingin-si-close" style="background:none;border:none;color:rgba(255,255,255,.35);font-size:14px;cursor:pointer;padding:0;">✕</button></div><div style="font-size:9px;color:rgba(255,255,255,.35);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${name.split(' ')[0]}${company?' · '+company.split(',')[0].slice(0,22):''}</div></div><div style="padding:10px 12px 12px;"><div style="font-size:22px;font-weight:800;color:#5BB5FF;letter-spacing:-.4px;line-height:1;margin-bottom:10px;">${rangeText}</div><div style="display:flex;flex-direction:column;gap:5px;margin-bottom:10px;"><div style="display:flex;justify-content:space-between;font-size:10px;"><span style="color:rgba(255,255,255,.4);">Company tier</span><span style="color:rgba(255,255,255,.75);font-weight:600;">${r.tierLabel}</span></div><div style="display:flex;justify-content:space-between;font-size:10px;"><span style="color:rgba(255,255,255,.4);">Seniority</span><span style="color:rgba(255,255,255,.75);font-weight:600;">${r.sen.charAt(0).toUpperCase()+r.sen.slice(1)}</span></div>${city?`<div style="display:flex;justify-content:space-between;font-size:10px;"><span style="color:rgba(255,255,255,.4);">Location</span><span style="color:rgba(255,255,255,.75);font-weight:600;">${city.split(',')[0].slice(0,18)}</span></div>`:''}</div><div style="background:rgba(255,180,0,.07);border:1px solid rgba(255,180,0,.15);border-radius:7px;padding:6px 9px;font-size:9px;color:rgba(255,200,80,.7);line-height:1.5;">⚡ Estimation only · Based on India market data 2025–26<br>Glassdoor · AmbitionBox · Levels.fyi</div></div>`;document.body.appendChild(overlay);requestAnimationFrame(()=>{overlay.style.opacity='1';overlay.style.transform='translateY(0)';});document.getElementById('pingin-si-close')?.addEventListener('click',()=>{overlay.style.opacity='0';overlay.style.transform='translateY(8px)';setTimeout(()=>overlay.remove(),300);});setTimeout(()=>{if(document.getElementById(OVERLAY_ID)){overlay.style.opacity='0';overlay.style.transform='translateY(8px)';setTimeout(()=>overlay.remove(),300);}},12000);}
function siRun(){const url=location.href;if(!url.includes('linkedin.com/in/')||url.includes('/search')||url.includes('/messaging')||url.includes('/feed'))return;setTimeout(()=>{const data=readProfileData();if(data.role||data.company)siInjectOverlay(data);},2500);}
siRun();
