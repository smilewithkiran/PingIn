'use strict';
/**
 * PingIN Stack Overflow Content Script v2
 * Scrapes top experts from SO tag pages + user list pages
 */

function scrapeSOUsers() {
  const users = [];
  const seen  = new Set();

  // Strategy 1: All anchors linking to user profiles
  document.querySelectorAll('a[href*="/users/"]').forEach(a => {
    try {
      const href = a.getAttribute('href') || '';
      if (!href.match(/\/users\/\d+\//)) return;
      const fullUrl = href.startsWith('http') ? href : 'https://stackoverflow.com' + href;
      if (seen.has(fullUrl)) return;

      // Get name - prefer aria-label or direct text
      const name = (a.getAttribute('aria-label') || a.textContent || '').trim();
      if (!name || name.length < 2 || name.toLowerCase().includes('all users')) return;

      // Look for reputation near this element
      const card = a.closest('div, li, td') || a.parentElement;
      const repEl = card?.querySelector(
        '.reputation-score, [class*="reputation"], .s-user-card--reputation, ' +
        '.fs-caption.fc-black-400, span[title*="reputation"]'
      );
      const rep = repEl?.textContent?.trim() || '';

      seen.add(fullUrl);
      users.push({
        name,
        soProfile: fullUrl,
        reputation: rep,
        source: 'stackoverflow',
        scrapedAt: new Date().toISOString(),
      });
    } catch(e) {}
  });

  // Strategy 2: User cards (newer SO layout)
  document.querySelectorAll('.s-user-card, .user-info, .grid--item.fl-shrink0').forEach(card => {
    try {
      const nameEl = card.querySelector('a[href*="/users/"]');
      if (!nameEl) return;
      const name = nameEl.textContent?.trim();
      if (!name) return;
      const href = nameEl.getAttribute('href');
      const fullUrl = href.startsWith('http') ? href : 'https://stackoverflow.com' + href;
      if (seen.has(fullUrl)) return;

      const repEl = card.querySelector('[class*="reputation"], .reputation-score');
      const tagEl = card.querySelector('.post-tag, [class*="tag"]');

      seen.add(fullUrl);
      users.push({
        name,
        soProfile: fullUrl,
        reputation: repEl?.textContent?.trim() || '',
        tag: tagEl?.textContent?.trim() || '',
        source: 'stackoverflow',
        scrapedAt: new Date().toISOString(),
      });
    } catch(e) {}
  });

  return users;
}

// Send to service worker
function sendToExtension() {
  const users = scrapeSOUsers();
  if (users.length > 0) {
    chrome.runtime.sendMessage({
      action: 'SO_USERS_SCRAPED',
      users,
      tag: location.href.match(/\/tags\/([^/]+)\/topusers/)?.[1] || '',
      pageUrl: location.href,
    }).catch(() => {});
    console.log('[PingIN] SO experts found:', users.length);
  } else {
    console.log('[PingIN] SO: No users found on page — layout may have changed');
  }
}

// Wait for page to render
setTimeout(sendToExtension, 3000);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'SCRAPE_SO_USERS') {
    sendResponse({ ok: true, users: scrapeSOUsers() });
  }
  return true;
});
