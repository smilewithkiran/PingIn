/**

// ── Location match helper — used in both auto + manual scrape ─────────────────
const LOC_ALIASES = {
  'bengaluru':  ['bengaluru','bangalore'],
  'hyderabad':  ['hyderabad','secunderabad','cyberabad'],
  'mumbai':     ['mumbai','bombay'],
  'navi mumbai':['navi mumbai'],
  'thane':      ['thane'],
  'delhi':      ['delhi','new delhi'],
  'new delhi':  ['new delhi','delhi'],
  'noida':      ['noida','greater noida'],
  'gurgaon':    ['gurgaon','gurugram'],
  'faridabad':  ['faridabad'],
  'ghaziabad':  ['ghaziabad'],
  'chennai':    ['chennai','madras'],
  'pune':       ['pune','pimpri'],
  'kolkata':    ['kolkata','calcutta'],
  'ahmedabad':  ['ahmedabad'],
  'jaipur':     ['jaipur'],
  'kochi':      ['kochi','cochin','ernakulam'],
  'coimbatore': ['coimbatore'],
  'chandigarh': ['chandigarh','mohali'],
  'indore':     ['indore'],
  'lucknow':    ['lucknow'],
  'nagpur':     ['nagpur'],
};

function matchesCity(profileCity, wantedLoc) {
  if (!wantedLoc) return true;           // no filter → accept all
  if (!profileCity) return false;        // 100% strict: no city visible → reject
  const city = profileCity.toLowerCase();
  const want = wantedLoc.toLowerCase();
  if (city.includes(want)) return true;
  const aliases = LOC_ALIASES[want] || [want.split(' ')[0]];
  return aliases.some(a => city.includes(a));
}
 * PingIN Service Worker v4
 * Smart Outreach: navigates existing LinkedIn tab, no new windows
 * Full state persistence — survives popup close/reopen
 */
'use strict';

// ── Install ──────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  if (reason === 'install') {
    await chrome.storage.local.set({
      profiles: [],
      log: [],
      sent: 0,
      failed: 0,
      dailySent: 0,
      dailyReset: new Date().toDateString(),
      sentUrls: [],           // permanent dedup list
      campaign: {
        running: false,
        paused: false,
        index: 0,
        total: 0,
        message: '',
        type: 'connect',
        startedAt: null,
      },
      campaignScreen: 'home', // last popup screen
      settings: {
        dailyLimit: 25,
        delaySeconds: 45,
        randomDelay: true,
      }
    });
  }
  chrome.alarms.create('dailyReset', {
    when: nextMidnightIST(),
    periodInMinutes: 1440
  });
});

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name === 'dailyReset') {
    await chrome.storage.local.set({
      dailySent: 0,
      dailyReset: new Date().toDateString()
    });
    swLog('Daily counters reset');
  }
  if (alarm.name === 'campaignTick') await campaignTick();
});

// ── Auto-scrape when LinkedIn search page loads ───────────────
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status !== 'complete') return;
  if (!tab.url?.includes('linkedin.com/search/results/people')) return;

  const data = await chrome.storage.local.get('pendingScrape');
  const ps = data.pendingScrape;
  if (!ps) return;
  if ((Date.now() - ps.requestedAt) > 180000) {
    await chrome.storage.local.remove('pendingScrape');
    return;
  }

  swLog('Auto-scrape triggered: ' + (ps.params?.keywords || ''));

  // Three attempts — LinkedIn React needs time to render profiles
  // Using keepAlive ping to prevent service worker termination during waits
  for (let attempt = 1; attempt <= 3; attempt++) {
    const waitMs = attempt === 1 ? 4000 : attempt === 2 ? 5000 : 7000;
    await new Promise(r => setTimeout(r, waitMs));
    // Ping storage to keep SW alive during wait
    await chrome.storage.local.get('_ping').catch(()=>{});
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        func: scrapeLinkedInPage,
      });
      const scraped = results?.[0]?.result || [];
      swLog('Attempt ' + attempt + ' (after ' + waitMs + 'ms): ' + scraped.length + ' profiles');

      if (scraped.length === 0 && attempt < 3) continue;

      if (scraped.length > 0) {
        const stored = await chrome.storage.local.get('profiles');
        const isNew = ps.isNewSearch !== false && (ps.page || 1) <= 1;
        const base  = isNew ? [] : (stored.profiles || []);
        const existing = new Set(base.map(p => p.profileUrl));
        const _wantLoc = (ps.params?.location || '').trim();
        const fresh = scraped
          .filter(p => {
            if (!p.profileUrl || existing.has(p.profileUrl)) return false;
            if (!matchesCity(p.city, _wantLoc)) return false; // strict location filter
            return true;
          })
          .map(p => ({
            ...p,
            status: 'pending',
            keyword:  ps.params?.keywords || '',
            location: ps.params?.location || '',
            page: ps.page || 1,
            scrapedAt: new Date().toISOString(),
          }));
        const all = [...base, ...fresh];
        await chrome.storage.local.set({
          profiles: all,
          lastScrapeResult: { count: fresh.length, total: all.length, at: Date.now() }
        });
        await chrome.storage.local.remove('pendingScrape');
        swLog('Saved ' + fresh.length + ' new profiles. Total: ' + all.length);
        try {
          chrome.runtime.sendMessage({
            action: 'SCRAPE_DONE',
            added: fresh.length,
            total: all.length,
          }).catch(() => {});
        } catch(e) {}
      } else {
        await chrome.storage.local.remove('pendingScrape');
        swLog('No profiles found after 2 attempts');
      }
      break;
    } catch(e) {
      swLog('Scrape error attempt ' + attempt + ': ' + e.message);
      if (attempt === 2) await chrome.storage.local.remove('pendingScrape');
    }
  }
});

// ── Message hub ───────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.action) {

        case 'START_CAMPAIGN': {
          sendResponse({ ok: false, error: 'Smart Outreach is currently unavailable. Please use LinkedIn directly.' });
          break;
        }

        case 'PAUSE_CAMPAIGN': {
          const d = await chrome.storage.local.get('campaign');
          const camp = d.campaign || {};
          camp.paused = !camp.paused;
          await chrome.storage.local.set({ campaign: camp });
          swLog(camp.paused ? 'Campaign paused' : 'Campaign resumed');
          sendResponse({ ok: true, paused: camp.paused });
          break;
        }

        case 'STOP_CAMPAIGN': {
          await chrome.storage.local.set({
            campaign: { running: false, paused: false, index: 0, total: 0, message: '' }
          });
          chrome.alarms.clear('campaignTick');
          // Reset queued profiles back to pending
          const d2 = await chrome.storage.local.get('profiles');
          const profs = (d2.profiles || []).map(p =>
            p.status === 'queued' ? { ...p, status: 'pending' } : p
          );
          await chrome.storage.local.set({ profiles: profs });
          swLog('Campaign stopped');
          sendResponse({ ok: true });
          break;
        }

        case 'GET_STATUS': {
          const d = await chrome.storage.local.get([
            'profiles', 'campaign', 'log', 'sent', 'failed',
            'dailySent', 'sentUrls', 'lastScrapeResult'
          ]);
          sendResponse({ ok: true, ...d });
          break;
        }

        case 'OPEN_TAB': {
          const tab = await chrome.tabs.create({ url: msg.url, active: msg.active !== false });
          sendResponse({ ok: true, tabId: tab.id });
          break;
        }

        case 'SAVE_SCREEN': {
          await chrome.storage.local.set({ campaignScreen: msg.screen });
          sendResponse({ ok: true });
          break;
        }

        case 'MANUAL_SCRAPE': {
          let targetTabId = msg.tabId || null;
          if (!targetTabId) {
            const allTabs = await chrome.tabs.query({});
            const liTab = allTabs.find(t =>
              t.url && t.url.includes('linkedin.com/search/results/people')
            );
            if (liTab) targetTabId = liTab.id;
          }
          if (!targetTabId) {
            sendResponse({ ok: false, error: 'No LinkedIn search tab found' });
            return;
          }
          try {
            const results = await chrome.scripting.executeScript({
              target: { tabId: targetTabId },
              func: scrapeLinkedInPage,
            });
            const scraped = results?.[0]?.result || [];
            if (scraped.length > 0) {
              const psData = await chrome.storage.local.get('pendingScrape');
              const ps2 = psData.pendingScrape;
              const stored = await chrome.storage.local.get('profiles');
              const newKeyword = ps2?.params?.keywords || '';
              const isNew = ps2?.isNewSearch !== false && (ps2?.page || 1) <= 1;
              const base = isNew ? [] : (stored.profiles || []);
              const existing = new Set(base.map(p => p.profileUrl));
              const _wantLoc2 = (ps2?.params?.location || '').trim();
              const fresh = scraped
                .filter(p => {
                  if (!p.profileUrl || existing.has(p.profileUrl)) return false;
                  if (p.city && !matchesCity(p.city, _wantLoc2)) return false;
                  return true;
                })
                .map(p => ({
                  ...p, status: 'pending',
                  keyword: newKeyword,
                  page: ps2?.page || 1,
                  scrapedAt: new Date().toISOString()
                }));
              const all = [...base, ...fresh];
              await chrome.storage.local.set({ profiles: all });
              if (ps2) await chrome.storage.local.remove('pendingScrape');
              try {
                chrome.runtime.sendMessage({
                  action: 'SCRAPE_DONE', added: fresh.length, total: all.length
                }).catch(() => {});
              } catch(e) {}
              sendResponse({ ok: true, found: scraped.length, added: fresh.length, total: all.length });
            } else {
              sendResponse({ ok: false, error: 'No profiles found on page' });
            }
          } catch(e) {
            sendResponse({ ok: false, error: e.message });
          }
          break;
        }

        default:
          sendResponse({ ok: false, error: 'Unknown action: ' + msg.action });
      }
    } catch(e) {
      swLog('SW error: ' + e.message);
      sendResponse({ ok: false, error: e.message });
    }
  })();
  return true;
});

// ── Campaign tick — navigate existing LinkedIn tab ────────────
async function campaignTick() {
  const data = await chrome.storage.local.get([
    'profiles', 'campaign', 'settings', 'dailySent', 'dailyReset', 'sentUrls'
  ]);
  const camp = data.campaign || {};
  const profiles = data.profiles || [];
  const sentUrls = new Set(data.sentUrls || []);

  if (!camp.running || camp.paused) return;

  // Daily reset check
  let dailySent = data.dailySent || 0;
  if (new Date().toDateString() !== data.dailyReset) {
    dailySent = 0;
    await chrome.storage.local.set({ dailySent: 0, dailyReset: new Date().toDateString() });
  }

  const limit = data.settings?.dailyLimit || 25;
  if (dailySent >= limit) {
    swLog('Daily limit ' + limit + ' reached — pausing campaign');
    camp.paused = true;
    await chrome.storage.local.set({ campaign: camp });
    try { chrome.runtime.sendMessage({ action: 'CAMPAIGN_UPDATE', event: 'daily_limit' }).catch(() => {}); } catch(e) {}
    return;
  }

  // Find next queued profile
  const idx = profiles.findIndex(p => p.status === 'queued');
  if (idx === -1) {
    camp.running = false;
    await chrome.storage.local.set({ campaign: camp });
    swLog('Campaign complete');
    try { chrome.runtime.sendMessage({ action: 'CAMPAIGN_UPDATE', event: 'complete' }).catch(() => {}); } catch(e) {}
    return;
  }

  const profile = profiles[idx];

  // Skip if already sent (dedup)
  if (sentUrls.has(profile.profileUrl)) {
    swLog('Skip (already sent): ' + profile.name);
    profiles[idx].status = 'sent';
    await chrome.storage.local.set({ profiles });
    chrome.alarms.create('campaignTick', { delayInMinutes: 0.1 });
    return;
  }

  try {
    // ── Find existing LinkedIn tab ────────────────────────────
    const allTabs = await chrome.tabs.query({});
    let liTab = allTabs.find(t => t.url && t.url.includes('linkedin.com') && !t.url.includes('linkedin.com/search/results') === false);
    // Prefer search results tab, then any LinkedIn tab
    liTab = allTabs.find(t => t.url?.includes('linkedin.com/search/results/people'))
          || allTabs.find(t => t.url?.includes('linkedin.com'));

    if (!liTab) {
      // No LinkedIn tab open — open one
      swLog('No LinkedIn tab found — opening one');
      liTab = await chrome.tabs.create({ url: 'https://www.linkedin.com/feed/', active: false });
      await sleep(3000);
    }

    swLog('Navigating to: ' + profile.name + ' (' + profile.profileUrl + ')');

    // Mark as queued in UI
    profiles[idx].status = 'queued';
    await chrome.storage.local.set({ profiles });
    try { chrome.runtime.sendMessage({ action: 'CAMPAIGN_UPDATE', event: 'actioning', profile }).catch(() => {}); } catch(e) {}

    // ── Navigate existing tab to profile ─────────────────────
    await chrome.tabs.update(liTab.id, { url: profile.profileUrl });

    // Wait for page to load
    await waitForTabLoad(liTab.id, 12000);
    await sleep(2000); // extra wait for React

    // ── Inject connect script ─────────────────────────────────
    const msg = personalizeMessage(camp.message || '', profile);
    let result;
    try {
      result = await chrome.scripting.executeScript({
        target: { tabId: liTab.id },
        func: clickConnectOnProfile,
        args: [msg, camp.type || 'connect'],
      });
    } catch(injErr) {
      throw new Error('Script inject failed: ' + injErr.message);
    }

    const ok = result?.[0]?.result?.success === true;
    const reason = result?.[0]?.result?.reason || '';

    profiles[idx].status = ok ? 'sent' : 'failed';
    profiles[idx].sentAt = new Date().toISOString();
    profiles[idx].failReason = ok ? '' : reason;

    // Update sent URL set
    if (ok) {
      sentUrls.add(profile.profileUrl);
      dailySent++;
    }

    await chrome.storage.local.set({
      profiles,
      sentUrls: [...sentUrls],
      sent: (data.sent || 0) + (ok ? 1 : 0),
      failed: (data.failed || 0) + (ok ? 0 : 1),
      dailySent,
    });

    swLog((ok ? '✓ Sent' : '✗ Failed (' + reason + ')') + ' → ' + profile.name);

    try {
      chrome.runtime.sendMessage({
        action: 'CAMPAIGN_UPDATE',
        event: ok ? 'sent' : 'failed',
        profile,
        reason,
        dailySent,
      }).catch(() => {});
    } catch(e) {}

    // Schedule next action with human-like delay
    const baseDelay = data.settings?.delaySeconds || 45;
    const jitter = Math.floor(Math.random() * 20) - 10;
    const delayMs = Math.max(20, baseDelay + jitter) * 1000;
    swLog('Next action in ' + Math.round(delayMs / 1000) + 's');
    chrome.alarms.create('campaignTick', { delayInMinutes: delayMs / 60000 });

  } catch(e) {
    profiles[idx].status = 'failed';
    profiles[idx].failReason = e.message;
    await chrome.storage.local.set({ profiles });
    swLog('Campaign error: ' + e.message);
    chrome.alarms.create('campaignTick', { delayInMinutes: 0.5 });
  }
}

// ── Wait for tab to finish loading ────────────────────────────
function waitForTabLoad(tabId, timeoutMs) {
  return new Promise((resolve) => {
    const deadline = setTimeout(resolve, timeoutMs);
    function handler(id, info) {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(deadline);
        chrome.tabs.onUpdated.removeListener(handler);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(handler);
  });
}

// ── Scrape LinkedIn search results page ───────────────────────
function scrapeLinkedInPage() {
  const profiles = [];
  const seen = new Set();

  // ── Strategy 1: LinkedIn search result cards (multiple selector variants) ──
  const CARD_SELECTORS = [
    '.reusable-search__result-container',
    '[data-view-name="search-entity-result-universal-template"]',
    '.entity-result',
    'ul.reusable-search__entity-result-list > li',
    '[class*="search-result"][class*="entity"]',
    'li.reusable-search__result-container',
    '[data-chameleon-result-urn]',
    '.search-results-container ul > li',
  ];

  let cards = [];
  for (const sel of CARD_SELECTORS) {
    try {
      const found = document.querySelectorAll(sel);
      if (found.length >= 2) { cards = Array.from(found); break; }
    } catch(e) {}
  }

  // ── Strategy 2: Link-based fallback (always works if profiles render) ───────
  const allLinks = document.querySelectorAll('a[href*="/in/"]');
  allLinks.forEach(link => {
    try {
      const href = link.href || '';
      const url = href.split('?')[0];
      if (!url.match(/linkedin\.com\/in\/[^/]+\/?$/) || seen.has(url)) return;
      // Skip nav/sidebar links — they're usually short text or icons
      const txt = link.textContent?.trim();
      if (!txt || txt.length < 2 || txt === 'LinkedIn Member') return;
      // Skip if this looks like a nav item
      const card = link.closest('li') || link.closest('[class*="result"]') || link.closest('[class*="entity"]');
      if (!card) return;
      seen.add(url);
      const name = link.querySelector('span[aria-hidden="true"]')?.textContent?.trim() ||
                   link.textContent?.trim();
      if (!name || name.length < 2) return;
      profiles.push({
        name,
        profileUrl: url,
        role:    card.querySelector('[class*="primary-subtitle"],[class*="headline"],[class*="t-14 t-black"]')?.textContent?.trim() || '',
        company: card.querySelector('[class*="secondary-subtitle"]')?.textContent?.trim() || '',
        city:    card.querySelector('[class*="tertiary"],[class*="subline-level-2"],[class*="t-12 t-black"]')?.textContent?.trim() || '',
        degree:  card.querySelector('[class*="dist-value"],[class*="distance"]')?.textContent?.trim() || '',
        isOTW:   !!card.querySelector('[aria-label*="Open to work"],[class*="open-to-work"]'),
        photo:   card.querySelector('img[src*="media"],img[src*="profile-displayphoto"]')?.src || '',
        status:  'pending',
        scrapedAt: new Date().toISOString(),
      });
    } catch(e) {}
  });

  // ── Strategy 3: card-based scraping if strategy 1 found cards ───────────────
  if (cards.length > 0) {
    cards.forEach(card => {
      try {
        // Name
        const nameEl = card.querySelector('a[href*="/in/"] span[aria-hidden="true"]') ||
                       card.querySelector('[class*="title"] span[aria-hidden="true"]') ||
                       card.querySelector('span[class*="name"]');
        const name = nameEl?.textContent?.trim();
        if (!name || name === 'LinkedIn Member' || name.length < 2) return;

        // Profile URL
        const linkEl = card.querySelector('a[href*="/in/"]');
        const url = linkEl?.href?.split('?')[0];
        if (!url || seen.has(url)) return;
        seen.add(url);

        // Role, Company, City
        const subs = card.querySelectorAll('[class*="subtitle"],[class*="subline"]');
        const role    = subs[0]?.textContent?.trim() || card.querySelector('[class*="primary"]')?.textContent?.trim() || '';
        const company = subs[1]?.textContent?.trim() || card.querySelector('[class*="secondary"]')?.textContent?.trim() || '';
        const city    = subs[2]?.textContent?.trim() || card.querySelector('[class*="tertiary"],[class*="t-12"]')?.textContent?.trim() || '';
        const degree  = card.querySelector('[class*="dist"],[class*="distance"]')?.textContent?.trim() || '';
        const photo   = card.querySelector('img[src*="media"],img[src*="profile"]')?.src || '';
        const isOTW   = !!card.querySelector('[aria-label*="Open to work"]');

        // Override in profiles array if we already have this from link strategy
        const existing = profiles.findIndex(p => p.profileUrl === url);
        const data = { name, profileUrl: url, role, company, city, degree, photo, isOTW, status:'pending', scrapedAt: new Date().toISOString() };
        if (existing > -1) profiles[existing] = data;
        else profiles.push(data);
      } catch(e) {}
    });
  }

  return profiles.filter(p => p.name && p.profileUrl);
}

// ── Click Connect on a profile page ──────────────────────────
function clickConnectOnProfile(message, campaignType) {
  return new Promise(async resolve => {
    function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

    function findBtn(labels, root) {
      root = root || document;
      for (const label of labels) {
        let el = root.querySelector(`button[aria-label="${label}"]`);
        if (el?.offsetParent !== null) return el;
        el = root.querySelector(`button[aria-label*="${label}"]`);
        if (el?.offsetParent !== null) return el;
        const all = Array.from(root.querySelectorAll('button'));
        el = all.find(b => b.offsetParent !== null && b.textContent.trim() === label);
        if (el) return el;
        el = all.find(b => b.offsetParent !== null && b.textContent.trim().toLowerCase() === label.toLowerCase());
        if (el) return el;
      }
      return null;
    }

    function getModal() {
      return document.querySelector('.artdeco-modal, [data-test-modal], [role="dialog"]') || document;
    }

    await sleep(1500);

    // ── Handle 'Message' type — for 1st connections ──────────
    if (campaignType === 'message') {
      const msgBtn = findBtn(['Message']);
      if (!msgBtn) { resolve({ success: false, reason: 'No Message button — may not be 1st connection' }); return; }
      msgBtn.click();
      await sleep(1500);
      const modal = getModal();
      const ta = modal.querySelector('div[role="textbox"], .msg-form__contenteditable, textarea');
      if (!ta) { resolve({ success: false, reason: 'Message box not found' }); return; }
      ta.focus();
      try {
        const setter = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'innerHTML')?.set;
        if (setter && ta.getAttribute('role') === 'textbox') {
          setter.call(ta, message);
          ta.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          const setter2 = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
          if (setter2) setter2.call(ta, message);
          ta.dispatchEvent(new Event('input', { bubbles: true }));
        }
      } catch(e) {
        ta.textContent = message;
        ta.dispatchEvent(new Event('input', { bubbles: true }));
      }
      await sleep(800);
      const sendBtn = findBtn(['Send', 'Send message'], modal);
      if (sendBtn && !sendBtn.disabled) {
        sendBtn.click();
        await sleep(500);
        resolve({ success: true });
      } else {
        resolve({ success: false, reason: 'Send button not found or disabled' });
      }
      return;
    }

    // ── Handle 'visit' type — just visiting is enough ─────────
    if (campaignType === 'visit') {
      resolve({ success: true }); // visiting the page IS the action
      return;
    }

    // ── Default: Connect ──────────────────────────────────────
    let connectBtn = findBtn(['Connect']);
    if (!connectBtn) {
      // Try More Actions menu
      const more = findBtn(['More actions', 'More']);
      if (more) {
        more.click();
        await sleep(800);
        connectBtn = findBtn(['Connect']);
      }
    }
    if (!connectBtn) {
      resolve({ success: false, reason: 'No Connect button — may already be connected' });
      return;
    }

    connectBtn.click();
    await sleep(1500);
    const modal = getModal();

    // Handle "How do you know X?" screen
    const otherBtn = findBtn(['Other'], modal);
    if (otherBtn) {
      otherBtn.click();
      await sleep(600);
      const nextBtn = findBtn(['Next'], modal);
      if (nextBtn) { nextBtn.click(); await sleep(800); }
    }

    // Add note if message provided
    if (message && message.trim()) {
      const addNoteBtn = findBtn(['Add a note', 'Add note'], getModal());
      if (addNoteBtn) {
        addNoteBtn.click();
        await sleep(900);
        const ta = document.querySelector('#custom-message, .artdeco-modal textarea, .send-invite textarea');
        if (ta) {
          try {
            const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
            setter.call(ta, message.slice(0, 300));
            ta.dispatchEvent(new Event('input', { bubbles: true }));
            ta.dispatchEvent(new Event('change', { bubbles: true }));
          } catch(e) {
            ta.value = message.slice(0, 300);
            ta.dispatchEvent(new Event('input', { bubbles: true }));
          }
          await sleep(500);
        }
      }
    }

    await sleep(400);
    const sendBtn = findBtn(['Send now', 'Send invitation', 'Send', 'Done'], getModal());
    if (sendBtn && !sendBtn.disabled) {
      sendBtn.click();
      await sleep(600);
      resolve({ success: true });
    } else {
      const dismiss = document.querySelector('[aria-label="Dismiss"], .artdeco-modal__dismiss');
      if (dismiss) dismiss.click();
      resolve({ success: false, reason: 'Send button not found or disabled' });
    }
  });
}

// ── Message personalisation ───────────────────────────────────
function personalizeMessage(tmpl, p) {
  const first = (p.name || '').split(' ')[0] || 'there';
  const role  = (p.role || '').split(' at ')[0].trim() || 'your field';
  return tmpl
    .replace(/{{first_name}}/g, first)
    .replace(/{{company}}/g,    p.company || 'your company')
    .replace(/{{role}}/g,       role)
    .replace(/{{location}}/g,   p.city || 'your city')
    .replace(/{{your_name}}/g,  'Recruiter')
    .replace(/{FirstName}/g,    first)
    .replace(/{Role}/g,         role)
    .replace(/{Company}/g,      p.company || 'your company');
}

// ── Suppress extension noise ──────────────────────────────────
self.addEventListener('unhandledrejection', event => {
  const msg = event?.reason?.message || '';
  if (
    msg.includes('Receiving end does not exist') ||
    msg.includes('Could not establish connection') ||
    msg.includes('message channel closed') ||
    msg.includes('Extension context invalidated')
  ) event.preventDefault();
});

// ── Utilities ─────────────────────────────────────────────────
async function swLog(msg) {
  const data = await chrome.storage.local.get('log');
  const log  = data.log || [];
  log.unshift('[' + new Date().toLocaleTimeString('en-IN') + '] ' + msg);
  if (log.length > 50) log.pop();
  await chrome.storage.local.set({ log });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function nextMidnightIST() {
  const now = new Date();
  const ist = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
  const midnight = new Date(ist);
  midnight.setDate(midnight.getDate() + 1);
  midnight.setHours(0, 0, 0, 0);
  return Date.now() + (midnight - ist);
}

// ── Salary Intel AI (preserved) ───────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'SI_GET_SALARY') {
    siAICall(msg.profileText)
      .then(r  => sendResponse({ ok: true,  ...r }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});

async function siAICall(profileText) {
  const stored = await chrome.storage.local.get('anthropicApiKey');
  const apiKey = (stored.anthropicApiKey || '').trim();
  if (!apiKey) throw new Error('NO_KEY');
  const text2k = profileText.slice(0, 2000);
  const prompt = [
    'You are a senior compensation analyst for the Indian job market (2025-26).',
    'Read this LinkedIn profile and return a salary estimate as JSON.',
    'PROFILE TEXT:', '"""', text2k, '"""',
    'Return ONLY this JSON (no markdown):',
    '{"title":"","company":"","city":"","expYears":null,"education":"","tier":"","minLPA":0,"maxLPA":0,"reasoning":""}',
    'Bands: faang 15-200L, unicorn 10-130L, mnc 7-100L, startup 6-85L, service 3-45L',
  ].join('\n');
  const resp = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 400,
      messages: [{ role: 'user', content: prompt }]
    })
  });
  if (!resp.ok) { const e = await resp.json().catch(() => ({})); throw new Error(e?.error?.message || 'API error ' + resp.status); }
  const data = await resp.json();
  const raw  = (data.content?.[0]?.text || '').replace(/```json|```/g, '').trim();
  const json = JSON.parse(raw);
  json.ok = true;
  return json;
}
